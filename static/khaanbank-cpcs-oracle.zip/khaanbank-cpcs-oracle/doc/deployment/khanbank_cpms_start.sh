cd /var/www/vhosts/chinggis.systems/projects/khanbank-cpms
./mvnw -Pprod clean verify -Dmaven.test.skip=true
java -jar target/*.jar --spring.profiles.active=prod
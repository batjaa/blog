cd /var/www/vhosts/chinggis.systems/projects/khanbank-cpms
git reset --hard origin/master
git pull origin
chmod +x -R /var/www/vhosts/chinggis.systems/projects/khanbank-cpms/
./mvnw -Pprod clean verify
java -jar target/*.jar --spring.profiles.active=prod
npm run webpack:prod
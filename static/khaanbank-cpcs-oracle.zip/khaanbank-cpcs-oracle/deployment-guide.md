## Deployment guide

## Setting up your environment

- Install Java 8. We recommend installing it from [Oracle](https://www.oracle.com/technetwork/java/javase/downloads/index.html).
- Install Node.js from the [Node.js website](https://nodejs.org/) (please use an LTS 64-bit version, non-LTS versions are not supported). [not needed on server, only for building the app]
- Install the build tool [Maven](https://maven.apache.org/) v3.6.1^. [not needed on server, only for building the app]

- Python 3.3 or later. If prompted to install `pip`, prompt yes.
  - To install python and dependent libraries, we recommend [this guide](https://www.ibm.com/support/knowledgecenter/en/SSWTQQ_2.0.3/install/t_si_pythonpackagesoffline.html).
- Install [pywin32](http://sourceforge.net/projects/pywin32/files/pywin32), pywin32 can't be installed with `pip`, follow as instructed in the doc.
- [Pillow](https://pypi.python.org/pypi/Pillow) 3.3.1 or later. `pip install
    - Download the necessary python packages and copy the zip files into a directory on the offline computer.
    Create a folder called `pypi` (can be anywhere we will take `C:/online/pypi` as our example) and create a file called "requirements.txt" inside the newly created `C:/online/pypi` that contains the following
    ```
    Pillow==6.0.0
    ```
    - Open the `pypi` directory in with a cli and download the required zip files
    ```
    pip download -r requirements.txt
    ```
    This will download _not_ install required packages
    - To install the packages on an offline machine. Copy the `C:/online/pypi` directory to the offline machine (e.g. `C:/offline/pypi`) and run
    ```
    pip install -r requirements.txt --no-index --find-links file:///C:/offline/pypi
    ```

- [MySQL](https://www.mysql.com/downloads/) 5.7
- Microsoft Excel 2013 or later

## Running the app

We will need to download necessary 3rd party libraries and the source code in an online environment, build the code and copy to the offline computer.

### 1. Get the repo

Either downloading the zip or using [git](https://git-scm.com/) download the [repo](https://github.com/chinggis-systems/khaanbank-cpcs) (remember you'll need access).

### 2. Configure your env variables

Configure your production variables in `src/main/resources/config/application-prod.yml`

    spring.datasource.url: 'jdbc:mysql://<URL>:<PORT>/<DB_NAME>?useUnicode=true&characterEncoding=utf8&useSSL=false&useLegacyDatetimeCode=false&serverTimezone=UTC'
    spring.datasource.username - DB_USERNAME
    spring.datasource.password - DB_PASSWORD

    app.python-director - python executable home directory
    e.g. app.python-home: C:/Users/user_name/AppData/Local/Programs/Python/Python37/

### 3. Packaging as jar

To build the final jar and optimize the KhanbankCpms API for production, run:

    mvn -Pprod clean verify

### 4. Configure your env variables

Configure `webpack/webpack.prod.js` as necessary. At minimum change these values:

    output.path - webpack build ouput directory. Where all the client app resources will be exported. Absolute path is required.
    SERVER_API_URL - API URL (without the API prefix)
    new BaseHrefWebpackPlugin({ baseHref: '' }) - BaseURL for client app

### 5. Build client app

To build the client app, run:

    npm install
    npm run webpack:prod

This will concatenate and minify the client CSS and JavaScript files. It will also modify `index.html` so it references these new files.

### 6. Copying to offline computer

- Copy the created jar file from step 3 to the offline computer. By default the jar file should be created in in the repo `./target/khanbank-cpms<version>.jar`.
- Zip the webpack output directory (`output.path` config directory) from step 5 and copy the created client app to the server.

### 7. Run API service

Make sure the java server is serving the jar file, run the command choosing the production profile:

    java -jar target/*.jar --spring.profiles.active=prod

### 8. Serve the client app

The copied client app is ready to serve and it should be hosted on a web server.

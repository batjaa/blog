package com.khanbank.cpms.domain.enumeration;

/**
 * The EngineerAssessmentType enumeration.
 */
public enum EngineerAssessmentType {
    FIRST_ASSESMENT, GRANT, MID_ASSESMENT, ADDITIONAL_GRANT
}

package com.khanbank.cpms.service;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.khanbank.cpms.domain.Compliance;
import com.khanbank.cpms.domain.Notification;
import com.khanbank.cpms.domain.Project;
import com.khanbank.cpms.repository.ComplianceRepository;
import com.khanbank.cpms.repository.NotificationRepository;
import com.khanbank.cpms.service.util.HelperUtil;

/**
 * Service for managing notifications.
 * <p>
 * This is the default implementation to support SpringBoot Actuator {@code NotificationService}.
 */
@Service
@Transactional
public class NotificationService {

    private final Logger logger = LoggerFactory.getLogger(NotificationService.class);

    @Autowired
    private NotificationRepository notificationRepository;

    @Autowired
    private ComplianceRepository complianceRepository;

    /** Төслийн холбогдох зөвшөөрлийн хугацаа дууссан эсэхийг шалгах, дууссан зөвшөөрлийн тухай сонордуулга notification table-д нэмэх */
    @Scheduled(cron = "0 0 6 * * *") // Өдөр бүр 06:00 цагт
    public void checkDueDate() {
        List<Compliance> complianceList = complianceRepository.findByDueDateBefore(Instant.now());
        if (complianceList == null)
            return;

        final List<Notification> notificatioList = new ArrayList<Notification>();

        complianceList.forEach(c -> {
            Project project = c.getProject();
            // notifications for to remind project direct owners
            String message = project.getName() + " төслийн \"" + c.getType().name()
                    + "\" зөвшөөрлийн хугацаа дууссан байна!";
            
            List<String> userIds = new ArrayList<>();
            
            try {
                userIds = HelperUtil.parseListString(project.getUsers(), ",");
            } catch (Exception e) {
                logger.error(e.getMessage());
            }

            userIds.forEach(userId -> notificatioList.add(creatNotification(message, userId)));
        });

        notificationRepository.saveAll(notificatioList);
        notificationRepository.flush();
    }

    private Notification creatNotification(String message, String userId) {
        Notification result = new Notification();
        result.setMessage(message);
        result.setUserId(userId);
        return result;
    }

    public void sendNotification(List<String> userIds, String message) {

        if (message == null || message.isEmpty())
            return;

        userIds.forEach(userId -> notificationRepository.saveAndFlush(creatNotification(message, userId)));

    }
    
}

package com.khanbank.cpms.web.rest;

import java.net.URISyntaxException;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.khanbank.cpms.domain.EngineerAssessment;
import com.khanbank.cpms.domain.File;
import com.khanbank.cpms.repository.EngineerAssessmentRepository;
import com.khanbank.cpms.repository.FileRepository;
import com.khanbank.cpms.service.util.HelperUtil;
import com.khanbank.cpms.service.util.JsonUtil;

import io.github.jhipster.web.util.HeaderUtil;
import io.github.jhipster.web.util.ResponseUtil;

/**
 * REST controller for managing {@link com.khanbank.cpms.domain.EngineerAssessment}.
 */
@RestController
@RequestMapping("/api")
public class EngineerAssessmentResource {

    private final Logger log = LoggerFactory.getLogger(EngineerAssessmentResource.class);

    private static final String ENTITY_NAME = "engineerAssessment";

    private static final String ENGINEERASSESSMENT_FILE_ID = "fileIds";

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final EngineerAssessmentRepository engineerAssessmentRepo;

    @Autowired
    private FileRepository fileRepo;

    public EngineerAssessmentResource(EngineerAssessmentRepository engineerAssessmentRepository) {
        this.engineerAssessmentRepo = engineerAssessmentRepository;
    }

    /**
     * {@code PUT  /engineer-assessments} : Updates an existing engineerAssessment.
     *
     * @param engineerAssessment
     *            the engineerAssessment to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated engineerAssessment, or with status {@code 400 (Bad Request)} if the engineerAssessment is not valid, or
     *         with status {@code 500 (Internal Server Error)} if the engineerAssessment couldn't be updated.
     * @throws URISyntaxException
     *             if the Location URI syntax is incorrect.
     */
    @PutMapping("/engineer-assessments")
    public ResponseEntity<EngineerAssessment> updateEngineerAssessment(@Valid @RequestBody ObjectNode content)
            throws URISyntaxException {
        log.debug("REST request to update EngineerAssessment : {}", content);

        ArrayNode nodeFileIds = (ArrayNode) content.get(ENGINEERASSESSMENT_FILE_ID);

        EngineerAssessment engineerAssessment = JsonUtil.parseObjectNodeToObject(content, EngineerAssessment.class,
                ENGINEERASSESSMENT_FILE_ID);

        Optional<EngineerAssessment> optOldEngineerAssessment = engineerAssessmentRepo
                .findById(engineerAssessment.getId());

        boolean updateEntity = HelperUtil.updateObjectRequiredFields(optOldEngineerAssessment, engineerAssessment,
                "project");

        if (!updateEntity)
            return ResponseEntity.badRequest().build();

        Set<Long> fileIds = HelperUtil.convertListLongValues(nodeFileIds);

        Set<File> files = fileIds.isEmpty() ? new HashSet<>()
                : fileRepo.findAllById(fileIds).stream().collect(Collectors.toSet());

        engineerAssessment.setFiles(files);

        EngineerAssessment result = engineerAssessmentRepo.save(engineerAssessment);

        return ResponseEntity.ok().headers(HeaderUtil.createEntityUpdateAlert(applicationName, true, ENTITY_NAME,
                engineerAssessment.getId().toString())).body(result);
    }

    /**
     * {@code GET  /engineer-assessments/:id} : get the "id" engineerAssessment.
     *
     * @param id
     *            the id of the engineerAssessment to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the engineerAssessment, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/engineer-assessments/{id}")
    public ResponseEntity<EngineerAssessment> getEngineerAssessment(@PathVariable Long id) {
        log.debug("REST request to get EngineerAssessment : {}", id);
        Optional<EngineerAssessment> engineerAssessment = engineerAssessmentRepo.findById(id);
        return ResponseUtil.wrapOrNotFound(engineerAssessment);
    }

    /**
     * {@code DELETE  /engineer-assessments/:id} : delete the "id" engineerAssessment.
     *
     * @param id
     *            the id of the engineerAssessment to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/engineer-assessments/{id}")
    public ResponseEntity<Void> deleteEngineerAssessment(@PathVariable Long id) {
        log.debug("REST request to delete EngineerAssessment : {}", id);
        engineerAssessmentRepo.deleteById(id);
        return ResponseEntity.noContent()
                .headers(HeaderUtil.createEntityDeletionAlert(applicationName, true, ENTITY_NAME, id.toString()))
                .build();
    }
}

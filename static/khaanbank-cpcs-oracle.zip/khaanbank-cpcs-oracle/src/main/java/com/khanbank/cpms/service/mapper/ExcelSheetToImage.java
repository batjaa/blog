package com.khanbank.cpms.service.mapper;

import java.io.File;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.khanbank.cpms.service.util.FileUtil;

/**
 * used resource: https://github.com/glexey/excel2img
 */
public class ExcelSheetToImage {

    private final Logger logger = LoggerFactory.getLogger(ExcelSheetToImage.class);

    private String pythonDirector = "";
    private String pythonScriptDirector = System.getProperty("user.dir") + "/src/main/resources/";
    private String pythonPyScriptName = "excel2img.py";

    public ExcelSheetToImage(String pythonDirector) {
        this.pythonDirector = pythonDirector;
    }

    public void convert(File inputXlsxFile, String sheetName, String fromCell, String toCell, String outputFilePath)
            throws Exception {

        if (inputXlsxFile == null)
            throw new Exception("input file cannot be null");

        convert(inputXlsxFile.getAbsolutePath(), sheetName, fromCell, toCell, outputFilePath);
    }

    /**
     * Convert input ms excel file to image
     * 
     * @param inputXlsxFilePath
     *            absolut path of source excel file
     * @param sheetName
     *            sheet name of excel file, if nec
     * @param fromCell
     *            range from
     * @param toCell
     *            range to
     * @param output
     *            image absolut path
     * 
     * @throws Exception
     */
    public void convert(String inputXlsxFilePath, String sheetName, String fromCell, String toCell,
            String outputFilePath) throws Exception {

        if (pythonDirector.isEmpty()) {
            throw new Exception("Python director not found !!!");
        }

        if (inputXlsxFilePath == null && sheetName == null && fromCell == null && toCell == null
                && outputFilePath == null)
            throw new Exception("Excel sheetToImage generator bad request parameters");

        if (!FileUtil.existsFile(inputXlsxFilePath))
            throw new Exception("input file cannot be exists");

        boolean hasSheet = sheetName != null;
        boolean hasRange = fromCell != null && toCell != null && hasSheet;

        String flag = "";

        if (hasRange)
            flag = " -r \"" + sheetName + "!" + fromCell + ":" + toCell + "\"";
        else if (hasSheet)
            flag = " -p " + sheetName;

        if (!hasSheet && !hasRange)
            throw new Exception("Failed locating used cell range on page");

        String rootPythonScriptDirector = pythonScriptDirector + pythonPyScriptName;

        if (!FileUtil.existsFile(rootPythonScriptDirector))
            throw new Exception("python script director not found file: " + pythonPyScriptName);

        String command = rootPythonScriptDirector + " " + inputXlsxFilePath + " " + outputFilePath + flag;

        String pythonCommand = pythonDirector + "python " + command;

        logger.debug("*** {} ***", pythonCommand);

        Process process = Runtime.getRuntime().exec(pythonCommand);

        // process exit value 0 үүсэгэсэн амжилтай болсон эсвэл 1 бол алдаатай ажилсан үүсэгэж чадаггүй
        int processExitValue = Integer.MIN_VALUE;
        do {
            try {
                processExitValue = process.exitValue();
            } catch (IllegalThreadStateException e) {
            }
        } while (processExitValue == Integer.MIN_VALUE);

        logger.debug("process script : {}, process exited value: {}", pythonPyScriptName, processExitValue);

        if (processExitValue > 0)
            throw new Exception("Failed excel file convert image generated bad request");

    }

}

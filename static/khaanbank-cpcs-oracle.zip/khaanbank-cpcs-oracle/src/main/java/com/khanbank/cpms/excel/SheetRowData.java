package com.khanbank.cpms.excel;

import java.util.List;

import com.khanbank.cpms.excel.template.TemplateField;

public class SheetRowData {

    private int lineNumber = -1;
    private List<TemplateField> documentFields;

    public SheetRowData(int lineNumber, List<TemplateField> documentFields) {
        this.lineNumber = lineNumber;
        this.documentFields = documentFields;
    }

    public int getLineNumber() {
        return lineNumber;
    }

    public void setLineNumber(int lineNumber) {
        this.lineNumber = lineNumber;
    }

    public List<TemplateField> getDocumentFields() {
        return documentFields;
    }

    public void setDocumentFields(List<TemplateField> documentFields) {
        this.documentFields = documentFields;
    }

    public TemplateField findDocumentField(Class<?> contentClass, String fieldName) {
        return documentFields.stream()
                .filter(f -> f.getContentClass().equals(contentClass) && f.getFieldName().matches(fieldName))
                .findFirst().orElse(null);
    }

}

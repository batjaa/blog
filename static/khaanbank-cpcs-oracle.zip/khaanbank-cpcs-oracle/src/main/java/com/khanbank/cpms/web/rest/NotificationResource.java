package com.khanbank.cpms.web.rest;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.khanbank.cpms.domain.Notification;
import com.khanbank.cpms.repository.NotificationRepository;

import io.github.jhipster.web.util.PaginationUtil;
import io.github.jhipster.web.util.ResponseUtil;
import net.kaczmarzyk.spring.data.jpa.domain.Equal;
import net.kaczmarzyk.spring.data.jpa.domain.Null;
import net.kaczmarzyk.spring.data.jpa.web.annotation.And;
import net.kaczmarzyk.spring.data.jpa.web.annotation.Spec;

/**
 * REST controller for managing {@link com.khanbank.cpms.domain.Notification}.
 */
@RestController
@RequestMapping("/api")
public class NotificationResource {

    private final Logger log = LoggerFactory.getLogger(NotificationResource.class);

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final NotificationRepository notificationRepository;

    public NotificationResource(NotificationRepository notificationRepository) {
        this.notificationRepository = notificationRepository;
    }

    @PostMapping("/notifications/{id}/acknowledged")
    public ResponseEntity<Notification> acknowledgedNotification(@PathVariable Long id) {

        Optional<Notification> optNotify = notificationRepository.findById(id);

        if (optNotify.isPresent()) {

            Notification notification = optNotify.get();
            notification.setAcknowledgedAt(Instant.now());
            notificationRepository.save(notification);

            return ResponseEntity.ok().body(notification);
        }

        return ResponseEntity.badRequest().build();
    }

    /**
     * {@code GET  /notifications} : get all the notifications.
     *
     * @param pageable
     *            the pagination information.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of notifications in body.
     */
    @GetMapping("/notifications")
    public ResponseEntity<List<Notification>> getAllNotifications(@And({
            @Spec(path = "acknowledgedAt", spec = Null.class, constVal = "true"),
            @Spec(path = "userId", params = "filter[user_id]", spec = Equal.class),
    }) Specification<Notification> spec, Pageable pageable, UriComponentsBuilder uriBuilder) {
        log.debug("REST request to get a page of Notifications");
        Page<Notification> page = notificationRepository.findAll(spec, pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(uriBuilder, page);
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
     * {@code GET  /notifications/:id} : get the "id" notification.
     *
     * @param id
     *            the id of the notification to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the notification, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/notifications/{id}")
    public ResponseEntity<Notification> getNotification(@PathVariable Long id) {
        log.debug("REST request to get Notification : {}", id);
        Optional<Notification> notification = notificationRepository.findById(id);
        return ResponseUtil.wrapOrNotFound(notification);
    }

}

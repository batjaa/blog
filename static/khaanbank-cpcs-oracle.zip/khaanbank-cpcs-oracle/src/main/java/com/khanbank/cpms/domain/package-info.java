/**
 * JPA domain objects.
 */
package com.khanbank.cpms.domain;

package com.khanbank.cpms.security;

import java.util.HashSet;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.stereotype.Component;

import com.khanbank.cpms.domain.Authority;

@Component
public class CustomAuthenticationProvider implements AuthenticationProvider {

    private final Logger logger = LoggerFactory.getLogger(CustomAuthenticationProvider.class);

    public CustomAuthenticationProvider() {
        super();
    }

    // API
    @Override
    public Authentication authenticate(final Authentication authentication) throws AuthenticationException {
        final String username = authentication.getName();
        final String password = authentication.getCredentials().toString();

        try {
            //Demo Authority
            Set<Authority> authorities = new HashSet<>();
            Authority authority = new Authority();
            authority.setName(username.toUpperCase());
            authorities.add(authority);


            return new UsernamePasswordAuthenticationToken(username, password, authorities);
        } catch (Exception exception) {
            logger.error(exception.getMessage());
            return null;
        }
    }


    @Override
    public boolean supports(final Class<?> authentication) {
        return authentication.equals(UsernamePasswordAuthenticationToken.class);
    }

}

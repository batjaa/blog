package com.khanbank.cpms.excel;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.khanbank.cpms.excel.template.TemplateField;

public class SheetData {

    private String name;
    private String fromCell;
    private String toCell;

    private List<SheetRowData> sheetRowDatas;

    private Class<?> entityClass;

    private List<String> errorMessages = new ArrayList<>();

    public SheetData(Class<?> entityClass) {
        this.entityClass = entityClass;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFromCell() {
        return fromCell;
    }

    public void setFromCell(String fromCell) {
        this.fromCell = fromCell;
    }

    public String getToCell() {
        return toCell;
    }

    public void setToCell(String toCell) {
        this.toCell = toCell;
    }

    public boolean hasFromToCell() {
        return this.fromCell != null && !fromCell.isEmpty() && toCell != null && !toCell.isEmpty();
    }

    public void addSheetRowData(SheetRowData sheetRowData) {
        addSheetRowData(-1, sheetRowData);
    }

    public void addSheetRowData(int index, SheetRowData sheetRowData) {

        if (sheetRowDatas == null)
            sheetRowDatas = new ArrayList<>();

        if (index > -1 && sheetRowDatas.size() > index)
            sheetRowDatas.add(index, sheetRowData);
        else
            sheetRowDatas.add(0, sheetRowData);
    }

    public void removeSheetRowData(SheetRowData sheetRowData) {

        if (sheetRowDatas == null)
            return;

        sheetRowDatas.remove(sheetRowData);
    }

    public List<SheetRowData> getSheetRowDatas() {
        return sheetRowDatas;
    }

    public void setSheetRowDatas(List<SheetRowData> fileLineParsers) {
        this.sheetRowDatas = fileLineParsers;
    }

    public Class<?> getEntityClass() {
        return entityClass;
    }

    public void setEntityClass(Class<?> entityClass) {
        this.entityClass = entityClass;
    }

    public void addErrorMessage(String errorMessage) {

        if (errorMessages.stream().anyMatch(e -> e.matches(errorMessage)))
            return;

        errorMessages.add(errorMessage);
    }

    public void removeErrorMessage(String errorMessage) {
        errorMessages.remove(errorMessage);
    }

    public List<String> getErrorMessages() {
        return errorMessages;
    }

    public void setErrorMessages(List<String> errorMessages) {
        this.errorMessages = errorMessages;
    }

    public boolean isSheetRowData() {
        return sheetRowDatas != null && !sheetRowDatas.isEmpty();
    }

    public boolean hasErrorMessages() {
        return errorMessages != null && !errorMessages.isEmpty();
    }

    public TemplateField findTemplate(Class<?> contentClass, String fieldName) {

        Optional<SheetRowData> optionalRowData = sheetRowDatas.stream()
                .filter(f -> f.findDocumentField(contentClass, fieldName) != null).findFirst();

        TemplateField templateField = null;

        if (optionalRowData.isPresent())
            templateField = optionalRowData.get().findDocumentField(contentClass, fieldName);

        return templateField;
    }

}

package com.khanbank.cpms.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.khanbank.cpms.domain.ProjectCostEstimateSubmission;

/**
 * Spring Data repository for the ProjectCostEstimateSubmission entity.
 */
@Repository
public interface ProjectCostEstimateSubmissionRepository extends JpaRepository<ProjectCostEstimateSubmission, Long> {

    Page<ProjectCostEstimateSubmission> findByDeletedAtIsNullAndProjectCostEstimateProjectId(Long id, Pageable pageable);

    Page<ProjectCostEstimateSubmission> findByDeletedAtIsNullAndProjectCostEstimateId(Long id, Pageable pageable);
}

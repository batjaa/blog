package com.khanbank.cpms.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.khanbank.cpms.domain.EngineerAssessment;

/**
 * Spring Data repository for the EngineerAssessment entity.
 */
@Repository
public interface EngineerAssessmentRepository extends JpaRepository<EngineerAssessment, Long> {

	Page<EngineerAssessment> findByProjectId(Long projectId, Pageable pageable);

}

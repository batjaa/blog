package com.khanbank.cpms.service;

import java.io.File;
import java.util.Set;

import org.springframework.web.multipart.MultipartFile;

import com.khanbank.cpms.excel.SheetData;

public interface StorageService {

    void init();

    File store(MultipartFile file);

    <T> Set<T> loadParserSheetDatas(com.khanbank.cpms.domain.File file, Class<T> entityClass) throws Exception;

    <T> T loadParserSheetData(com.khanbank.cpms.domain.File file, Class<T> entityClass) throws Exception;

    SheetData customParserSheetData(com.khanbank.cpms.domain.File file, Class<?>... classes) throws Exception;

    String generateSheetToImage(com.khanbank.cpms.domain.File file, String sheetName, String fromCell, String toCell);
}

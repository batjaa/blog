package com.khanbank.cpms.domain.enumeration;

/**
 * The ProjectCostEstimateSubmissionStatus enumeration.
 */
public enum ProjectCostEstimateSubmissionStatus {
    SUBMITTED, ACCEPTED, DECLINED
}

package com.khanbank.cpms.excel.template;

public class TemplateField implements Comparable<TemplateField> {

    private String displayName;

    private String fieldName;

    private String groupFieldName;

    private Class<?> type;

    private Class<?> contentClass;

    private Class<?> parentClass;

    private boolean collection;

    private boolean isRequired;

    private Object value;

    public TemplateField(TemplateField field) {
        this.displayName = field.getDisplayName();
        this.fieldName = field.getFieldName();
        this.type = field.getType();
        this.contentClass = field.getContentClass();
        this.value = field.getValue();
        this.parentClass = field.getParentClass();
        this.collection = field.isCollection();
        this.isRequired = field.isRequired();
        this.groupFieldName = field.getGroupFieldName();
    }

    public TemplateField(String displayName, String fieldName, Class<?> type, Class<?> contentClass,
            Class<?> parentClass) {

        this.displayName = displayName;
        this.fieldName = fieldName;
        this.type = type;
        this.contentClass = contentClass;
        this.parentClass = parentClass;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getFieldName() {
        return fieldName;
    }

    public void setFieldName(String fieldName) {
        this.fieldName = fieldName;
    }

    public Class<?> getType() {
        return type;
    }

    public void setType(Class<?> type) {
        this.type = type;
    }

    public Object getValue() {
        return value;
    }

    public void setValue(Object value) {
        this.value = value;
    }

    public Class<?> getContentClass() {
        return contentClass;
    }

    public void setContentClass(Class<?> contentClass) {
        this.contentClass = contentClass;
    }

    @Override
    public String toString() {
        return displayName + " - " + fieldName + " : " + value;
    }

    public boolean hasValue() {
        return value != null && !value.toString().isEmpty();
    }

    public Class<?> getParentClass() {
        return parentClass;
    }

    public void setParentClass(Class<?> parentClass) {
        this.parentClass = parentClass;
    }

    public boolean isCollection() {
        return this.collection;
    }

    public void setCollection(boolean collection) {
        this.collection = collection;
    }

    public boolean isRequired() {
        return isRequired;
    }

    public void setRequired(boolean isRequired) {
        this.isRequired = isRequired;
    }

    public boolean hasParentClass() {
        return this.parentClass != null;
    }

    public boolean anyMatchDisplayName(String displayName) {
        return this.displayName != null && this.displayName.matches(displayName);
    }

    public String getGroupFieldName() {
        return groupFieldName;
    }

    public void setGroupFieldName(String groupFieldName) {
        this.groupFieldName = groupFieldName;
    }

    public boolean hasGroupFieldName() {
        return this.groupFieldName != null && !this.groupFieldName.isEmpty();
    }

    @Override
    public int compareTo(TemplateField o) {
        int compareTo = 0;

        if (this.displayName != null && o.getDisplayName() != null)
            compareTo = this.displayName.compareTo(o.getDisplayName());

        if (compareTo == 0 && this.fieldName != null && o.getFieldName() != null)
            compareTo = this.fieldName.compareTo(o.getFieldName());

        if (compareTo == 0 && this.hasGroupFieldName() && o.hasGroupFieldName())
            compareTo = 1;

        return compareTo;
    }

}

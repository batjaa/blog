package com.khanbank.cpms.excel;

import com.khanbank.cpms.excel.SheetAbstractCellView.SheetReadType;
import com.khanbank.cpms.excel.template.TemplateField;

public interface SheetCellView {

    String getKey();

    TemplateField getTemplate();

    SheetReadType getReadType();

    boolean anyMatchKey(String key);

    boolean anyMatchType(SheetReadType readType);

}

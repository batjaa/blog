package com.khanbank.cpms.security;

public class AccessExpressions {

    public final static String PROJECT_ACCESS = "@restSecurity.verifyProjectRequest(authentication, #id)";

    public final static String COMPANY_DELETE_INVALID = "@restSecurity.verifyCompanyDeleteRequest(#id)";
}

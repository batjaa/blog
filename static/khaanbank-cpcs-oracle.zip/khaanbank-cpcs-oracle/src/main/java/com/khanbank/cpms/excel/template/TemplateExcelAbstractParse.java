package com.khanbank.cpms.excel.template;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import com.khanbank.cpms.excel.SheetCellView;

public abstract class TemplateExcelAbstractParse implements TemplateExcelParse {
    private InputStream inputStream;

    private boolean lockedGroupSheet = false;

    private List<SheetCellView> sheetCellViews = new ArrayList<SheetCellView>();

    private Class<?> mapperType;

    public TemplateExcelAbstractParse(InputStream inputStream, Class<?> mapperType) {
        this.inputStream = inputStream;
        this.mapperType = mapperType;
    }

    @Override
    public InputStream getInputStream() {
        return inputStream;
    }

    public void setInputStream(InputStream inputStream) {
        this.inputStream = inputStream;
    }

    @Override
    public boolean isLockedGroupSheet() {
        return lockedGroupSheet;
    }

    public void setLockedGroupSheet(boolean lockedTabGroup) {
        this.lockedGroupSheet = lockedTabGroup;
    }

    @Override
    public List<SheetCellView> getSheetCellViews() {
        return sheetCellViews;
    }

    public void setSheetCellViews(List<SheetCellView> sheetColumn) {
        this.sheetCellViews = sheetColumn;
    }

    @Override
    public Class<?> getMapperType() {
        return mapperType;
    }

    public void setMapperType(Class<?> mapperType) {
        this.mapperType = mapperType;
    }

}

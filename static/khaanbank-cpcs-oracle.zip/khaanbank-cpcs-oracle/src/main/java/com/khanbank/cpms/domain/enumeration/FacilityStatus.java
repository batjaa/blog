package com.khanbank.cpms.domain.enumeration;

/**
 * The FacilityStatus enumeration.
 */
public enum FacilityStatus {
    TO_BE_PURCHASED("Захиалга аваагүй"), ORDER_RECEIVED("Захиалга авсан"), PURCHASED("Зарагдсан"), BARTERED("Бартер");

    private String text;

	private FacilityStatus(String text) {
		this.setText(text);
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	@Override
	public String toString() {
		return text;
	}
}

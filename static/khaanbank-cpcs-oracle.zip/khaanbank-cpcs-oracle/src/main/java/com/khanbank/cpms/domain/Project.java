package com.khanbank.cpms.domain;

import java.time.Instant;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.khanbank.cpms.domain.enumeration.ProjectStatus;
import com.khanbank.cpms.excel.anno.SheetRow;
import com.khanbank.cpms.excel.enumeration.SheetCellFormat;
import com.khanbank.cpms.excel.enumeration.SheetRowType;
import com.khanbank.cpms.excel.enumeration.SheetRowValue;

/**
 * A Project.
 */
@Entity
@Table(name = "project")
public class Project extends AbstractAuditingEntity {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    @Column(name = "name", nullable = false)
    private String name;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false)
    private ProjectStatus status;

    @SheetRow(mergedRowNumbers = {
            11, 12
    }, firstColumn = 6, valueType = SheetRowValue.LAST_DATE, format = SheetCellFormat.YEAR_DATE, columnType = SheetRowType.MERGED)
    @Column(name = "due_date")
    private Instant dueDate;

    @SheetRow(mergedRowNumbers = {
            11, 12
    }, firstColumn = 6, valueType = SheetRowValue.LAST_VALUE, format = SheetCellFormat.YEAR_DATE, columnType = SheetRowType.MERGED)
    @Column(name = "loan_amount")
    private Long loanAmount;

    @Column(name = "grants_open_until")
    private Instant grantsOpenUntil;

    @Column(name = "users")
    private String users;

    @CreatedBy
    @Column(name = "created_by", nullable = false)
    private String createdBy;

    @LastModifiedBy
    @Column(name = "updated_by", nullable = false)
    private String updatedBy;

    @LastModifiedDate
    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;

    @CreatedDate
    @Column(name = "created_at", nullable = false)
    private Instant createdAt;

    @ManyToOne
    @JsonIgnoreProperties("projects")
    private Company company;

    @OneToOne(mappedBy = "project", cascade = CascadeType.ALL)
    @JsonIgnore
    private ProjectCostEstimate projectCostEstimate;

    @OneToMany(mappedBy = "project", cascade = CascadeType.ALL)
    private Set<Grant> grants;

    @OneToMany(mappedBy = "project", cascade = CascadeType.ALL)
    private Set<Building> buildings = new HashSet<>();

    @OneToMany(mappedBy = "project", cascade = CascadeType.ALL)
    private Set<Compliance> compliances = new HashSet<>();

    @OneToMany(mappedBy = "project", cascade = CascadeType.ALL)
    private Set<EngineerAssessment> engineerAssessments = new HashSet<>();

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public Project name(String name) {
        this.name = name;
        return this;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ProjectStatus getStatus() {
        return status;
    }

    public Project status(ProjectStatus status) {
        this.status = status;
        return this;
    }

    public void setStatus(ProjectStatus status) {
        this.status = status;
    }

    public Instant getDueDate() {
        return dueDate;
    }

    public Project dueDate(Instant dueDate) {
        this.dueDate = dueDate;
        return this;
    }

    public void setDueDate(Instant dueDate) {
        this.dueDate = dueDate;
    }

    public Long getLoanAmount() {
        return loanAmount;
    }

    public Project loanAmount(Long loanAmount) {
        this.loanAmount = loanAmount;
        return this;
    }

    public void setLoanAmount(Long loanAmount) {
        this.loanAmount = loanAmount;
    }

    public Instant getGrantsOpenUntil() {
        return grantsOpenUntil;
    }

    public Project grantsOpenUntil(Instant grantsOpenUntil) {
        this.grantsOpenUntil = grantsOpenUntil;
        return this;
    }

    public void setGrantsOpenUntil(Instant grantsOpenUntil) {
        this.grantsOpenUntil = grantsOpenUntil;
    }

    public String getUsers() {
        return users;
    }

    public Project users(String users) {
        this.users = users;
        return this;
    }

    public void setUsers(String users) {
        this.users = users;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public Project createdBy(String createdBy) {
        this.createdBy = createdBy;
        return this;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public Project updatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
        return this;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Instant getUpdatedAt() {
        return updatedAt;
    }

    public Project updatedAt(Instant updatedAt) {
        this.updatedAt = updatedAt;
        return this;
    }

    public void setUpdatedAt(Instant updatedAt) {
        this.updatedAt = updatedAt;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public Project createdAt(Instant createdAt) {
        this.createdAt = createdAt;
        return this;
    }

    public void setCreatedAt(Instant createdAt) {
        this.createdAt = createdAt;
    }

    public Company getCompany() {
        return company;
    }

    public Project company(Company company) {
        this.company = company;
        return this;
    }

    public void setCompany(Company company) {
        this.company = company;
    }

    public ProjectCostEstimate getProjectCostEstimate() {
        return projectCostEstimate;
    }

    public Project projectCostEstimate(ProjectCostEstimate projectCostEstimate) {
        this.projectCostEstimate = projectCostEstimate;
        return this;
    }

    public void setProjectCostEstimate(ProjectCostEstimate projectCostEstimate) {
        this.projectCostEstimate = projectCostEstimate;
    }

    public Set<Grant> getGrants() {
        return grants;
    }

    public void setGrants(Set<Grant> grant) {
        this.grants = grant;
    }

    public Set<Building> getBuildings() {
        return buildings;
    }

    public Project buildings(Set<Building> buildings) {
        this.buildings = buildings;
        return this;
    }

    public Project addBuilding(Building building) {
        this.buildings.add(building);
        building.setProject(this);
        return this;
    }

    public Project removeBuilding(Building building) {
        this.buildings.remove(building);
        building.setProject(null);
        return this;
    }

    public void setBuildings(Set<Building> buildings) {
        this.buildings = buildings;
    }

    public Set<Compliance> getCompliances() {
        return compliances;
    }

    public Project compliances(Set<Compliance> compliances) {
        this.compliances = compliances;
        return this;
    }

    public Project addCompliances(Compliance compliance) {
        this.compliances.add(compliance);
        compliance.setProject(this);
        return this;
    }

    public Project removeCompliances(Compliance compliance) {
        this.compliances.remove(compliance);
        compliance.setProject(null);
        return this;
    }

    public void setCompliances(Set<Compliance> compliances) {
        this.compliances = compliances;
    }

    public Set<EngineerAssessment> getEngineerAssessments() {
        return engineerAssessments;
    }

    public Project engineerAssessments(Set<EngineerAssessment> engineerAssessments) {
        this.engineerAssessments = engineerAssessments;
        return this;
    }

    public Project addEngineerAssessments(EngineerAssessment engineerAssessment) {
        this.engineerAssessments.add(engineerAssessment);
        engineerAssessment.setProject(this);
        return this;
    }

    public Project removeEngineerAssessments(EngineerAssessment engineerAssessment) {
        this.engineerAssessments.remove(engineerAssessment);
        engineerAssessment.setProject(null);
        return this;
    }

    public void setEngineerAssessments(Set<EngineerAssessment> engineerAssessments) {
        this.engineerAssessments = engineerAssessments;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Project)) {
            return false;
        }
        return id != null && id.equals(((Project) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return "Project{" + "id=" + getId() + ", name='" + getName() + "'" + ", status='" + getStatus() + "'"
                + ", dueDate='" + getDueDate() + "'" + ", loanAmount=" + getLoanAmount() + ", grantsOpenUntil='"
                + getGrantsOpenUntil() + "'" + ", users='" + getUsers() + "'" + ", createdBy='" + getCreatedBy() + "'"
                + ", updatedBy='" + getUpdatedBy() + "'" + ", updatedAt='" + getUpdatedAt() + "'" + ", createdAt='"
                + getCreatedAt() + "'" + "}";
    }
}

package com.khanbank.cpms.domain;

import java.time.Instant;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.khanbank.cpms.domain.enumeration.ComplianceType;

/**
 * A Compliance.
 */
@Entity
@Table(name = "compliance")
public class Compliance extends AbstractAuditingEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Lob
	@Column(name = "notes")
	private String notes;

	@Column(name = "due_date")
	private Date dueDate;

	@NotNull
	@Enumerated(EnumType.STRING)
	@Column(name = "jhi_type", nullable = false)
	private ComplianceType type;

	@CreatedBy
	@Column(name = "created_by", nullable = false)
	private String createdBy;

	@LastModifiedBy
	@Column(name = "updated_by", nullable = false)
	private String updatedBy;

	@LastModifiedDate
	@Column(name = "updated_at", nullable = false)
	private Instant updatedAt;

	@CreatedDate
	@Column(name = "created_at", nullable = false)
	private Instant createdAt;

	@NotNull
	@OneToOne
	@JoinColumn(unique = true)
	private File file;

	@ManyToOne
	@JsonIgnoreProperties("compliances")
	private Project project;

	// jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNotes() {
		return notes;
	}

	public Compliance notes(String notes) {
		this.notes = notes;
		return this;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public Date getDueDate() {
		return dueDate;
	}

	public Compliance dueDate(Date dueDate) {
		this.dueDate = dueDate;
		return this;
	}

	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}

	public ComplianceType getType() {
		return type;
	}

	public Compliance type(ComplianceType type) {
		this.type = type;
		return this;
	}

	public void setType(ComplianceType type) {
		this.type = type;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public Compliance createdBy(String createdBy) {
		this.createdBy = createdBy;
		return this;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public Compliance updatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
		return this;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Instant getUpdatedAt() {
		return updatedAt;
	}

	public Compliance updatedAt(Instant updatedAt) {
		this.updatedAt = updatedAt;
		return this;
	}

	public void setUpdatedAt(Instant updatedAt) {
		this.updatedAt = updatedAt;
	}

	public Instant getCreatedAt() {
		return createdAt;
	}

	public Compliance createdAt(Instant createdAt) {
		this.createdAt = createdAt;
		return this;
	}

	public void setCreatedAt(Instant createdAt) {
		this.createdAt = createdAt;
	}

	public File getFile() {
		return file;
	}

	public Compliance file(File file) {
		this.file = file;
		return this;
	}

	public void setFile(File file) {
		this.file = file;
	}

	public Project getProject() {
		return project;
	}

	public Compliance project(Project project) {
		this.project = project;
		return this;
	}

	public void setProject(Project project) {
		this.project = project;
	}
	// jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (!(o instanceof Compliance)) {
			return false;
		}
		return id != null && id.equals(((Compliance) o).id);
	}

	@Override
	public int hashCode() {
		return 31;
	}

	@Override
	public String toString() {
		return "Compliance{" + "id=" + getId() + ", notes='" + getNotes() + "'" + ", dueDate='" + getDueDate() + "'" + ", type='" + getType() + "'" + ", createdBy='" + getCreatedBy() + "'"
				+ ", updatedBy='" + getUpdatedBy() + "'" + ", updatedAt='" + getUpdatedAt() + "'" + ", createdAt='" + getCreatedAt() + "'" + "}";
	}
}
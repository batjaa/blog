package com.khanbank.cpms.domain.enumeration;

/**
 * The ReleaseStatus enumeration.
 */
public enum ReleaseStatus {
    NOT_RELEASED, PURCHASED_BY_FINANCING, PURCHASED_BY_CASH, BARTERED, OTHER
}

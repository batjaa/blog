package com.khanbank.cpms.repository;

import org.springframework.stereotype.Repository;

import com.khanbank.cpms.domain.Notification;

/**
 * Spring Data repository for the Notification entity.
 */
@Repository
public interface NotificationRepository extends BaseSpecRespository<Notification, Long> {

}

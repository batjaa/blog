package com.khanbank.cpms.service.util;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.khanbank.cpms.excel.SheetData;
import com.khanbank.cpms.excel.SheetRowData;
import com.khanbank.cpms.excel.template.GroupTemplate;
import com.khanbank.cpms.excel.template.TemplateField;
import com.khanbank.cpms.service.param.JsonNodeParam;
import com.khanbank.cpms.web.rest.errors.BadRequestAlertException;

public class JsonUtil {

    @SuppressWarnings("unchecked")
    public static <T> T parseObjectNodeToObject(ObjectNode objectNode, Class<T> entityClass, String... removeNodeNames) throws BadRequestAlertException {
        T result = null;

        for (String name : removeNodeNames) {
            if (objectNode.has(name))
                objectNode.remove(name);
        }

        try {
            result = (T) JsonUtil.parseMapperJsonNodeToObject(objectNode, entityClass);
        } catch (Exception e) {
            throw new BadRequestAlertException(e.getMessage(), entityClass.getSimpleName(), "idexists");
        }

        return result;
    }

    public static List<Object> parseMapperJsonNodesToObjects(List<JsonNodeParam> jsonNodeParams) throws Exception {
        List<Object> parseObjects = new ArrayList<>();

        for (JsonNodeParam nodeParam : jsonNodeParams) {
            Object object = parseMapperJsonNodeToObject(nodeParam);
            parseObjects.add(object);
        }

        return parseObjects;
    }

    private static Object parseMapperJsonNodeToObject(JsonNode node, Class<?> entityClass) throws Exception {
        JsonNodeParam param = new JsonNodeParam(node, entityClass);
        return parseMapperJsonNodeToObject(param);
    }

    public static Object parseMapperJsonNodeToObject(JsonNodeParam jsonNodeParam) throws Exception {

        JsonNode jsonNode = jsonNodeParam.getJsonNode();

        Class<?> entityClass = jsonNodeParam.getEntityClass();

        String jsonResult = parseMapperJsonNodeToString(jsonNode);

        Object result = parseMapperStringToObject(jsonResult, entityClass);

        return result;
    }

    private static Object parseMapperStringToObject(String jsonContent, Class<?> entityClass) throws Exception {
        ObjectMapper jsonMapper = new ObjectMapper();

        jsonMapper.registerModule(new JavaTimeModule());

        Object result = jsonMapper.readValue(jsonContent, entityClass);

        return result;
    }

    public static List<JsonNodeParam> parseMapperJsonNodes(List<SheetData> sheetDatas) throws Exception {
        List<JsonNodeParam> parseJsonNodeParams = new ArrayList<>();

        for (SheetData sheetData : sheetDatas) {
            JsonNodeParam jsonNodeParam = parseMapperJsonNode(sheetData);
            parseJsonNodeParams.add(jsonNodeParam);
        }

        return parseJsonNodeParams;
    }

    public static JsonNodeParam parseMapperJsonNode(SheetData sheetData) throws Exception {

        if (sheetData == null)
            throw new Exception("FileParser parameter null байна.");

        ObjectMapper jsonMapper = new ObjectMapper();

        JsonNodeParam jsonNodeParam = parseJsonNode(sheetData, jsonMapper);

        return jsonNodeParam;
    }

    public static String parseMapperJsonNodeToString(JsonNode jsonNode) throws Exception {

        if (jsonNode == null)
            throw new Exception("JsonNodeParam parameter null байна.");

        ObjectMapper jsonMapper = new ObjectMapper();

        jsonMapper.registerModule(new JavaTimeModule());

        String jsonResult = jsonMapper.writeValueAsString(jsonNode);

        return jsonResult;

    }

    private static JsonNodeParam parseJsonNode(SheetData sheetData, ObjectMapper jsonMapper) throws Exception {

        if (jsonMapper == null)
            jsonMapper = new ObjectMapper();

        Class<?> entityClass = sheetData.getEntityClass();

        if (entityClass == null)
            throw new Exception("Entity class null байна.");

        ObjectNode contentNode = jsonMapper.createObjectNode();

        JsonNodeParam resultJsonParam = new JsonNodeParam(contentNode, entityClass);

        List<SheetRowData> sheetRowDatas = sheetData.getSheetRowDatas();

        for (SheetRowData sheetRowData : sheetRowDatas) {

            List<TemplateField> docFields = sheetRowData.getDocumentFields();

            if (docFields == null || docFields.isEmpty())
                throw new Exception("Document fields null байна.");

            for (TemplateField docField : docFields) {
                buildDocFieldToObjectNode(docField, jsonMapper, contentNode, entityClass);
            }

        }

        String jsonAsString = jsonMapper.writeValueAsString(contentNode);
        System.out.println(jsonAsString);

        return resultJsonParam;
    }

    private static void buildDocFieldToObjectNode(TemplateField docField, ObjectMapper jsonMapper, ObjectNode contentNode, Class<?> entityClass) {
        String fieldName = docField.getFieldName();
        Object value = docField.getValue();
        Class<?> contentClass = docField.getContentClass();
        boolean firstEntity = entityClass.equals(contentClass);
        String bEntityName = ReflectionUtil.firstChatToLowercase(contentClass.getSimpleName());

        boolean hasParentClass = docField.hasParentClass();

        Class<?> parentClass = docField.getParentClass();

        if (docField.isCollection() && hasParentClass) {
            firstEntity = entityClass.equals(parentClass);
            bEntityName = ReflectionUtil.firstChatToLowercase(parentClass.getSimpleName());
        }

        ObjectNode objectNode = firstEntity ? contentNode : (ObjectNode) contentNode.get(bEntityName);

        if (objectNode == null) {
            objectNode = jsonMapper.createObjectNode();
            contentNode.set(bEntityName, objectNode);
        }

        if (docField.isCollection()) {

            String collectionName = fieldName;
            ArrayNode collectNode = (ArrayNode) objectNode.get(collectionName);

            if (collectNode == null) {
                collectNode = jsonMapper.createArrayNode();
                objectNode.set(collectionName, collectNode);
            }

            objectNode = jsonMapper.createObjectNode();
            collectNode.add(objectNode);
        }

        if (docField instanceof GroupTemplate) {
            GroupTemplate groupDocField = (GroupTemplate) docField;
            for (TemplateField child : groupDocField.getChildTemplate()) {
                if (contentClass.equals(child.getParentClass()) || child.isCollection()) {
                    buildDocFieldToObjectNode(child, jsonMapper, objectNode, contentClass);
                }

                else
                    objectNode.putPOJO(child.getFieldName(), child.getValue());
            }
        }

        else {
            objectNode.putPOJO(fieldName, value);
        }
    }
}

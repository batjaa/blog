package com.khanbank.cpms.domain.enumeration;

/**
 * The PaymentTerm enumeration.
 */
public enum PaymentTerm {
    FINANCED_BY_KHAANBANK("ХААН Банкны зээл"), FINANCED_BY_OTHER("Бусад Банкны зээл"), CASH("Бэлэн");

    private String text;

	private PaymentTerm(String text) {
		this.setText(text);
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	@Override
	public String toString() {
		return text;
	}
}

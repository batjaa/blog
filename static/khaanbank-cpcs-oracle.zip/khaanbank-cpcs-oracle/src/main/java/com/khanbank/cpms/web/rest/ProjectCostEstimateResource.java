package com.khanbank.cpms.web.rest;

import java.net.URISyntaxException;
import java.util.Optional;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.khanbank.cpms.domain.ProjectCostEstimate;
import com.khanbank.cpms.repository.ProjectCostEstimateRepository;
import com.khanbank.cpms.service.util.HelperUtil;

import io.github.jhipster.web.util.HeaderUtil;

/**
 * REST controller for managing {@link com.khanbank.cpms.domain.ProjectCostEstimate}.
 */
@RestController
@RequestMapping("/api")
public class ProjectCostEstimateResource {

    private final Logger log = LoggerFactory.getLogger(ProjectCostEstimateResource.class);

    private static final String ENTITY_NAME = "projectCostEstimate";

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final ProjectCostEstimateRepository projectCostEstimateRepository;

    public ProjectCostEstimateResource(ProjectCostEstimateRepository projectCostEstimateRepository) {
        this.projectCostEstimateRepository = projectCostEstimateRepository;
    }

    /**
     * {@code PUT  /project-cost-estimates} : Updates an existing projectCostEstimate.
     *
     * @param projectCostEstimate
     *            the projectCostEstimate to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated projectCostEstimate, or with status {@code 400 (Bad Request)} if the projectCostEstimate is not valid,
     *         or with status {@code 500 (Internal Server Error)} if the projectCostEstimate couldn't be updated.
     * @throws URISyntaxException
     *             if the Location URI syntax is incorrect.
     */
    @PutMapping("/project-cost-estimates")
    public ResponseEntity<ProjectCostEstimate> updateProjectCostEstimate(
            @Valid @RequestBody ProjectCostEstimate projectCostEstimate) throws URISyntaxException {
        log.debug("REST request to update ProjectCostEstimate : {}", projectCostEstimate);

        Optional<ProjectCostEstimate> optOldCostEstimate = projectCostEstimateRepository
                .findById(projectCostEstimate.getId());

        boolean updateEntity = HelperUtil.updateObjectRequiredFields(optOldCostEstimate, projectCostEstimate,
                "project");

        if (!updateEntity)
            return ResponseEntity.badRequest().build();

        ProjectCostEstimate result = projectCostEstimateRepository.save(projectCostEstimate);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityUpdateAlert(applicationName, true, ENTITY_NAME,
                projectCostEstimate.getId().toString())).body(result);
    }

    /**
     * {@code DELETE  /project-cost-estimates/:id} : delete the "id" projectCostEstimate.
     *
     * @param id
     *            the id of the projectCostEstimate to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/project-cost-estimates/{id}")
    public ResponseEntity<Void> deleteProjectCostEstimate(@PathVariable Long id) {
        log.debug("REST request to delete ProjectCostEstimate : {}", id);
        projectCostEstimateRepository.deleteById(id);
        return ResponseEntity.noContent()
                .headers(HeaderUtil.createEntityDeletionAlert(applicationName, true, ENTITY_NAME, id.toString()))
                .build();
    }
}

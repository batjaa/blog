package com.khanbank.cpms.excel.template;

import java.io.InputStream;

public class TemplateExcelEntityParse extends TemplateExcelAbstractParse {

    public TemplateExcelEntityParse(InputStream inputStream, boolean lockedGroupSheet, Class<?> mapperType) {
        super(inputStream, mapperType);
        this.setLockedGroupSheet(lockedGroupSheet);
    }

}

package com.khanbank.cpms.web.rest.errors;

public class ErrorResponseCodes {

    public final static String PROJECT_NOT_FOUND = "PR0001";
    public final static String PROJECT_COST_SUBMIT_NOT_ALLOWED = "PR0002";
    public final static String REQUIRED_FIELDS_MISSING = "PR0003";
    public final static String PROJECT_NOT_DELETED = "PR0004";

}

package com.khanbank.cpms.web.rest.spec;

import java.time.Instant;

import com.khanbank.cpms.service.util.CalendarUtil;

public interface InstantConverter {

    @SuppressWarnings("unchecked")
    default <Y extends Comparable<? super Y>> Y makePredicatedValueConverter(Y y) {

        Instant date = CalendarUtil.parseToInstant("" + y);

        if (date != null)
            y = (Y) date;
        
        return y;
    }

}

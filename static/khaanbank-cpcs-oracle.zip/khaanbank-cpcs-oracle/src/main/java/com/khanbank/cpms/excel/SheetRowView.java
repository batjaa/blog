package com.khanbank.cpms.excel;

import com.khanbank.cpms.excel.anno.SheetRow;
import com.khanbank.cpms.excel.enumeration.SheetCellFormat;
import com.khanbank.cpms.excel.enumeration.SheetRowType;
import com.khanbank.cpms.excel.enumeration.SheetRowValue;

public class SheetRowView extends SheetAbstractCellView {
    private int firstColumn = -1;
    private int lastColumn = -1;
    private int sheetRowIndex = -1;
    private int sheetLastCellIndex = -1;
    private int[] mergedRowNumbers = {};

    private Object templateDefaultValue;
    private SheetCellFormat format = SheetCellFormat.NONE;
    private SheetRowType columnType = SheetRowType.NONE;
    private SheetRowValue rowValueType = SheetRowValue.CURRENT;

    public SheetRowView(String key, SheetCellFormat columnFormat, SheetRowType columnType, SheetRowValue rowValueType) {
        super(key, SheetReadType.ROW);
        this.format = columnFormat;
        this.columnType = columnType;
        this.rowValueType = rowValueType;
    }

    public SheetRowView(SheetRow sheetRow) {
        this(sheetRow.key(), sheetRow.format(), sheetRow.columnType(), sheetRow.valueType());

        this.firstColumn = sheetRow.firstColumn();
        this.lastColumn = sheetRow.lastColumn();
        this.mergedRowNumbers = sheetRow.mergedRowNumbers();

    }

    public SheetCellFormat getFormat() {
        return format;
    }

    public void setFormat(SheetCellFormat cellFormat) {
        this.format = cellFormat;
    }

    public SheetRowType getColumnType() {
        return columnType;
    }

    public void setColumnType(SheetRowType columnType) {
        this.columnType = columnType;
    }

    public boolean hasMergedRowNumbers() {
        return mergedRowNumbers != null && mergedRowNumbers.length > 0;
    }

    public int getFirstColumn() {
        return firstColumn;
    }

    public void setFirstColumn(int firstColumnIndex) {
        this.firstColumn = firstColumnIndex;
    }

    public int getLastColumn() {
        return lastColumn;
    }

    public void setLastColumn(int lastColumnIndex) {
        this.lastColumn = lastColumnIndex;
    }

    public int[] getMergedRowNumbers() {
        return mergedRowNumbers;
    }

    public void setMergedRowNumbers(int[] rowNumbers) {
        this.mergedRowNumbers = rowNumbers;
    }

    public int getSheetRowIndex() {
        return sheetRowIndex;
    }

    public void setSheetRowIndex(int sheetRowIndex) {
        this.sheetRowIndex = sheetRowIndex;
    }

    public Object getTemplateDefaultValue() {
        return templateDefaultValue;
    }

    public void setTemplateDefaultValue(Object defualtValue) {
        this.templateDefaultValue = defualtValue;
    }

    public int getSheetLastCellIndex() {
        return sheetLastCellIndex;
    }

    public void setSheetLastCellIndex(int sheetLastCellIndex) {
        this.sheetLastCellIndex = sheetLastCellIndex;
    }

    public SheetRowValue getRowValueType() {
        return rowValueType;
    }

    public void setRowValueType(SheetRowValue rowValueType) {
        this.rowValueType = rowValueType;
    }

}

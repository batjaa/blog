package com.khanbank.cpms.excel;

import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.util.CellAddress;
import org.apache.poi.ss.util.CellRangeAddress;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.khanbank.cpms.excel.SheetAbstractCellView.SheetReadType;
import com.khanbank.cpms.excel.enumeration.SheetCellFormat;
import com.khanbank.cpms.excel.enumeration.SheetRowValue;
import com.khanbank.cpms.excel.exception.TemplateException;
import com.khanbank.cpms.excel.template.GroupTemplate;
import com.khanbank.cpms.excel.template.TemplateExcelAbstractParse;
import com.khanbank.cpms.excel.template.TemplateField;
import com.khanbank.cpms.service.util.CalendarUtil;
import com.khanbank.cpms.service.util.ReflectionUtil;

public class ExcelSheetParser {

    private final Logger logger = LoggerFactory.getLogger(ExcelSheetParser.class);
    private static final String SHEET_NAME = "SHEET_NAME";

    private Class<?> mapperType;
    private InputStream inputStream;

    private List<SheetRowView> rowViews;
    private List<SheetColumnView> columnViews;

    private List<String> requiredFields;
    private Map<String, Object> mergedValues;

    private Map<Integer, TemplateField> templates;
    private List<CellRangeAddress> allCellMergedRegions;

    private boolean lockedGroupSheet;

    private List<SheetData> sheetDatas = new ArrayList<>();

    public ExcelSheetParser(TemplateExcelAbstractParse templateExcelParse) throws Exception {

        this.mapperType = templateExcelParse.getMapperType();
        this.inputStream = templateExcelParse.getInputStream();
        this.lockedGroupSheet = templateExcelParse.isLockedGroupSheet();

        if (inputStream == null || inputStream.available() <= 0)
            throw new Exception("Таны өгсөн excel file байхгүй байна олдсонгүй !!!");

        List<SheetCellView> sheetCellViews = templateExcelParse.getSheetCellViews();

        rowViews = sheetCellViews.stream().filter(sheetCel -> sheetCel.anyMatchType(SheetReadType.ROW))
                .map(SheetRowView.class::cast).collect(Collectors.toList());

        columnViews = sheetCellViews.stream().filter(sheetCel -> sheetCel.anyMatchType(SheetReadType.COL))
                .map(SheetColumnView.class::cast).collect(Collectors.toList());

        mergedValues = new LinkedHashMap<>();

        templates = new LinkedHashMap<Integer, TemplateField>();

        sheetDatas = buildSheets(inputStream);
    }

    private List<SheetData> buildSheets(InputStream inputStream) throws EncryptedDocumentException, IOException {

        List<SheetData> sheetDatas = new ArrayList<>();

        Workbook workBook = WorkbookFactory.create(inputStream);

        Iterator<Sheet> iterator = workBook.iterator();
        while (iterator.hasNext()) {

            Sheet sheet = iterator.next();

            logger.debug("Force parse Sheet Data : {}", sheet.getSheetName());

            // Нэгдсэн хүснэгтийн утагууд
            allCellMergedRegions = sheet.getMergedRegions();

            SheetData rowSheetData = buildRowSheetDatas(sheet);

            SheetData colSheetData = buildColSheetDatas(sheet);

            if (!rowSheetData.isSheetRowData() && !colSheetData.isSheetRowData())
                continue;

            if (rowSheetData.isSheetRowData())
                sheetDatas.add(rowSheetData);

            if (colSheetData.isSheetRowData())
                sheetDatas.add(colSheetData);

        }

        return sheetDatas;
    }

    private SheetData buildColSheetDatas(Sheet sheet) {

        SheetData sheetData = new SheetData(mapperType);

        if (columnViews.isEmpty())
            return sheetData;

        String sheetName = sheet.getSheetName();

        SheetColumnView sheetColumn = columnViews.stream().filter(t -> t.anyMatchKey(SHEET_NAME)).findFirst()
                .orElse(null);

        if (!lockedGroupSheet && sheetColumn != null) {

            TemplateField docField = null;

            try {
                docField = buildTemplate(sheetColumn.getTemplate(), sheetName);
                SheetRowData rowData = new SheetRowData(-1, Arrays.asList(docField));
                sheetData.addSheetRowData(rowData);
            } catch (TemplateException e) {
                sheetData.addErrorMessage(e.getMessage());
            }

        }

        long requiredCount = columnViews.stream().filter(t -> !t.anyMatchKey(SHEET_NAME) && t.isRequired()).count();

        // Нийт мөр
        Iterator<Row> rows = sheet.rowIterator();

        while (rows.hasNext()) {

            requiredFields = new ArrayList<String>();

            Row row = rows.next();

            int rowNum = row.getRowNum();

            // үүсгэсэн тemplate үүд цэвэрлэх
            if (columnViews.size() > row.getPhysicalNumberOfCells())
                continue;

            List<TemplateField> templates = buildRow(row, sheetData);

            if (templates.isEmpty())
                continue;

            long requiredCountDoc = requiredFields.size();

            if (requiredCount > 0 && requiredCount > requiredCountDoc)
                continue;

            List<TemplateField> removeFields = new ArrayList<>();
            List<TemplateField> convertGroupFields = templates.stream().filter(TemplateField::hasGroupFieldName)
                    .collect(Collectors.toList());
            convertGroupFields.forEach(docField -> definitionGroupFields(docField, templates, removeFields));
            templates.removeAll(removeFields);

            SheetRowData sheetRowData = new SheetRowData(rowNum + 1, templates);
            sheetData.addSheetRowData(sheetRowData);
        }

        return sheetData;
    }

    private SheetData buildRowSheetDatas(Sheet sheet) {

        SheetData sheetData = new SheetData(mapperType);
        sheetData.setName(sheet.getSheetName());
        sheetData.setFromCell("A1");

        if (rowViews.isEmpty())
            return sheetData;

        buildSheetColumnMergedChild(sheet);

        for (SheetRowView rowView : rowViews) {
            SheetRowValue rowValueType = rowView.getRowValueType();

            Object templateDefaultValue = rowView.getTemplateDefaultValue();
            Object value = templateDefaultValue;
            int sheetRowIndex = rowView.getSheetRowIndex();
            int sheetLastCellIndex = rowView.getSheetLastCellIndex();
            Cell lastCell = null;

            if (sheetRowIndex >= 0 && sheetLastCellIndex >= 0) {
                Row row = sheet.getRow(sheetRowIndex);

                if (row == null)
                    continue;

                lastCell = row.getCell(sheetLastCellIndex);

                if (lastCell == null)
                    continue;

                CellAddress address = lastCell.getAddress();

                sheetData.setToCell(address.formatAsString());
            }

            if (lastCell != null && rowValueType.equals(SheetRowValue.LAST_VALUE)) {
                value = lastCell.getNumericCellValue();
            }

            TemplateField template = null;

            try {
                template = buildTemplate(rowView.getTemplate(), value);
                SheetRowData sheetRowData = new SheetRowData(sheetRowIndex + 1, Arrays.asList(template));
                sheetData.addSheetRowData(sheetRowData);
            } catch (TemplateException e) {
                sheetData.addErrorMessage(e.getMessage());
            }

            // clean row view numbers
            rowView.setSheetRowIndex(-1);
            rowView.setSheetLastCellIndex(-1);
            rowView.setLastColumn(-1);
        }

        return sheetData;

    }

    private Stream<CellRangeAddress> getMergedColumnsFilter(Predicate<CellRangeAddress> predicate) {
        return allCellMergedRegions.stream().filter(predicate);
    }

    private List<TemplateField> buildRow(Row row, SheetData sheetData) {

        List<TemplateField> docFields = new ArrayList<>();

        Iterator<Cell> cells = row.cellIterator();

        // мөрний хүснэгтээр гүйх
        while (cells.hasNext()) {
            Cell cell = cells.next();

            boolean updateTemplates = updateSheetColumn(cell);

            if (updateTemplates)
                continue;

            TemplateField docField = null;

            try {
                docField = buildCell(cell);
            } catch (TemplateException e) {
                sheetData.addErrorMessage(e.getMessage());
            }

            if (docField == null)
                continue;

            if (docField.isRequired())
                requiredFields.add(docField.getFieldName());

            docFields.add(docField);
        }

        return docFields;
    }

    private void buildSheetColumnMergedChild(Sheet sheet) {

        for (SheetRowView rowView : rowViews) {

            Map<String, String> mergedValues = getMergedValues(sheet, rowView);

            if (mergedValues.isEmpty())
                continue;

            SheetRowValue rowValueType = rowView.getRowValueType();
            int mergedSize = mergedValues.size();
            int firstColumnIndex = rowView.getFirstColumn();
            int sheetLastCellIndex = firstColumnIndex + mergedSize;

            if (rowValueType.equals(SheetRowValue.LAST_DATE)) {
                String dateValue = mergedValues.get(sheetLastCellIndex - 1 + "");
                Instant lastDate = CalendarUtil.parseToInstant(dateValue);
                rowView.setTemplateDefaultValue(lastDate);
                continue;
            }

            SheetCellFormat columnFormat = rowView.getFormat();

            String format = columnFormat.getFormat();
            String formatValue = null;

            if (columnFormat.equals(SheetCellFormat.YEAR_DATE))
                formatValue = new SimpleDateFormat(format).format(Date.from(Instant.now()));

            for (Entry<String, String> entry : mergedValues.entrySet()) {
                String key = entry.getKey();

                // no number ignored
                if (!key.matches("^[0-9]+$"))
                    continue;

                String value = entry.getValue();

                if (formatValue != null && formatValue.matches(value)) {
                    rowView.setLastColumn(Integer.parseInt(key));
                    break;
                }
            }

            if (rowValueType.equals(SheetRowValue.CURRENT)) {
                String value = mergedValues.get(rowView.getLastColumn() + "");
                rowView.setTemplateDefaultValue(value);
                continue;
            }

            List<Long> values = new ArrayList<>();
            int lastRowNum = sheet.getLastRowNum() - 1;

            while (lastRowNum > 0) {
                int columnIndex = rowView.getLastColumn();
                Row row = sheet.getRow(lastRowNum);
                lastRowNum--;

                if (row == null)
                    continue;

                boolean successLastRow = false;

                while (columnIndex >= firstColumnIndex) {

                    Cell cell = row.getCell(columnIndex);
                    columnIndex--;

                    if (cell == null && rowView.getLastColumn() == (columnIndex + 1))
                        break;

                    CellType cellType = cell.getCellType();

                    if (cellType.equals(CellType.FORMULA))
                        cellType = cell.getCachedFormulaResultType();

                    successLastRow = cellType.equals(CellType.NUMERIC);

                    if (successLastRow) {

                        Double cellValue = cell.getNumericCellValue();

                        if (cellValue == null || cellValue.longValue() == 0)
                            continue;

                        if (rowValueType.equals(SheetRowValue.SUM))
                            values.add(cellValue.longValue());
                    }

                    else
                        break;

                }

                if (successLastRow) {
                    rowView.setSheetRowIndex(row.getRowNum());
                    rowView.setSheetLastCellIndex(sheetLastCellIndex);
                    break;
                }

            }

            if (!values.isEmpty()) {

                Long cellTotal = 0l;

                for (Long cellValue : values)
                    cellTotal += cellValue;

                rowView.setTemplateDefaultValue(cellTotal);
            }

        }
    }

    private Map<String, String> getMergedValues(Sheet sheet, SheetRowView rowView) {

        SheetCellFormat columnFormat = rowView.getFormat();

        Map<String, String> mergedValues = new LinkedHashMap<>();

        for (int rowNumber : rowView.getMergedRowNumbers()) {
            Row row = sheet.getRow(rowNumber);

            if (row == null)
                continue;

            int columnIndex = rowView.getFirstColumn();

            short lastCellNum = row.getLastCellNum();

            if (columnIndex < 0)
                columnIndex = 0;

            while (columnIndex <= lastCellNum) {
                Cell cell = row.getCell(columnIndex);
                columnIndex++;

                if (cell == null)
                    continue;

                Object cellValue = getCellValue(String.class, cell);

                int cellIndex = cell.getColumnIndex();

                int firstColumn = getMergedColumnsFilter(f -> //
                f.getFirstRow() == rowNumber && //
                        f.getFirstColumn() != f.getLastColumn() && //
                        f.getFirstColumn() < cellIndex && f.getLastColumn() >= cellIndex)//
                                .map(CellRangeAddress::getFirstColumn).findFirst().orElse(-1);

                Entry<String, String> oldEntry = mergedValues.entrySet().stream()
                        .filter(k -> k.getKey().startsWith(firstColumn + "")).findFirst().orElse(null);

                if (oldEntry != null) {
                    String key = oldEntry.getKey();
                    String value = oldEntry.getValue();
                    mergedValues.remove(key);
                    mergedValues.put(key + "," + cellIndex, value);
                }

                if (cellValue == null)
                    continue;

                String columnKey = cellIndex + "";

                Entry<String, String> entry = mergedValues.entrySet().stream()
                        .filter(k -> k.getKey().contains(columnKey)).findFirst().orElse(null);

                String value = cellValue.toString();

                if (value.matches("[^0-9]+$") && columnFormat.equals(SheetCellFormat.YEAR_DATE))
                    continue;

                String subText = "";

                if (columnFormat.equals(SheetCellFormat.YEAR_DATE)) {
                    subText = "-";
                    value = value.replaceAll("\\s", "");
                    value = value.replaceAll("он", "-");
                    value = value.replaceAll("\\.\\d+$", "");
                    value = value.length() > 1 ? value : "0" + value;
                }

                if (entry == null) {
                    mergedValues.put(columnKey, value);
                }

                else {

                    String key = entry.getKey();
                    String oldValue = entry.getValue();
                    String newValue = oldValue + (oldValue.endsWith(subText) ? "" : subText) + value;
                    mergedValues.put(columnKey, newValue);

                    if (key.endsWith("," + columnKey)) {
                        mergedValues.remove(key);
                    }
                }

            }

        }

        return mergedValues;
    }

    private TemplateField buildCell(Cell cell) throws TemplateException {
        TemplateField result = null;
        int cellNumber = cell.getColumnIndex();
        int rowNumber = cell.getRowIndex();

        // Header биш мөрийн багана нэгдсэн байвал цуглуулах

        TemplateField template = templates.get(cellNumber);

        // template олдоогүй бол нэгдсэн хүснэгт эсэхийн шалгаж тийм бол үүссэн template авах
        if (template == null) {

            int firstColumn = getMergedColumnsFilter(f -> //
            f.getFirstRow() == rowNumber && //
                    f.getFirstColumn() != f.getLastColumn() && //
                    f.getFirstColumn() < cellNumber && f.getLastColumn() >= cellNumber)//
                            .map(CellRangeAddress::getFirstColumn).findFirst().orElse(-1);

            if (firstColumn >= 0)
                template = templates.get(firstColumn);
        }

        if (template == null)
            return null;

        Object cellValue = getCellValue(template.getType(), cell);

        if (cellValue == null) {
            int rowNum = getMergedColumnsFilter(f -> f.getLastRow() >= rowNumber && f.getFirstColumn() == cellNumber)
                    .map(CellRangeAddress::getFirstRow).findFirst().orElse(-1);
            String key = rowNum + "-" + cellNumber;
            cellValue = mergedValues.get(key);
        }

        result = buildTemplate(template, cellValue);

        // хоёр өөр мөрний ижил багана нэгдсэн байвал түүний утагийн авах
        CellRangeAddress cellRangeAddress = getMergedColumnsFilter(m -> //
        m.getFirstRow() == rowNumber && //
                m.getFirstRow() != m.getLastRow() && //
                m.getFirstColumn() == m.getLastColumn() && //
                m.getFirstColumn() == cellNumber).findFirst().orElse(null);

        if (cellRangeAddress != null)
            mergedValues.put(rowNumber + "-" + cellNumber, cellValue);

        return result;
    }

    /**
     * Group болгож ялгаж бэлдэх
     * 
     * @param docField
     * @param docFields
     * @param removeFields
     */
    private void definitionGroupFields(TemplateField docField, List<TemplateField> docFields,
            List<TemplateField> removeFields) {

        Class<?> contentClass = docField.getContentClass();

        // ижил contentClass тай агуулагч үүсэн эсэхийн мэдэх
        GroupTemplate groupDocField = docFields.stream().filter(f -> //
        f.getClass().equals(GroupTemplate.class)//
                && f.getContentClass().equals(contentClass))//
                .findFirst()//
                .map(GroupTemplate.class::cast).orElse(null);

        if (groupDocField == null || groupDocField.hasFieldNameDocField(docField.getFieldName())) {
            groupDocField = new GroupTemplate(docField);
            docFields.add(groupDocField);

            Class<?> parentClass = docField.getParentClass();
            GroupTemplate pGrpDocField = docFields.stream().filter(f -> //
            f.getClass().equals(GroupTemplate.class)//
                    && f.getContentClass().equals(parentClass))//
                    .findFirst()//
                    .map(GroupTemplate.class::cast).orElse(null);

            if (pGrpDocField != null) {
                pGrpDocField.addGroupTemplate(groupDocField);
                removeFields.add(groupDocField);
            }
        }

        groupDocField.addTemplate(docField);
        removeFields.add(docField);

    }

    /***/
    private boolean updateSheetColumn(Cell cell) {

        boolean result = false;

        int cellNumber = cell.getColumnIndex();
        String addressName = cell.getAddress().formatAsString();

        SheetColumnView sheetColumn = columnViews.stream().filter(f -> f.anyMatchKey(addressName)).findFirst()
                .orElse(null);

        if (sheetColumn == null && !cell.getCellType().equals(CellType.STRING))
            return false;

        String textValue = cell.getRichStringCellValue().toString();

        if (sheetColumn == null) {

            // enter зэвэрлэх
            textValue = textValue.replaceAll("\n", " ");

            // unit тэмдэг цэвэрлэх
            textValue = textValue.replaceAll("\\sMNT$", "");

            // тусгай тэмдэгт цэвэрлэх
            String headerValue = textValue.replaceAll("\\(|\\)", "");

            sheetColumn = columnViews.stream().filter(f -> f.anyMatchKey(headerValue)).findFirst().orElse(null);
        }

        result = sheetColumn != null;

        if (result)
            templates.put(cellNumber, sheetColumn.getTemplate());

        return result;
    }

    /**
     * Нэг хүснэгтийн утагийн авах
     * 
     * @param template
     * @param cell
     */
    private Object getCellValue(Class<?> dataType, Cell cell) {

        Object result = null;

        if (dataType == null || cell == null)
            return result;

        CellType cellType = cell.getCellType();

        switch (cellType) {
        case NUMERIC: {
            result = ReflectionUtil.isDate(dataType) ? cell.getDateCellValue() : cell.getNumericCellValue();
            break;
        }
        case STRING: {
            result = cell.getRichStringCellValue().getString();
            break;
        }
        case FORMULA: {
            if (cell.getCachedFormulaResultType().equals(CellType.NUMERIC)) {
                result = ReflectionUtil.isDate(dataType) ? cell.getDateCellValue() : cell.getNumericCellValue();
            }

        }

        default: {
            break;
        }

        }

        return result;
    }

    /***/
    private TemplateField buildTemplate(TemplateField template, Object value) throws TemplateException {
        TemplateField result = null;

        String fieldName = template.getFieldName();
        // орж ирсэн template төрөлийн авах
        Class<?> type = template.getType();

        if (value == null)
            throw new TemplateException("утаг null орж ирсэн байна.[" + fieldName + "]  ");

        // орж ирсэн value-ний төрөл
        Class<?> vType = value.getClass();

        // Шинэ document үүсгэхэд зоож өгөх утаг
        Object rValue = value;

        // Enum төрөл бол enum ийн name талбарийн авах
        if (type.isEnum()) {
            List<?> enumValues = Arrays.asList(type.getEnumConstants());
            rValue = enumValues.stream().map(Enum.class::cast)//
                    .filter(en -> en.toString().matches(value.toString()))//
                    .map(Enum::name).findFirst().orElse(null);
        }

        // primitive төрөл шалгах
        else if (ReflectionUtil.isWrapperClass(type) && !vType.equals(type)) {
            if (ReflectionUtil.isText(type)) {
                rValue = value.toString();
            } else if (ReflectionUtil.isDate(type)) {

                if (ReflectionUtil.isText(vType)) {
                    rValue = Instant.parse(value.toString());
                }

                else
                    rValue = ((Date) value).toInstant();

            } else if (ReflectionUtil.isNumber(vType) && ReflectionUtil.isNumber(type))
                rValue = value;
            else {
                throw new TemplateException("Өгөгдөлийн төрөл зөрч байна. [" + fieldName + " : " + type + "] ");
            }
        }

        result = new TemplateField(template);
        result.setValue(rValue);

        return result;
    }

    public boolean isEmptySheetDatas() {
        return sheetDatas == null || sheetDatas.isEmpty();
    }

    public List<SheetData> getSheetDatas() {
        return sheetDatas;
    }

    public SheetData getFirstSheetData() {
        return sheetDatas.get(0);
    }

}

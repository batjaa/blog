package com.khanbank.cpms.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.khanbank.cpms.domain.Installment;

/**
 * Spring Data repository for the Installment entity.
 */
@Repository
public interface InstallmentRepository extends JpaRepository<Installment, Long> {

    Page<Installment> findByTradeId(Long id, Pageable pageable);

}

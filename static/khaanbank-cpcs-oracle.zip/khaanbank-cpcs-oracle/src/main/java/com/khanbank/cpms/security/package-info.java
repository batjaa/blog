/**
 * Spring Security configuration.
 */
package com.khanbank.cpms.security;

package com.khanbank.cpms.domain;

import java.time.Instant;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.khanbank.cpms.domain.enumeration.ProjectCostEstimateSubmissionStatus;
import com.khanbank.cpms.excel.anno.SheetRow;
import com.khanbank.cpms.excel.enumeration.SheetCellFormat;
import com.khanbank.cpms.excel.enumeration.SheetRowType;
import com.khanbank.cpms.excel.enumeration.SheetRowValue;

/**
 * A ProjectCostEstimateSubmission.
 */
@Entity
@Table(name = "proj_cost_est_sub")
public class ProjectCostEstimateSubmission extends AbstractAuditingEntity {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false)
    private ProjectCostEstimateSubmissionStatus status;

    @CreatedBy
    @Column(name = "submitted_by")
    private String submittedBy;

    @Column(name = "responded_by")
    private String respondedBy;
    
    @CreatedDate
    @Column(name = "submitted_at")
    private Instant submittedAt;
    
    @Column(name = "responded_at")
    private Instant respondedAt;

    @Column(name = "notes")
    private String notes;

    @SheetRow(mergedRowNumbers = {
            11, 12
    }, firstColumn = 6, valueType = SheetRowValue.SUM, format = SheetCellFormat.YEAR_DATE, columnType = SheetRowType.MERGED)
    @Column(name = "current_total")
    private Long currentTotal;

    @Column(name = "deleted_at")
    private Instant deletedAt;

    @LastModifiedDate
    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;

    @CreatedDate
    @Column(name = "created_at", nullable = false)
    private Instant createdAt;

    @OneToOne
    @JoinColumn(unique = true)
    private File file;

    @Column(name = "image_path")
    private String imagePath;

    @ManyToOne
    @JsonIgnoreProperties("projectCostEstimateSubmissions")
    private ProjectCostEstimate projectCostEstimate;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public ProjectCostEstimateSubmissionStatus getStatus() {
        return status;
    }

    public ProjectCostEstimateSubmission status(ProjectCostEstimateSubmissionStatus status) {
        this.status = status;
        return this;
    }

    public void setStatus(ProjectCostEstimateSubmissionStatus status) {
        this.status = status;
    }

    public String getSubmittedBy() {
        return submittedBy;
    }

    public ProjectCostEstimateSubmission submittedBy(String submittedBy) {
        this.submittedBy = submittedBy;
        return this;
    }

    public void setSubmittedBy(String submittedBy) {
        this.submittedBy = submittedBy;
    }

    public String getRespondedBy() {
        return respondedBy;
    }

    public ProjectCostEstimateSubmission respondedBy(String respondedBy) {
        this.respondedBy = respondedBy;
        return this;
    }

    public void setRespondedBy(String respondedBy) {
        this.respondedBy = respondedBy;
    }

    public Instant getSubmittedAt() {
        return submittedAt;
    }

    public ProjectCostEstimateSubmission submittedAt(Instant submittedAt) {
        this.submittedAt = submittedAt;
        return this;
    }

    public void setSubmittedAt(Instant submittedAt) {
        this.submittedAt = submittedAt;
    }

    public Instant getRespondedAt() {
        return respondedAt;
    }

    public ProjectCostEstimateSubmission respondedAt(Instant respondedAt) {
        this.respondedAt = respondedAt;
        return this;
    }

    public void setRespondedAt(Instant respondedAt) {
        this.respondedAt = respondedAt;
    }

    public String getNotes() {
        return notes;
    }

    public ProjectCostEstimateSubmission notes(String notes) {
        this.notes = notes;
        return this;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public Long getCurrentTotal() {
        return currentTotal;
    }

    public void setCurrentTotal(Long currentTotal) {
        this.currentTotal = currentTotal;
    }

    public Instant getDeletedAt() {
        return deletedAt;
    }

    public ProjectCostEstimateSubmission deletedAt(Instant deletedAt) {
        this.deletedAt = deletedAt;
        return this;
    }

    public void setDeletedAt(Instant deletedAt) {
        this.deletedAt = deletedAt;
    }

    public Instant getUpdatedAt() {
        return updatedAt;
    }

    public ProjectCostEstimateSubmission updatedAt(Instant updatedAt) {
        this.updatedAt = updatedAt;
        return this;
    }

    public void setUpdatedAt(Instant updatedAt) {
        this.updatedAt = updatedAt;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public ProjectCostEstimateSubmission createdAt(Instant createdAt) {
        this.createdAt = createdAt;
        return this;
    }

    public void setCreatedAt(Instant createdAt) {
        this.createdAt = createdAt;
    }

    public File getFile() {
        return file;
    }

    public ProjectCostEstimateSubmission file(File file) {
        this.file = file;
        return this;
    }

    public void setFile(File file) {
        this.file = file;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }

    public ProjectCostEstimate getProjectCostEstimate() {
        return projectCostEstimate;
    }

    public ProjectCostEstimateSubmission projectCostEstimate(ProjectCostEstimate projectCostEstimate) {
        this.projectCostEstimate = projectCostEstimate;
        return this;
    }

    public void setProjectCostEstimate(ProjectCostEstimate projectCostEstimate) {
        this.projectCostEstimate = projectCostEstimate;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof ProjectCostEstimateSubmission)) {
            return false;
        }
        return id != null && id.equals(((ProjectCostEstimateSubmission) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return "ProjectCostEstimateSubmission{" + "id=" + getId() + ", status='" + getStatus() + "'" + ", submittedBy='"
                + getSubmittedBy() + "'" + ", respondedBy='" + getRespondedBy() + "'" + ", submittedAt='"
                + getSubmittedAt() + "'" + ", respondedAt='" + getRespondedAt() + "'" + ", notes='" + getNotes() + "'"
                + ", deletedAt='" + getDeletedAt() + "'" + ", updatedAt='" + getUpdatedAt() + "'" + ", createdAt='"
                + getCreatedAt() + "'" + "}";
    }

}

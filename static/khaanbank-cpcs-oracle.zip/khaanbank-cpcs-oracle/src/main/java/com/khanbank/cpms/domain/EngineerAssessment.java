package com.khanbank.cpms.domain;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.LastModifiedBy;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.khanbank.cpms.domain.enumeration.EngineerAssessmentType;

/**
 * A EngineerAssessment.
 */
@Entity
@Table(name = "engineer_assessment")
public class EngineerAssessment extends AbstractAuditingEntity {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "jhi_type", nullable = false)
    private EngineerAssessmentType type;

    @Lob
    @Column(name = "notes")
    private String notes;

    @CreatedBy
    @Column(name = "created_by", nullable = false)
    private String createdBy;

    @LastModifiedBy
    @Column(name = "updated_by", nullable = false)
    private String updatedBy;

    @OneToOne
    @JoinColumn(unique = true)
    private Grant grant;

    @OneToMany(fetch = FetchType.EAGER)
    private Set<File> files = new HashSet<>();

    @ManyToOne
    @JsonIgnoreProperties("engineerAssessments")
    private Project project;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public EngineerAssessmentType getType() {
        return type;
    }

    public EngineerAssessment type(EngineerAssessmentType type) {
        this.type = type;
        return this;
    }

    public void setType(EngineerAssessmentType type) {
        this.type = type;
    }

    public String getNotes() {
        return notes;
    }

    public EngineerAssessment notes(String notes) {
        this.notes = notes;
        return this;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public EngineerAssessment createdBy(String createdBy) {
        this.createdBy = createdBy;
        return this;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public EngineerAssessment updatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
        return this;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Grant getGrant() {
        return grant;
    }

    public EngineerAssessment grant(Grant grant) {
        this.grant = grant;
        return this;
    }

    public void setGrant(Grant grant) {
        this.grant = grant;
    }

    public Set<File> getFiles() {
        return files;
    }

    public EngineerAssessment files(Set<File> files) {
        this.files = files;
        return this;
    }

    public EngineerAssessment addFiles(File file) {
        this.files.add(file);
        return this;
    }

    public EngineerAssessment removeFiles(File file) {
        this.files.remove(file);
        return this;
    }

    public void setFiles(Set<File> files) {
        this.files = files;
    }

    public Project getProject() {
        return project;
    }

    public EngineerAssessment project(Project project) {
        this.project = project;
        return this;
    }

    public void setProject(Project project) {
        this.project = project;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof EngineerAssessment)) {
            return false;
        }
        return id != null && id.equals(((EngineerAssessment) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return "EngineerAssessment{" + "id=" + getId() + ", type='" + getType() + "'" + ", notes='" + getNotes() + "'"
                + ", createdBy='" + getCreatedBy() + "'" + ", updatedBy='" + getUpdatedBy() + "'" + "}";
    }
}

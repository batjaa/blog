/**
 * Service layer beans.
 */
package com.khanbank.cpms.service;

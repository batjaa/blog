/**
 * View Models used by Spring MVC REST controllers.
 */
package com.khanbank.cpms.web.rest.vm;

package com.khanbank.cpms.domain;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.springframework.data.annotation.LastModifiedBy;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.khanbank.cpms.domain.enumeration.FacilityType;
import com.khanbank.cpms.excel.anno.SheetCell;

/**
 * A Facility.
 */
@Entity
@Table(name = "facility")
public class Facility extends AbstractAuditingEntity {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    @SheetCell(key = "Тоот")
    @Column(name = "jhi_number", nullable = false)
    private String number;

    @NotNull
    @SheetCell(key = "Хэмжээ м/кв")
    @Column(name = "area", nullable = false)
    private Double area;

    @NotNull
    @SheetCell(key = "Төрөл")
    @Enumerated(EnumType.STRING)
    @Column(name = "jhi_type", nullable = false)
    private FacilityType type;

    @LastModifiedBy
    @Column(name = "updated_by", nullable = false)
    private String updatedBy;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(unique = true)
    private Trade trade;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(unique = true)
    private Release release;

    @ManyToOne
    @JsonIgnoreProperties("facilities")
    private Building building;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNumber() {
        return number;
    }

    public Facility number(String number) {
        this.number = number;
        return this;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public Double getArea() {
        return area;
    }

    public Facility area(Double area) {
        this.area = area;
        return this;
    }

    public void setArea(Double area) {
        this.area = area;
    }

    public FacilityType getType() {
        return type;
    }

    public Facility type(FacilityType type) {
        this.type = type;
        return this;
    }

    public void setType(FacilityType type) {
        this.type = type;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public Facility updatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
        return this;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Trade getTrade() {
        return trade;
    }

    public Facility trade(Trade trade) {
        this.trade = trade;
        return this;
    }

    public void setTrade(Trade trade) {
        this.trade = trade;
    }

    public Release getRelease() {
        return release;
    }

    public Facility release(Release release) {
        this.release = release;
        return this;
    }

    public void setRelease(Release release) {
        this.release = release;
    }

    public Building getBuilding() {
        return building;
    }

    public Facility building(Building building) {
        this.building = building;
        return this;
    }

    public void setBuilding(Building building) {
        this.building = building;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Facility)) {
            return false;
        }
        return id != null && id.equals(((Facility) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return "Facility{" + "id=" + getId() + ", number='" + getNumber() + "'" + ", area=" + getArea() + ", type='" + getType() + "'" + ", updatedBy='" + getUpdatedBy() + "'" + "}";
    }
}

package com.khanbank.cpms.excel.enumeration;

public enum SheetRowType {
    NONE, MERGED
}

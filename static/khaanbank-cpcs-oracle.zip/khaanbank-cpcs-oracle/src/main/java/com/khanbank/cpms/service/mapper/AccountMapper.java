package com.khanbank.cpms.service.mapper;

import java.util.List;

public class AccountMapper {

    private String login;
    private String langKey;
    private List<String> authorities;

    public AccountMapper(String login, List<String> authorities) {
        this.login = login;
        this.authorities = authorities;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getLangKey() {
        return langKey;
    }

    public void setLangKey(String langKey) {
        this.langKey = langKey;
    }

    public List<String> getAuthorities() {
        return authorities;
    }

    public void setAuthorities(List<String> authorities) {
        this.authorities = authorities;
    }
}

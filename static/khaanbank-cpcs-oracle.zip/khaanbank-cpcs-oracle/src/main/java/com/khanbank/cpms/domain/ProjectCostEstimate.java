package com.khanbank.cpms.domain;

import java.time.Instant;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

/**
 * A ProjectCostEstimate.
 */
@Entity
@Table(name = "project_cost_estimate")
public class ProjectCostEstimate extends AbstractAuditingEntity {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Lob
    @Column(name = "jhi_raw")
    private String raw;

    @LastModifiedBy
    @Column(name = "updated_by")
    private String updatedBy;

    @LastModifiedDate
    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;

    @CreatedDate
    @Column(name = "created_at", nullable = false)
    private Instant createdAt;

    @OneToOne
    @JoinColumn(unique = true)
    private Project project;

    @OneToMany(mappedBy = "projectCostEstimate", cascade = CascadeType.ALL)
    private Set<ProjectCostEstimateSubmission> projectCostEstimateSubmissions = new HashSet<>();

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getRaw() {
        return raw;
    }

    public ProjectCostEstimate raw(String raw) {
        this.raw = raw;
        return this;
    }

    public void setRaw(String raw) {
        this.raw = raw;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public ProjectCostEstimate updatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
        return this;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Instant getUpdatedAt() {
        return updatedAt;
    }

    public ProjectCostEstimate updatedAt(Instant updatedAt) {
        this.updatedAt = updatedAt;
        return this;
    }

    public void setUpdatedAt(Instant updatedAt) {
        this.updatedAt = updatedAt;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public ProjectCostEstimate createdAt(Instant createdAt) {
        this.createdAt = createdAt;
        return this;
    }

    public void setCreatedAt(Instant createdAt) {
        this.createdAt = createdAt;
    }

    public Project getProject() {
        return project;
    }

    public ProjectCostEstimate project(Project project) {
        this.project = project;
        return this;
    }

    public void setProject(Project project) {
        this.project = project;
    }

    public Set<ProjectCostEstimateSubmission> getProjectCostEstimateSubmissions() {
        return projectCostEstimateSubmissions;
    }

    public ProjectCostEstimate projectCostEstimateSubmissions(
            Set<ProjectCostEstimateSubmission> projectCostEstimateSubmissions) {
        this.projectCostEstimateSubmissions = projectCostEstimateSubmissions;
        return this;
    }

    public ProjectCostEstimate addProjectCostEstimateSubmissions(
            ProjectCostEstimateSubmission projectCostEstimateSubmission) {
        this.projectCostEstimateSubmissions.add(projectCostEstimateSubmission);
        projectCostEstimateSubmission.setProjectCostEstimate(this);
        return this;
    }

    public ProjectCostEstimate removeProjectCostEstimateSubmissions(
            ProjectCostEstimateSubmission projectCostEstimateSubmission) {
        this.projectCostEstimateSubmissions.remove(projectCostEstimateSubmission);
        projectCostEstimateSubmission.setProjectCostEstimate(null);
        return this;
    }

    public void setProjectCostEstimateSubmissions(Set<ProjectCostEstimateSubmission> projectCostEstimateSubmissions) {
        this.projectCostEstimateSubmissions = projectCostEstimateSubmissions;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof ProjectCostEstimate)) {
            return false;
        }
        return id != null && id.equals(((ProjectCostEstimate) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return "ProjectCostEstimate{" + "id=" + getId() + ", raw='" + getRaw() + "'" + ", updatedBy='" + getUpdatedBy()
                + "'" + ", updatedAt='" + getUpdatedAt() + "'" + ", createdAt='" + getCreatedAt() + "'" + "}";
    }

    @PrePersist
    public void createdAt() {
        this.createdAt = Instant.now();
    }

    @PreUpdate
    public void updatedAt() {
        this.updatedAt = Instant.now();
    }
}

package com.khanbank.cpms.service.util;

import java.time.Instant;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class CalendarUtil {

    public static Instant parseToInstant(String dateValue) {

        if (dateValue == null || dateValue.isEmpty())
            return null;

        String regexDate = "[12]\\d{3}-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01])";// yyyy-mm-dd regex match
        String regexYearAndMonth = "[12]\\d{3}-(0[1-9]|1[0-2])";// yyyy-mm regex match

        if (!dateValue.matches(regexDate) && !dateValue.matches(regexYearAndMonth))
            return null;

        String[] date = dateValue.split("-");
        boolean notDay = date.length < 3;
        int year = Integer.parseInt(date[0]);
        int month = Integer.parseInt(date[1]);
        int day = notDay ? 0 : Integer.parseInt(date[2]);
        Calendar cal = new GregorianCalendar(year, month, day);
        return cal.toInstant();
    }
}

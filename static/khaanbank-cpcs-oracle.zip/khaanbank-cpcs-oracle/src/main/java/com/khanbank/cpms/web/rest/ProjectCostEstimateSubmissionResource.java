package com.khanbank.cpms.web.rest;

import java.net.URISyntaxException;
import java.nio.charset.Charset;
import java.time.Instant;
import java.util.Date;
import java.util.Optional;

import javax.validation.Valid;

import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.khanbank.cpms.domain.File;
import com.khanbank.cpms.domain.Project;
import com.khanbank.cpms.domain.ProjectCostEstimateSubmission;
import com.khanbank.cpms.domain.enumeration.ProjectCostEstimateSubmissionStatus;
import com.khanbank.cpms.excel.SheetData;
import com.khanbank.cpms.excel.template.TemplateField;
import com.khanbank.cpms.repository.FileRepository;
import com.khanbank.cpms.repository.ProjectCostEstimateSubmissionRepository;
import com.khanbank.cpms.security.SecurityUtils;
import com.khanbank.cpms.service.StorageService;
import com.khanbank.cpms.service.util.HelperUtil;
import com.khanbank.cpms.web.rest.errors.BadRequestAlertException;

import io.github.jhipster.web.util.HeaderUtil;
import io.github.jhipster.web.util.ResponseUtil;

/**
 * REST controller for managing {@link com.khanbank.cpms.domain.ProjectCostEstimateSubmission}.
 */
@RestController
@RequestMapping("/api")
public class ProjectCostEstimateSubmissionResource {

    private final Logger logger = LoggerFactory.getLogger(ProjectCostEstimateSubmissionResource.class);

    private static final String ENTITY_NAME = "projectCostEstimateSubmission";

    @Value("${app.upload-director}")
    private String uploadDirector = "";

    @Autowired
    private StorageService storageService;

    @Autowired
    private FileRepository fileRepo;

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final ProjectCostEstimateSubmissionRepository projectCostEstimateSubmissionRepository;

    public ProjectCostEstimateSubmissionResource(
            ProjectCostEstimateSubmissionRepository projectCostEstimateSubmissionRepository) {
        this.projectCostEstimateSubmissionRepository = projectCostEstimateSubmissionRepository;
    }

    /**
     * {@code PUT  /project-cost-estimate-submissions} : Updates an existing projectCostEstimateSubmission.
     *
     * @param projectCostEstimateSubmission
     *            the projectCostEstimateSubmission to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated projectCostEstimateSubmission, or with status {@code 400 (Bad Request)} if the
     *         projectCostEstimateSubmission is not valid, or with status {@code 500 (Internal Server Error)} if the projectCostEstimateSubmission couldn't be updated.
     * @throws URISyntaxException
     *             if the Location URI syntax is incorrect.
     */
    @PutMapping("/project-cost-estimate-submissions")
    public ResponseEntity<ProjectCostEstimateSubmission> updateProjectCostEstimateSubmission(
            @Valid @RequestBody ProjectCostEstimateSubmission projectCostEstimateSubmission) throws URISyntaxException {
        logger.debug("REST request to update ProjectCostEstimateSubmission : {}", projectCostEstimateSubmission);

        Optional<ProjectCostEstimateSubmission> optOldCostEstimateSubmission = projectCostEstimateSubmissionRepository
                .findById(projectCostEstimateSubmission.getId());

        boolean updateEntity = HelperUtil.updateObjectRequiredFields(optOldCostEstimateSubmission,
                projectCostEstimateSubmission, "projectCostEstimate");

        if (!updateEntity)
            return ResponseEntity.badRequest().build();

        ProjectCostEstimateSubmission result = projectCostEstimateSubmissionRepository
                .save(projectCostEstimateSubmission);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityUpdateAlert(applicationName, true, ENTITY_NAME,
                projectCostEstimateSubmission.getId().toString())).body(result);
    }

    @PostMapping("/project-cost-estimate-submissions/{id}/accept")
    public ResponseEntity<ProjectCostEstimateSubmission> acceptCostEstimateSubmission(@PathVariable Long id)
            throws URISyntaxException {
        ProjectCostEstimateSubmission submission = projectCostEstimateSubmissionRepository.findById(id).get();

        if (submission == null || submission.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }

        File file = submission.getFile();
        String generateImagePath = null;
        try {
            SheetData sheetData = storageService.customParserSheetData(file, ProjectCostEstimateSubmission.class);

            TemplateField field = sheetData.findTemplate(ProjectCostEstimateSubmission.class, "currentTotal");

            if (field == null || !sheetData.hasFromToCell())
                throw new Exception("Алдаатай еxcel file байна from сell болон to cell олдсонгүй");

            generateImagePath = storageService.generateSheetToImage(file, sheetData.getName(), sheetData.getFromCell(),
                    sheetData.getToCell());

            if (generateImagePath == null || generateImagePath.isEmpty())
                throw new Exception("Алдаатай еxcel file байна зураг болгож чадсангүй");

            // image file archive saving
            File fileImage = new File().name(file.getName()).path(generateImagePath);
            fileRepo.save(fileImage);

        } catch (Exception e) {
            logger.error(e.getMessage());
            return ResponseEntity.badRequest().build();
        }

        String currentUserLogin = SecurityUtils.getCurrentUserLogin().get();
        submission.setRespondedBy(currentUserLogin);
        submission.setRespondedAt(Instant.now());

        submission.setImagePath(generateImagePath);
        submission.setStatus(ProjectCostEstimateSubmissionStatus.ACCEPTED);

        submission = projectCostEstimateSubmissionRepository.save(submission);

        return ResponseEntity.ok(submission);
    }

    @PostMapping("/project-cost-estimate-submissions/{id}/decline")
    public ResponseEntity<ProjectCostEstimateSubmission> declineCostEstimateSubmission(@PathVariable Long id)
            throws URISyntaxException {

        ProjectCostEstimateSubmission submission = projectCostEstimateSubmissionRepository.findById(id).get();

        if (submission == null || submission.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }

        String currentUserLogin = SecurityUtils.getCurrentUserLogin().get();
        submission.setRespondedBy(currentUserLogin);
        submission.setRespondedAt(Instant.now());

        submission.setStatus(ProjectCostEstimateSubmissionStatus.DECLINED);

        submission = projectCostEstimateSubmissionRepository.save(submission);

        return ResponseEntity.ok(submission);
    }

    /**
     * {@code GET  /project-cost-estimate-submissions/:id} : get the "id" projectCostEstimateSubmission.
     *
     * @param id
     *            the id of the projectCostEstimateSubmission to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the projectCostEstimateSubmission, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/project-cost-estimate-submissions/{id}")
    public ResponseEntity<ProjectCostEstimateSubmission> getProjectCostEstimateSubmission(@PathVariable Long id) {
        logger.debug("REST request to get ProjectCostEstimateSubmission : {}", id);
        Optional<ProjectCostEstimateSubmission> projectCostEstimateSubmission = projectCostEstimateSubmissionRepository
                .findById(id);
        return ResponseUtil.wrapOrNotFound(projectCostEstimateSubmission);
    }

    /**
     * {@code DELETE  /project-cost-estimate-submissions/:id} : delete the "id" projectCostEstimateSubmission.
     *
     * @param id
     *            the id of the projectCostEstimateSubmission to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/project-cost-estimate-submissions/{id}")
    public ResponseEntity<Void> deleteProjectCostEstimateSubmission(@PathVariable Long id) {
        logger.debug("REST request to delete ProjectCostEstimateSubmission : {}", id);

        Optional<ProjectCostEstimateSubmission> opCostEstimateSubmission = projectCostEstimateSubmissionRepository
                .findById(id);

        if (opCostEstimateSubmission.isPresent()) {
            ProjectCostEstimateSubmission costEstimateSubmission = opCostEstimateSubmission.get();
            costEstimateSubmission.deletedAt(new Date().toInstant());
            projectCostEstimateSubmissionRepository.save(costEstimateSubmission);
            return ResponseEntity.ok().build();
        }

        return ResponseEntity.badRequest().build();

    }

    @PostMapping("/project-cost-estimate-submissions/file/{id}")
    public ResponseEntity<Object> parseFileData(@PathVariable Long id) {
        logger.debug("REST request to ProjectCostEstimateSubmission get File parse : {}", id);
        Optional<File> optFile = fileRepo.findById(id);

        if (optFile.isPresent()) {
            File file = optFile.get();
            try {
                Project project = storageService.loadParserSheetData(file, Project.class);
                return ResponseEntity.ok().body(project);
            } catch (Exception e) {
                logger.error(e.getMessage());
            }
        }

        return ResponseEntity.badRequest().build();
    }

    @GetMapping("/project-cost-estimate-submissions/{id}/image")
    public ResponseEntity<byte[]> getCostEstimateSubmissionImage(@PathVariable Long id) {

        Optional<ProjectCostEstimateSubmission> optCostEstimateSubmission = projectCostEstimateSubmissionRepository
                .findById(id);

        if (optCostEstimateSubmission.isPresent()) {

            String imagePath = optCostEstimateSubmission.get().getImagePath();
            try {
                java.io.File javaFile = new java.io.File(imagePath);
                String extension = FilenameUtils.getExtension(imagePath);
                byte[] imageByte = FileCopyUtils.copyToByteArray(javaFile);

                HttpHeaders headers = new HttpHeaders();
                headers.setContentType(new MediaType("image", extension, Charset.forName("UTF-8")));
                headers.setContentLength(imageByte.length);

                return ResponseEntity.ok().headers(headers).body(imageByte);

            } catch (Exception e) {
                logger.error(e.getMessage());
            }

        }

        return ResponseEntity.badRequest().build();

    }

}

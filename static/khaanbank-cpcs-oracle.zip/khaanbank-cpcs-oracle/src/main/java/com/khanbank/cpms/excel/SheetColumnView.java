package com.khanbank.cpms.excel;

import com.khanbank.cpms.excel.anno.SheetCell;

public class SheetColumnView extends SheetAbstractCellView {

    private boolean required;

    public SheetColumnView(String key) {
        super(key, SheetReadType.COL);
    }

    public SheetColumnView(SheetCell sheetCell) {
        this(sheetCell.key());
    }

    public boolean isRequired() {
        return required;
    }

    public void setRequired(boolean required) {
        this.required = required;
    }

}

package com.khanbank.cpms.excel.anno;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import com.khanbank.cpms.excel.enumeration.SheetCellFormat;
import com.khanbank.cpms.excel.enumeration.SheetRowType;
import com.khanbank.cpms.excel.enumeration.SheetRowValue;

@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
public @interface SheetRow {
    String key() default "";

    SheetRowValue valueType() default SheetRowValue.CURRENT;

    SheetCellFormat format() default SheetCellFormat.NONE;

    SheetRowType columnType() default SheetRowType.NONE;

    int[] mergedRowNumbers() default {};

    int firstColumn() default -1;

    int lastColumn() default -1;
}

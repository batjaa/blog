package com.khanbank.cpms.service.param;

import com.fasterxml.jackson.databind.JsonNode;

public class JsonNodeParam {
	private int rowNumber = -1;
	private JsonNode jsonNode;
	private Class<?> entityClass;

	public JsonNodeParam(JsonNode jsonNode, Class<?> entityClass) {
		this.jsonNode = jsonNode;
		this.entityClass = entityClass;
	}

	public JsonNode getJsonNode() {
		return jsonNode;
	}

	public void setJsonNode(JsonNode jsonNode) {
		this.jsonNode = jsonNode;
	}

	public Class<?> getEntityClass() {
		return entityClass;
	}

	public void setEntityClass(Class<?> entityClass) {
		this.entityClass = entityClass;
	}

	public int getRowNumber() {
		return rowNumber;
	}

	public void setRowNumber(int rowNumber) {
		this.rowNumber = rowNumber;
	}
}

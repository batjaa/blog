package com.khanbank.cpms.web.rest;

import java.net.URISyntaxException;
import java.util.Optional;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.khanbank.cpms.domain.Facility;
import com.khanbank.cpms.domain.Release;
import com.khanbank.cpms.domain.Trade;
import com.khanbank.cpms.repository.FacilityRepository;
import com.khanbank.cpms.repository.ReleaseRepository;
import com.khanbank.cpms.repository.TradeRepository;
import com.khanbank.cpms.service.util.HelperUtil;
import com.khanbank.cpms.web.rest.errors.BadRequestAlertException;

import io.github.jhipster.web.util.HeaderUtil;
import io.github.jhipster.web.util.ResponseUtil;

/**
 * REST controller for managing {@link com.khanbank.cpms.domain.Facility}.
 */
@RestController
@RequestMapping("/api")
public class FacilityResource {

    private final Logger log = LoggerFactory.getLogger(FacilityResource.class);

    private static final String ENTITY_NAME = "facility";

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final FacilityRepository facilityRepository;

    @Autowired
    private ReleaseRepository releaseRepository;

    @Autowired
    private TradeRepository tradeRepository;

    public FacilityResource(FacilityRepository facilityRepository) {
        this.facilityRepository = facilityRepository;
    }

    /**
     * {@code PUT  /facilities} : Updates an existing facility.
     *
     * @param facility
     *            the facility to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated facility, or with status {@code 400 (Bad Request)} if the facility is not valid, or with status
     *         {@code 500 (Internal Server Error)} if the facility couldn't be updated.
     * @throws URISyntaxException
     *             if the Location URI syntax is incorrect.
     */
    @PutMapping("/facilities")
    public ResponseEntity<Facility> updateFacility(@Valid @RequestBody Facility facility) throws URISyntaxException {
        log.debug("REST request to update Facility : {}", facility);
        if (facility.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }

        Optional<Facility> optOldFacility = facilityRepository.findById(facility.getId());

        boolean updateEntity = HelperUtil.updateObjectRequiredFields(optOldFacility, facility);

        if (!updateEntity)
            return ResponseEntity.badRequest().build();

        Facility result = facilityRepository.save(facility);
        return ResponseEntity.ok().headers(
                HeaderUtil.createEntityUpdateAlert(applicationName, true, ENTITY_NAME, facility.getId().toString()))
                .body(result);
    }

    /**
     * {@code GET  /facilities/:id} : get the "id" facility.
     *
     * @param id
     *            the id of the facility to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the facility, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/facilities/{id}")
    public ResponseEntity<Facility> getFacility(@PathVariable Long id) {
        log.debug("REST request to get Facility : {}", id);
        Optional<Facility> facility = facilityRepository.findById(id);
        return ResponseUtil.wrapOrNotFound(facility);
    }

    /**
     * {@code DELETE  /facilities/:id} : delete the "id" facility.
     *
     * @param id
     *            the id of the facility to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/facilities/{id}")
    public ResponseEntity<Void> deleteFacility(@PathVariable Long id) {
        log.debug("REST request to delete Facility : {}", id);
        facilityRepository.deleteById(id);
        return ResponseEntity.noContent()
                .headers(HeaderUtil.createEntityDeletionAlert(applicationName, true, ENTITY_NAME, id.toString()))
                .build();
    }

    @GetMapping("/facilities/{id}/trade")
    public ResponseEntity<Trade> getTrade(@PathVariable Long id) {

        Optional<Trade> optTrade = tradeRepository.findByFacilityId(id);

        return ResponseUtil.wrapOrNotFound(Optional.ofNullable(optTrade.get()));

    }

    @PostMapping("/facilities/{id}/trades")
    public ResponseEntity<Trade> createTrade(@PathVariable Long id, @Valid @RequestBody Trade trade)
            throws URISyntaxException {
        log.debug("REST request to save Trade : {}", trade);

        if (trade.getId() != null) {
            throw new BadRequestAlertException("A new trade cannot already have an ID", ENTITY_NAME, "idexists");
        }

        Optional<Facility> optFacility = facilityRepository.findById(id);

        if (!optFacility.isPresent())
            return ResponseEntity.badRequest().build();

        Facility facility = optFacility.get();

        trade.setFacility(facility);
        facility.setTrade(trade);

        facility = facilityRepository.saveAndFlush(facility);

        Trade result = facility.getTrade();

        return ResponseEntity.ok().body(result);
    }

    @GetMapping("/facilities/{id}/release")
    public ResponseEntity<Release> getRelease(@PathVariable Long id) {

        Optional<Release> optRelease = releaseRepository.findByFacilityId(id);

        return ResponseUtil.wrapOrNotFound(Optional.ofNullable(optRelease.get()));

    }

    @PostMapping("/facilities/{id}/releases")
    public ResponseEntity<Release> createRelease(@PathVariable Long id, @Valid @RequestBody Release release)
            throws URISyntaxException {
        log.debug("REST request to save Release : {}", release);

        if (release.getId() != null) {
            throw new BadRequestAlertException("A new release cannot already have an ID", ENTITY_NAME, "idexists");
        }

        Optional<Facility> optFacility = facilityRepository.findById(id);

        if (!optFacility.isPresent())
            return ResponseEntity.badRequest().build();

        Facility facility = optFacility.get();

        release.setFacility(facility);
        facility.setRelease(release);

        facility = facilityRepository.saveAndFlush(facility);

        Release result = facility.getRelease();

        return ResponseEntity.ok().body(result);
    }

}

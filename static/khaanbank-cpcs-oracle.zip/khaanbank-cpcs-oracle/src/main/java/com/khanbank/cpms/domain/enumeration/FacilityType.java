package com.khanbank.cpms.domain.enumeration;

/**
 * The FacilityType enumeration.
 */
public enum FacilityType {
	SERVICE("ҮЙЛЧИЛГЭЭ"), GARAGE("АВТО ЗОГСООЛ"), FLAT("ОРОН СУУЦ");

	private String text;

	private FacilityType(String text) {
		this.setText(text);
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	@Override
	public String toString() {
		return text;
	}
}

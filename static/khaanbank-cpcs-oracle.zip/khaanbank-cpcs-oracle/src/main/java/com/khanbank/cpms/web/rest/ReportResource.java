package com.khanbank.cpms.web.rest;

import java.util.Arrays;
import java.util.List;
import java.util.Spliterator;
import java.util.Spliterators;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.khanbank.cpms.domain.enumeration.FacilityStatus;
import com.khanbank.cpms.domain.enumeration.FacilityType;
import com.khanbank.cpms.repository.FacilityRepository;
import com.khanbank.cpms.service.dto.FacilityReport;

/**
 * REST controller for managing Facility or Project reports.
 */
@RestController
@RequestMapping("/api")
public class ReportResource {
	private final Logger logger = LoggerFactory.getLogger(ReportResource.class);

	@Autowired
	private FacilityRepository facilityRepo;

	@GetMapping("/report/facilities")
	public ResponseEntity<ArrayNode> getFacilitiesReport(Pageable pageable) {

		Page<FacilityReport> page = facilityRepo.fetchFacilityDataInnerJoin(pageable);

		List<FacilityType> facilityTypes = Arrays.asList(FacilityType.values());

		ObjectMapper jsonMapper = new ObjectMapper();
		ArrayNode arrayNodes = jsonMapper.createArrayNode();

		if (page.hasContent()) {

			logger.debug("facility report buildings");

			facilityTypes.forEach(type -> {
				ObjectNode objectNode = jsonMapper.createObjectNode();

				ArrayNode childNodes = jsonMapper.createArrayNode();

				List<FacilityReport> contents = page.getContent().stream().filter(f -> f.getType().equals(type)).collect(Collectors.toList());
				contents.forEach(c -> {
					FacilityStatus status = c.getStatus();
					updateGroupNode("area", c.getArea(), childNodes, status);
					updateGroupNode("totalPrice", c.getTotalPrice(), childNodes, status);
					updateGroupNode("installmentAmount", c.getInstallmentAmount(), childNodes, status);
				});

				objectNode.set(type.name(), childNodes);

				arrayNodes.add(objectNode);
			});
		}

		return ResponseEntity.ok().body(arrayNodes);
	}

	private void updateGroupNode(String key, Object value, ArrayNode objectNodes, FacilityStatus status) {
		
		String jsonKeyName = "name";
		String jsonSeriesName="series";
		
		ObjectMapper jsonMapper = new ObjectMapper();

		Stream<JsonNode>  elementStream = StreamSupport.stream(Spliterators
                .spliteratorUnknownSize(objectNodes.elements(),
                      Spliterator.ORDERED),false);
		
		ObjectNode objectNode = elementStream.filter(f -> f.has(jsonKeyName) && f.get(jsonKeyName).asText().matches(key)).map(ObjectNode.class::cast).findFirst().orElse(null);
		
		ArrayNode series = null;

		if (objectNode == null) {
			objectNode = jsonMapper.createObjectNode();
			series = jsonMapper.createArrayNode();
			objectNode.put(jsonKeyName, key);
			objectNode.set(jsonSeriesName, series);
			objectNodes.add(objectNode);
		}

		if (series == null)
			series = (ArrayNode) objectNode.get(jsonSeriesName);

		ObjectNode node = jsonMapper.createObjectNode();

		node.putPOJO("name", status);
		node.putPOJO("value", value);

		series.add(node);
	}

}

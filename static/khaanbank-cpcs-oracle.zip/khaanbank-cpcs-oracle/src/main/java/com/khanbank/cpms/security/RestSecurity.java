package com.khanbank.cpms.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;
import org.zalando.problem.Status;

import com.khanbank.cpms.domain.Project;
import com.khanbank.cpms.repository.ProjectRepository;
import com.khanbank.cpms.web.rest.errors.BadRequestException;
import com.khanbank.cpms.web.rest.errors.ErrorResponseCodes;

@Component
public class RestSecurity {

    @Autowired
    private ProjectRepository projectRepo;

    public boolean verifyProjectRequest(Authentication authentication, Long id) {
        Project project = projectRepo.findById(id).orElse(null);

        if (project == null)
            throw new BadRequestException(Status.BAD_REQUEST, ErrorResponseCodes.PROJECT_NOT_FOUND,
                    id + " ID-тай төсөл олдсонгүй.");

        return authentication.isAuthenticated();
    }

    public boolean verifyCompanyDeleteRequest(Long id) {
        Page<Project> page = projectRepo.findByCompanyId(id, Pageable.unpaged());

        if (page.hasContent()) {
            String name = page.getContent().get(0).getCompany().getName();
            throw new BadRequestException(Status.BAD_REQUEST, ErrorResponseCodes.PROJECT_NOT_DELETED,
                    name + " - г устгах боломжгүй. Холбоотой төслүүдийг устгах хэрэгтэй !!!");
        }

        return true;
    }
}

import { Moment } from 'moment';
import { IFile } from 'app/shared/model/file.model';
import { IProject } from 'app/shared/model/project.model';

export enum ComplianceType {
  ENGINEER_ASSESMENT = 'ENGINEER_ASSESMENT',
  CONSTRUCTION_COMPLIANCE = 'CONSTRUCTION_COMPLIANCE',
  ARCHITECTURE_ASSIGNMENT = 'ARCHITECTURE_ASSIGNMENT',
  BLUEPRINT_APPROVAL = 'BLUEPRINT_APPROVAL',
  THERMAL_COMPLIANCE = 'THERMAL_COMPLIANCE',
  ELECTRICITY_COMPLIANCE = 'ELECTRICITY_COMPLIANCE',
  TELECOMUNICATION_COMPLIANCE = 'TELECOMUNICATION_COMPLIANCE',
  WATER_COMPLIANCE = 'WATER_COMPLIANCE',
  OTHER_1 = 'OTHER_1',
  OTHER_2 = 'OTHER_2',
}

export interface ICompliance {
  id?: number;
  notes?: any;
  dueDate?: Moment;
  type?: ComplianceType;
  createdBy?: string;
  updatedBy?: string;
  updatedAt?: Moment;
  createdAt?: Moment;
  file?: IFile;
  project?: IProject;
}

export class Compliance implements ICompliance {
  constructor(
    public id?: number,
    public notes?: any,
    public dueDate?: Moment,
    public type?: ComplianceType,
    public createdBy?: string,
    public updatedBy?: string,
    public updatedAt?: Moment,
    public createdAt?: Moment,
    public file?: IFile,
    public project?: IProject
  ) {}
}

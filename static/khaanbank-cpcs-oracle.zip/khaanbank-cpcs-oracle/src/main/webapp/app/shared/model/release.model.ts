import { Moment } from 'moment';
import { IFacility } from 'app/shared/model/facility.model';

export enum ReleaseStatus {
  NOT_RELEASED = 'NOT_RELEASED',
  PURCHASED_BY_FINANCING = 'PURCHASED_BY_FINANCING',
  PURCHASED_BY_CASH = 'PURCHASED_BY_CASH',
  BARTERED = 'BARTERED',
  OTHER = 'OTHER',
}

export interface IRelease {
  id?: number;
  releasedDate?: Moment;
  notes?: string;
  status?: ReleaseStatus;
  releaseNumber?: number;
  updatedBy?: string;
  updatedAt?: Moment;
  createdAt?: Moment;
  facility?: IFacility;
}

export class Release implements IRelease {
  constructor(
    public id?: number,
    public releasedDate?: Moment,
    public notes?: string,
    public status?: ReleaseStatus,
    public releaseNumber?: number,
    public updatedBy?: string,
    public updatedAt?: Moment,
    public createdAt?: Moment,
    public facility?: IFacility
  ) {}
}

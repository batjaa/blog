export const ITEMS_PER_PAGE = 10;
export const HEADER_HEIGHT = 70;
export const ROW_HEIGHT = 70;

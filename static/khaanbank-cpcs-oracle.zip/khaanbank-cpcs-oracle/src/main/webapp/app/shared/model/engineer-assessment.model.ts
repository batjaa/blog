import { IGrant } from 'app/shared/model/grant.model';
import { IFile } from 'app/shared/model/file.model';
import { IProject } from 'app/shared/model/project.model';

export enum EngineerAssessmentType {
  FIRST_ASSESMENT = 'FIRST_ASSESMENT',
  GRANT = 'GRANT',
  MID_ASSESMENT = 'MID_ASSESMENT',
  ADDITIONAL_GRANT = 'ADDITIONAL_GRANT',
}

export interface IEngineerAssessment {
  id?: number;
  type?: EngineerAssessmentType;
  notes?: any;
  createdBy?: string;
  updatedBy?: string;
  grant?: IGrant;
  files?: IFile[];
  project?: IProject;
}

export class EngineerAssessment implements IEngineerAssessment {
  constructor(
    public id?: number,
    public type?: EngineerAssessmentType,
    public notes?: any,
    public createdBy?: string,
    public updatedBy?: string,
    public grant?: IGrant,
    public files?: IFile[],
    public project?: IProject
  ) {}
}

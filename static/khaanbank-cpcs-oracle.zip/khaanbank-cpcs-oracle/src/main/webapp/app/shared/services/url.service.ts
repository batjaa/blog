import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root',
})
export class UrlService {
  constructor(private router: Router) {}

  getCurrentUrlFragment() {
    return this.router.url;
  }

  isActiveUrl(url: string) {
    return this.router.isActive(url, false);
  }

  navigateUrl(url: string) {
    this.router.navigate([url]);
  }

  changeUrl(url: string) {
    this.router.navigateByUrl(url);
  }

  changeUrlPopup(parentUrl: string, name: string, url: string) {
    if (parentUrl === undefined) {
      parentUrl = '';
    } else {
      parentUrl += '/';
    }

    const outletPath = name + ':' + url;
    const path = parentUrl + '(' + outletPath + ')';

    this.router.navigateByUrl(path);
  }
}

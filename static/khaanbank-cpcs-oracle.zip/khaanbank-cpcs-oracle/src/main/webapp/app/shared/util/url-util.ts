export class UrlUtil {
  static hasUrlPopup(url: string) {
    if (url === undefined) {
      return false;
    }

    return url.match(/.+\/\(.+\)$/g);
  }

  static replaceUrlPopup(url: string, replaceUrl: string) {
    if (url === undefined) {
      return '';
    }

    return url.replace(/\/\(.+\)$/g, replaceUrl);
  }
}

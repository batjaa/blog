import { NgModule } from '@angular/core';

import { KhanbankCpmsSharedLibsModule, JhiAlertComponent, JhiAlertErrorComponent } from './';

@NgModule({
  imports: [KhanbankCpmsSharedLibsModule],
  declarations: [JhiAlertComponent, JhiAlertErrorComponent],
  exports: [KhanbankCpmsSharedLibsModule, JhiAlertComponent, JhiAlertErrorComponent],
})
export class KhanbankCpmsSharedCommonModule {}

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ExcerptPipe } from './excerpt.pipe';
import { GetValueByKeyPipe } from './get-value-by-key.pipe';
import { RelativeTimePipe } from './relative-time.pipe';
import { FindLanguageFromKeyPipe } from './find-language-from-key.pipe';
import { DateFormatPipe } from './date-format.pipe';
import { SafeHtmlPipe } from './safe-html.pipe';
import { TruncateHtmlPipe } from './truncate-html.pipe';

const pipes = [ExcerptPipe, GetValueByKeyPipe, RelativeTimePipe, FindLanguageFromKeyPipe, DateFormatPipe, SafeHtmlPipe, TruncateHtmlPipe];

@NgModule({
  imports: [CommonModule],
  declarations: pipes,
  exports: pipes,
})
export class SharedPipesModule {}

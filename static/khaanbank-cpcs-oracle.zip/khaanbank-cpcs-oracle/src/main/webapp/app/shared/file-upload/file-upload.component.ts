import { Component, EventEmitter, Injectable, Input, Output } from '@angular/core';
import { SERVER_API_URL } from 'app/app.constants';
import { AuthServerProvider } from 'app/core/auth/auth-jwt.service';
import { FileUploader } from 'ng2-file-upload';

@Injectable({
  providedIn: 'root',
})
@Component({
  selector: 'jhi-file-upload-component',
  templateUrl: './file-upload.component.html',
  styleUrls: ['./file-upload.component.scss'],
})
export class FileUploadComponent {
  @Input() multiple = false;
  @Input() allowedMimeType: string[];
  @Input() allowDragDrop = false;
  @Input() autoUpload = true;

  @Output() onFileUpload: EventEmitter<any> = new EventEmitter();

  public uploader: FileUploader;
  public response: string;
  public hasDropZoneOver = false;

  constructor(private jwt: AuthServerProvider) {
    this.uploader = new FileUploader({
      url: SERVER_API_URL + 'api/files',
      authToken: `Bearer ${jwt.getToken()}`,
      autoUpload: this.autoUpload,
      allowedMimeType: this.allowedMimeType,
      queueLimit: 10,
    });

    this.response = '';

    this.uploader.response.subscribe(res => (this.response = res));
    this.uploader.response.subscribe(res => this.onFileUpload.emit(JSON.parse(res)));
  }

  public fileOverDropZone(e: any): void {
    this.hasDropZoneOver = e;
  }
}

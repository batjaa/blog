import { Moment } from 'moment';
import { IFacility } from 'app/shared/model/facility.model';
import { IInstallment } from 'app/shared/model/installment.model';

export enum FacilityStatus {
  TO_BE_PURCHASED = 'TO_BE_PURCHASED',
  ORDER_RECEIVED = 'ORDER_RECEIVED',
  PURCHASED = 'PURCHASED',
  BARTERED = 'BARTERED',
}

export enum PaymentTerm {
  FINANCED_BY_KHAANBANK = 'FINANCED_BY_KHAANBANK',
  FINANCED_BY_OTHER = 'FINANCED_BY_OTHER',
  CASH = 'CASH',
}

export interface ITrade {
  id?: number;
  name?: string;
  status?: FacilityStatus;
  purchaser?: string;
  purchasedAt?: Moment;
  pricePerUnit?: number;
  discount?: number;
  downPayment?: number;
  paymentTerm?: PaymentTerm;
  numberOfInstall?: number;
  updatedBy?: string;
  updatedAt?: Moment;
  createdAt?: Moment;
  facility?: IFacility;
  installments?: IInstallment[];
}

export class Trade implements ITrade {
  constructor(
    public id?: number,
    public name?: string,
    public status?: FacilityStatus,
    public purchaser?: string,
    public purchasedAt?: Moment,
    public pricePerUnit?: number,
    public discount?: number,
    public downPayment?: number,
    public paymentTerm?: PaymentTerm,
    public numberOfInstall?: number,
    public updatedBy?: string,
    public updatedAt?: Moment,
    public createdAt?: Moment,
    public facility?: IFacility,
    public installments?: IInstallment[]
  ) {}
}

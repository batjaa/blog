import { Pipe, PipeTransform } from '@angular/core';
import truncate from 'truncate-html';
/*
 * truncate html
 * Takes an length argument that defaults to 150.
 * Usage:
 *   value | truncateHtml:exponent
 * Example:
 *   {{ '<p><img src="xxx.jpg">Hello from earth!</p>' | truncateHtml:10 }}
 *   formats to: <p><img src="abc.png">This is a ...</p>
 */
@Pipe({ name: 'truncateHtml' })
export class TruncateHtmlPipe implements PipeTransform {
  transform(html: string, length = 150): string {
    return truncate(html, length);
  }
}

import { Moment } from 'moment';
import { IProject } from 'app/shared/model/project.model';
import { IProjectCostEstimateSubmission } from 'app/shared/model/project-cost-estimate-submission.model';

export interface IProjectCostEstimate {
  id?: number;
  name?: string;
  raw?: any;
  updatedBy?: string;
  updatedAt?: Moment;
  createdAt?: Moment;
  project?: IProject;
  projectCostEstimateSubmissions?: IProjectCostEstimateSubmission[];
}

export class ProjectCostEstimate implements IProjectCostEstimate {
  constructor(
    public id?: number,
    public name?: string,
    public raw?: any,
    public updatedBy?: string,
    public updatedAt?: Moment,
    public createdAt?: Moment,
    public project?: IProject,
    public projectCostEstimateSubmissions?: IProjectCostEstimateSubmission[]
  ) {}
}

import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { SharedDirectivesModule } from './directives/shared-directives.module';
import { SharedPipesModule } from './pipes/shared-pipes.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { KhanbankCpmsSharedLibsModule, KhanbankCpmsSharedCommonModule, HasAnyAuthorityDirective } from './';
import { FileUploadComponent } from './file-upload/file-upload.component';
import { FileUploadModule } from 'ng2-file-upload';
import { DeletePopupComponent, DeleteDialogComponent } from './components/delete-dialog/delete-dialog.component';
import { DualListComponent } from './components/dual-list/dual-list.component';

@NgModule({
  imports: [KhanbankCpmsSharedLibsModule, KhanbankCpmsSharedCommonModule, FileUploadModule, SharedPipesModule],
  declarations: [FileUploadComponent, HasAnyAuthorityDirective, DeletePopupComponent, DeleteDialogComponent, DualListComponent],
  entryComponents: [FileUploadComponent, DeletePopupComponent, DeleteDialogComponent, DualListComponent],

  exports: [
    KhanbankCpmsSharedLibsModule,
    SharedPipesModule,
    FileUploadComponent,
    HasAnyAuthorityDirective,
    DeletePopupComponent,
    DeleteDialogComponent,
    DualListComponent,
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class KhanbankCpmsSharedModule {
  static forRoot() {
    return {
      ngModule: KhanbankCpmsSharedModule,
      SharedDirectivesModule,
      SharedPipesModule,
      NgbModule,
    };
  }
}

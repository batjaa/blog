export class Account {
  constructor(public authorities: string[], public langKey: string, public login: string) {}
}

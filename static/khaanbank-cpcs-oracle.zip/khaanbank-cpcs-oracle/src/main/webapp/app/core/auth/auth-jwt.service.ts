import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { LocalStorageService, SessionStorageService } from 'ngx-webstorage';

import { SERVER_API_URL } from 'app/app.constants';

@Injectable({ providedIn: 'root' })
export class AuthServerProvider {
  constructor(private http: HttpClient, private $localStorage: LocalStorageService, private $sessionStorage: SessionStorageService) {}

  getToken() {
    return this.$localStorage.retrieve('authenticationToken') || this.$sessionStorage.retrieve('authenticationToken');
  }

  login(credentials): Observable<any> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/x-www-form-urlencoded',
      Authorization: 'Basic ' + btoa('QXErxJeriykMyVWQAx08WqSmSIIBw70t:OGshEGhpk2RIQLS1OdGOdNINFcAce6uJ'),
    });

    const params = new URLSearchParams();
    params.append('username', credentials.username);
    params.append('password', credentials.password);
    params.append('grant_type', 'password');

    return this.http.post(SERVER_API_URL + 'oauth/token', params.toString(), { headers }).pipe(map(authenticateSuccess.bind(this)));

    function authenticateSuccess(resp) {
      const accessToken = resp.access_token;
      this.storeAuthenticationToken(accessToken, credentials.rememberMe);
      return accessToken;
    }
  }

  loginWithToken(accessToken, rememberMe) {
    if (accessToken) {
      this.storeAuthenticationToken(accessToken, rememberMe);
      return Promise.resolve(accessToken);
    } else {
      return Promise.reject('auth-accessToken-service Promise reject'); // Put appropriate error message here
    }
  }

  storeAuthenticationToken(accessToken, rememberMe) {
    if (rememberMe) {
      this.$localStorage.store('authenticationToken', accessToken);
    } else {
      this.$sessionStorage.store('authenticationToken', accessToken);
    }
  }

  logout(): Observable<any> {
    return new Observable(observer => {
      this.$localStorage.clear('authenticationToken');
      this.$sessionStorage.clear('authenticationToken');
      observer.complete();
    });
  }
}

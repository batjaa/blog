import { Component, OnInit } from '@angular/core';
import { JhiLanguageHelper } from 'app/core';
import {
  Router,
  ActivatedRouteSnapshot,
  NavigationEnd,
  NavigationError,
  RouteConfigLoadStart,
  ResolveStart,
  RouteConfigLoadEnd,
  ResolveEnd,
} from '@angular/router';
import { NavigationService } from 'app/shared/services/navigation.service';
import { SearchService } from 'app/shared/services/search.service';

@Component({
  selector: 'jhi-admin-layout',
  templateUrl: './admin-layout.component.html',
})
export class AdminLayoutComponent implements OnInit {
  moduleLoading: boolean;

  constructor(
    private jhiLanguageHelper: JhiLanguageHelper,
    private router: Router,
    public navService: NavigationService,
    public searchService: SearchService
  ) {
    this.moduleLoading = false;
  }

  private getPageTitle(routeSnapshot: ActivatedRouteSnapshot) {
    let title: string = routeSnapshot.data && routeSnapshot.data['pageTitle'] ? routeSnapshot.data['pageTitle'] : 'khanbankCpmsApp';
    if (routeSnapshot.firstChild) {
      title = this.getPageTitle(routeSnapshot.firstChild) || title;
    }
    return title;
  }

  ngOnInit() {
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        this.jhiLanguageHelper.updateTitle(this.getPageTitle(this.router.routerState.snapshot.root));
      }
      if (event instanceof NavigationError && event.error.status === 404) {
        this.router.navigate(['/404']);
      }
    });

    this.router.events.subscribe(event => {
      if (event instanceof RouteConfigLoadStart || event instanceof ResolveStart) {
        this.moduleLoading = true;
      }
      if (event instanceof RouteConfigLoadEnd || event instanceof ResolveEnd) {
        this.moduleLoading = false;
      }
    });
  }
}

import { HttpErrorResponse, HttpHeaders, HttpResponse } from '@angular/common/http';
import { Component, ElementRef, EventEmitter, Input, OnDestroy, OnInit, Output, ViewChild } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { DatatableComponent } from '@swimlane/ngx-datatable';
import { AccountService } from 'app/core';
import { HEADER_HEIGHT, ITEMS_PER_PAGE, ROW_HEIGHT } from 'app/shared';
import { IProjectCostEstimateSubmission, ProjectCostEstimateSubmission } from 'app/shared/model/project-cost-estimate-submission.model';
import { Project } from 'app/shared/model/project.model';
import { FileService } from 'app/shared/services/file.service';
import { UrlService } from 'app/shared/services/url.service';
import { JhiAlertService, JhiEventManager, JhiParseLinks } from 'ng-jhipster';
import { Observable, Subscription } from 'rxjs';
import { ProjectCostEstimateSubmissionService } from './project-cost-estimate-submission.service';

@Component({
  selector: 'jhi-project-cost-estimate-submission',
  templateUrl: './project-cost-estimate-submission.component.html',
  styleUrls: ['./project-cost-estimate-submission.component.scss'],
})
export class ProjectCostEstimateSubmissionComponent implements OnInit, OnDestroy {
  @Input() project?: Project;
  @Output() submissionSelected = new EventEmitter<ProjectCostEstimateSubmission>();
  @ViewChild(DatatableComponent) ngxDatatable: DatatableComponent;
  readonly headerHeight: number;
  readonly rowHeight: number;
  isLoading: boolean;
  projectCostEstimateSubmissions: IProjectCostEstimateSubmission[];
  currentAccount: any;
  eventSubscriber: Subscription;
  itemsPerPage: number;
  links: any;
  page: any;
  predicates = [];
  totalItems: number;
  private projectId: number;
  selectedRows = [];

  constructor(
    protected activatedRoute: ActivatedRoute,
    protected urlService: UrlService,
    protected jhiAlertService: JhiAlertService,
    protected storageService: FileService,
    protected projectCostEstimateSubmissionService: ProjectCostEstimateSubmissionService,
    protected eventManager: JhiEventManager,
    protected parseLinks: JhiParseLinks,
    protected accountService: AccountService,
    protected router: Router,
    protected element: ElementRef
  ) {
    this.projectCostEstimateSubmissions = [];
    this.itemsPerPage = ITEMS_PER_PAGE;
    this.headerHeight = HEADER_HEIGHT;
    this.rowHeight = ROW_HEIGHT;
    this.page = 0;
    this.links = {
      last: 0,
    };
    this.predicates = [
      {
        name: 'submittedAt',
        reverse: true,
      },
    ];
    this.projectId = null;
  }

  loadAll() {
    this.isLoading = true;
    this.activatedRoute.parent.parent.params.subscribe((params: Params) => {
      this.projectId = Number.parseInt(params['id'], 10);
    });
    this.projectCostEstimateSubmissionService
      .findByProjectId(this.projectId, {
        page: this.page,
        size: this.itemsPerPage,
        sort: this.sort(),
      })
      .subscribe(
        (res: HttpResponse<IProjectCostEstimateSubmission[]>) => {
          const projectCostEstimateSubmissions: IProjectCostEstimateSubmission[] = res.body;
          this.paginateProjectCostEstimateSubmissions(projectCostEstimateSubmissions, res.headers);
          if (projectCostEstimateSubmissions.length) {
            this.submissionSelected.emit(projectCostEstimateSubmissions[0]);
            this.selectedRows = [projectCostEstimateSubmissions[0]];
          }
        },
        (res: HttpErrorResponse) => this.onError(res.message)
      );
  }

  reset() {
    this.page = 0;
    this.projectCostEstimateSubmissions = [];
    this.ngxDatatable.bodyComponent.offsetY = 0;
    this.loadAll();
  }

  onScroll(offsetY: number) {
    // харагдаж байгаа мөрүүдийн нийт өндөр
    const viewHeight = this.element.nativeElement.getBoundingClientRect().height - this.headerHeight;

    // scroll хамгийн доод хэсэгт очсон эсэхийг шалгах
    if (!this.isLoading && offsetY + viewHeight >= this.projectCostEstimateSubmissions.length * this.rowHeight) {
      this.loadPage(this.page);
    }
  }

  loadPage(page) {
    this.page = page + 1;
    if (this.page > this.links['last']) {
      return null;
    }
    this.loadAll();
  }

  ngOnInit() {
    this.loadAll();
    this.accountService.identity().then(account => {
      this.currentAccount = account;
    });
    this.registerChangeInProjectCostEstimateSubmissions();
  }

  ngOnDestroy() {
    this.eventManager.destroy(this.eventSubscriber);
  }

  trackId(index: number, item: IProjectCostEstimateSubmission) {
    return item.id;
  }

  registerChangeInProjectCostEstimateSubmissions() {
    this.eventSubscriber = this.eventManager.subscribe('projectCostEstimateSubmissionListModification', response => this.reset());
  }

  sort() {
    const result = this.predicates.map(function(predicate) {
      return predicate.name + ',' + (predicate.reverse ? 'asc' : 'desc');
    });
    return result;
  }

  onSort(event) {
    const sort = event.sorts[0];
    this.predicates = [
      {
        name: sort.prop,
        reverse: !this.predicates[0].reverse,
      },
    ];
    this.reset();
  }

  protected paginateProjectCostEstimateSubmissions(data: IProjectCostEstimateSubmission[], headers: HttpHeaders) {
    this.links = this.parseLinks.parse(headers.get('link'));
    this.totalItems = parseInt(headers.get('X-Total-Count'), 10);
    const rows = this.projectCostEstimateSubmissions;
    for (let i = 0; i < data.length; i++) {
      rows.push(data[i]);
    }
    this.projectCostEstimateSubmissions = rows;
    this.isLoading = false;
  }

  protected onError(errorMessage: string) {
    this.jhiAlertService.error(errorMessage, null, null);
  }

  onSelect({ selected }) {
    this.submissionSelected.emit(selected[0]);
    this.selectedRows = [selected[0]];
    event.stopPropagation();
  }

  onDelete(event: any, id: number) {
    this.router.navigate([{ outlets: { popup: id + '/delete' } }], { relativeTo: this.activatedRoute });
    event.stopPropagation();
  }

  onFileDownload(event: any, fileId: number, fileName: string) {
    this.storageService.downloadFile(fileId).subscribe(
      value => {
        if (window.navigator && window.navigator.msSaveOrOpenBlob) {
          // save file for IE
          window.navigator.msSaveOrOpenBlob(value, fileName);
        } else {
          // save for other browsers: Chrome, Firefox
          const url = window.URL.createObjectURL(value);

          const anchor = document.createElement('a');
          document.body.appendChild(anchor);

          anchor.href = url;
          anchor.download = fileName;
          anchor.click();

          window.URL.revokeObjectURL(url);
          document.body.removeChild(anchor);
        }
      },
      error => {
        console.log(error.message);
      }
    );
    event.stopPropagation();
  }

  accept(event: any, submissionId: number) {
    this.subscribeToSaveResponse(this.projectCostEstimateSubmissionService.accept(submissionId));
    event.stopPropagation();
  }

  decline(event: any, submissionId: number) {
    this.subscribeToSaveResponse(this.projectCostEstimateSubmissionService.decline(submissionId));
    event.stopPropagation();
  }

  protected subscribeToSaveResponse(result: Observable<HttpResponse<IProjectCostEstimateSubmission>>) {
    result.subscribe(
      (res: HttpResponse<IProjectCostEstimateSubmission>) => {
        this.reset();
        this.onSaveSuccess();
      },
      (res: HttpErrorResponse) => this.onSaveError()
    );
  }

  protected onSaveSuccess() {
    this.jhiAlertService.success('Success', null, null);
  }

  protected onSaveError() {
    this.jhiAlertService.error('Error', null, null);
  }

  getCellClass({ row, column, value }): any {
    return {
      is_hidden: value !== null || value === null,
    };
  }
}

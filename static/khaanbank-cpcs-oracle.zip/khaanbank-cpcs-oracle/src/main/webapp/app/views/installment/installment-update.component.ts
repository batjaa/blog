import { HttpErrorResponse, HttpResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { DATE_TIME_FORMAT } from 'app/shared/constants/input.constants';
import { IInstallment, Installment } from 'app/shared/model/installment.model';
import { ITrade } from 'app/shared/model/trade.model';
import { TradeService } from 'app/views/facility/trade';
import { JhiAlertService } from 'ng-jhipster';
import { Observable } from 'rxjs';
import { InstallmentService } from './installment.service';
import { AlertService } from '../../shared/services/alert.service';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'jhi-installment-update',
  templateUrl: './installment-update.component.html',
})
export class InstallmentUpdateComponent implements OnInit {
  installment: IInstallment;
  isSaving: boolean;

  trade: ITrade;
  installmentId: number;
  action = '';

  editForm = this.fb.group({
    id: [],
    amount: [null, [Validators.required]],
    paidAt: [null, [Validators.required]],
    trade: [],
  });

  constructor(
    protected jhiAlertService: JhiAlertService,
    protected installmentService: InstallmentService,
    protected tradeService: TradeService,
    protected activatedRoute: ActivatedRoute,
    private fb: FormBuilder,
    private alert: AlertService,
    private translateService: TranslateService
  ) {}

  ngOnInit() {
    this.isSaving = false;
    this.activatedRoute.data.subscribe(({ installment }) => {
      this.updateForm(installment);
      this.installment = installment;
    });
    this.activatedRoute.parent.data.subscribe(({ facility }) => {
      this.trade = facility.trade;
    });
  }

  updateForm(installment: IInstallment) {
    this.editForm.patchValue({
      id: installment.id,
      amount: installment.amount,
      paidAt: installment.paidAt,
      createdBy: installment.createdBy,
      updatedBy: installment.updatedBy,
      updatedAt: installment.updatedAt,
      createdAt: installment.createdAt,
      trade: installment.trade,
    });
  }

  previousState() {
    window.history.back();
  }

  save() {
    this.isSaving = true;
    const installment = this.createFromForm();
    if (installment.id !== undefined) {
      this.subscribeToSaveResponse(this.installmentService.update(installment));
    } else {
      this.subscribeToSaveResponse(this.installmentService.create(this.trade.id, installment));
    }
  }

  private createFromForm(): IInstallment {
    const entity = {
      ...new Installment(),
      amount: this.editForm.get(['amount']).value,
      paidAt: this.editForm.get(['paidAt']).value,
    };
    return entity;
  }

  protected subscribeToSaveResponse(result: Observable<HttpResponse<IInstallment>>) {
    result.subscribe((res: HttpResponse<IInstallment>) => this.onSaveSuccess(res.statusText), (res: HttpErrorResponse) => this.onSaveError(res.message));
  }

  protected onSaveSuccess(message) {
    this.isSaving = false;
    if (message === 'Created') {
      this.action = this.translateService.instant('khanbankCpmsApp.installment.created');
      this.alert.success(this.action, '', 3000);
    } else if (message === 'OK') {
      this.action = this.translateService.instant('khanbankCpmsApp.installment.created');
      this.alert.success(this.action, '', 3000);
    }
    this.previousState();
  }

  protected onSaveError(message) {
    this.alert.error(message, '', 3000);
    this.isSaving = false;
  }
  protected onError(errorMessage: string) {
    this.jhiAlertService.error(errorMessage, null, null);
  }

  trackTradeById(index: number, item: ITrade) {
    return item.id;
  }
}

import { HttpResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { IProject } from 'app/shared/model/project.model';
import { JhiDataUtils } from 'ng-jhipster';
import { filter, map } from 'rxjs/operators';
import { ReportService } from './report.service';
import { debug } from 'util';

@Component({
  selector: 'jhi-project-detail',
  templateUrl: './project-detail.component.html',
})
export class ProjectDetailComponent implements OnInit {
  project: IProject;

  totalStats: [];
  serviceStats: [];
  garageStats: [];
  flatStats: [];

  barPadding = 20;
  showXAxis = true;
  showYAxis = true;
  showGridLines = true;
  maxXAxisTickLength = 8;
  maxYAxisTickLength = 8;
  gradient = true;
  showLegend = true;
  legendPosition = 'right';
  legendTitle = 'Статус';

  colorScheme = {
    domain: ['#4285f4', '#ffc107', '#4caf50', '#f4b400', '#9c27b0', '#e91e63'],
  };

  constructor(
    protected dataUtils: JhiDataUtils,
    protected activatedRoute: ActivatedRoute,
    protected reportService: ReportService,
    protected translateService: TranslateService
  ) {}

  ngOnInit() {
    this.totalStats = [];
    this.activatedRoute.data.subscribe(({ project }) => {
      this.project = project;
    });
    this.reportService
      .getFacilityReport()
      .pipe(
        filter((mayBeOk: HttpResponse<any>) => mayBeOk.ok),
        map((response: HttpResponse<any>) => response.body)
      )
      .subscribe((res: any) => this.setStats(res));
  }

  private setStats(stats: []) {
    stats.map((stat: any) => {
      if (stat.SERVICE) {
        this.serviceStats = this.translateStat(stat.SERVICE);
      } else if (stat.GARAGE) {
        this.garageStats = this.translateStat(stat.GARAGE);
      } else if (stat.FLAT) {
        this.flatStats = this.translateStat(stat.FLAT);
      }
    });
    this.calcTotalStat();
  }

  private translateStat(stats: []) {
    stats.map((column: any) => {
      column.name = this.translateService.instant('khanbankCpmsApp.facility.'.concat(column.name));
      column.series.map((seriesVal: any) => {
        seriesVal.name = this.translateService.instant('khanbankCpmsApp.FacilityStatus.'.concat(seriesVal.name));
        return seriesVal;
      });
      return column;
    });
    return stats;
  }

  private calcTotalStat() {
    this.totalStats.push(...this.serviceStats, ...this.garageStats, ...this.flatStats);
    this.totalStats = this.totalStats.reduce(
      (function(hash) {
        return function(array, obj) {
          if (!hash[obj.name]) {
            array.push((hash[obj.name] = obj));
          } else {
            hash[obj.name].series.push(...obj.series);
            const series = hash[obj.name].series;
            const dict = Object.create(null);

            hash[obj.name].series = series.reduce(function(arr, o) {
              let current = dict[o.name];

              if (!current) {
                current = Object.assign({}, o);

                arr.push(current);

                dict[o.name] = current;
              } else {
                current.value += o.value;
              }

              return arr;
            }, []);
          }
          return array;
        };
      })({}),
      []
    );
  }

  byteSize(field) {
    return this.dataUtils.byteSize(field);
  }

  openFile(contentType, field) {
    return this.dataUtils.openFile(contentType, field);
  }

  previousState() {
    window.history.back();
  }
}

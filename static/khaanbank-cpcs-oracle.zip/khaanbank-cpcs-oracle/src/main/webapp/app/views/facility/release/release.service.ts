import { HttpClient, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { SERVER_API_URL } from 'app/app.constants';
import { IRelease } from 'app/shared/model/release.model';
import * as moment from 'moment';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

type EntityResponseType = HttpResponse<IRelease>;
type EntityArrayResponseType = HttpResponse<IRelease[]>;

@Injectable({ providedIn: 'root' })
export class ReleaseService {
  public resourceUrl = SERVER_API_URL + 'api/releases';
  public facilityApiUrl = SERVER_API_URL + 'api/facilities';

  constructor(protected http: HttpClient) {}

  create(facilityId: number, release: IRelease): Observable<EntityResponseType> {
    return this.http
      .post<IRelease>(`${this.facilityApiUrl}/${facilityId}/releases`, release, { observe: 'response' })
      .pipe(map((res: EntityResponseType) => this.convertDateFromServer(res)));
  }

  update(release: IRelease): Observable<EntityResponseType> {
    return this.http
      .put<IRelease>(this.resourceUrl, release, { observe: 'response' })
      .pipe(map((res: EntityResponseType) => this.convertDateFromServer(res)));
  }

  findByFacilityId(id: number): Observable<EntityResponseType> {
    return this.http
      .get<IRelease>(`${this.facilityApiUrl}/${id}/release`, { observe: 'response' })
      .pipe(map((res: EntityResponseType) => this.convertDateFromServer(res)));
  }

  protected convertDateFromServer(res: EntityResponseType): EntityResponseType {
    if (res.body) {
      res.body.releasedDate = res.body.releasedDate != null ? moment(res.body.releasedDate) : null;
      res.body.updatedAt = res.body.updatedAt != null ? moment(res.body.updatedAt) : null;
      res.body.createdAt = res.body.createdAt != null ? moment(res.body.createdAt) : null;
    }
    return res;
  }

  protected convertDateArrayFromServer(res: EntityArrayResponseType): EntityArrayResponseType {
    if (res.body) {
      res.body.forEach((release: IRelease) => {
        release.releasedDate = release.releasedDate != null ? moment(release.releasedDate) : null;
        release.updatedAt = release.updatedAt != null ? moment(release.updatedAt) : null;
        release.createdAt = release.createdAt != null ? moment(release.createdAt) : null;
      });
    }
    return res;
  }
}

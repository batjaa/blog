import { HttpClient, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { SERVER_API_URL } from 'app/app.constants';
import { createRequestOption } from 'app/shared';
import { IProjectCostEstimate } from 'app/shared/model/project-cost-estimate.model';
import * as moment from 'moment';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Project } from 'app/shared/model/project.model';
import { ProjectService } from '../project.service';

type EntityResponseType = HttpResponse<IProjectCostEstimate>;
type EntityArrayResponseType = HttpResponse<IProjectCostEstimate[]>;

@Injectable({ providedIn: 'root' })
export class ProjectCostEstimateService {
  public resourceUrl = SERVER_API_URL + 'api/project-cost-estimates';
  public resourceParentUrl = SERVER_API_URL + 'api/projects';

  constructor(protected http: HttpClient, protected projectService: ProjectService) {}

  find(id: number): Observable<EntityResponseType> {
    return this.http
      .get<IProjectCostEstimate>(`${this.resourceParentUrl}/${id}/cost-estimate`, { observe: 'response' })
      .pipe(map((res: EntityResponseType) => this.convertDateFromServer(res)));
  }

  findByProjectId(projectId: number): Observable<EntityResponseType> {
    return this.http.get<IProjectCostEstimate>(`${this.resourceParentUrl}/${projectId}/cost-estimate`, { observe: 'response' }).pipe(
      map((res: EntityResponseType) => this.convertDateFromServer(res)),
      map((response: EntityResponseType) => {
        const project: Project = this.projectService.projects.get(projectId);
        project.projectCostEstimate = response.body;
        return response;
      })
    );
  }

  query(req?: any): Observable<EntityArrayResponseType> {
    const options = createRequestOption(req);
    return this.http
      .get<IProjectCostEstimate[]>(this.resourceUrl, { params: options, observe: 'response' })
      .pipe(map((res: EntityArrayResponseType) => this.convertDateArrayFromServer(res)));
  }

  protected convertDateFromClient(projectCostEstimate: IProjectCostEstimate): IProjectCostEstimate {
    const copy: IProjectCostEstimate = Object.assign({}, projectCostEstimate, {
      updatedAt:
        projectCostEstimate.updatedAt != null && projectCostEstimate.updatedAt.isValid() ? projectCostEstimate.updatedAt.toJSON() : null,
      createdAt:
        projectCostEstimate.createdAt != null && projectCostEstimate.createdAt.isValid() ? projectCostEstimate.createdAt.toJSON() : null,
    });
    return copy;
  }

  protected convertDateFromServer(res: EntityResponseType): EntityResponseType {
    if (res.body) {
      res.body.updatedAt = res.body.updatedAt != null ? moment(res.body.updatedAt) : null;
      res.body.createdAt = res.body.createdAt != null ? moment(res.body.createdAt) : null;
    }
    return res;
  }

  protected convertDateArrayFromServer(res: EntityArrayResponseType): EntityArrayResponseType {
    if (res.body) {
      res.body.forEach((projectCostEstimate: IProjectCostEstimate) => {
        projectCostEstimate.updatedAt = projectCostEstimate.updatedAt != null ? moment(projectCostEstimate.updatedAt) : null;
        projectCostEstimate.createdAt = projectCostEstimate.createdAt != null ? moment(projectCostEstimate.createdAt) : null;
      });
    }
    return res;
  }
}

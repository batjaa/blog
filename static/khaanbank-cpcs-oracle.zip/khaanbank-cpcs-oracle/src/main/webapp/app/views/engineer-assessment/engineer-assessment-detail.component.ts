import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { JhiDataUtils } from 'ng-jhipster';

import { IEngineerAssessment } from 'app/shared/model/engineer-assessment.model';

@Component({
  selector: 'jhi-engineer-assessment-detail',
  templateUrl: './engineer-assessment-detail.component.html',
})
export class EngineerAssessmentDetailComponent implements OnInit {
  engineerAssessment: IEngineerAssessment;

  constructor(protected dataUtils: JhiDataUtils, protected activatedRoute: ActivatedRoute) {}

  ngOnInit() {
    this.activatedRoute.data.subscribe(({ engineerAssessment }) => {
      this.engineerAssessment = engineerAssessment;
    });
  }

  byteSize(field) {
    return this.dataUtils.byteSize(field);
  }

  openFile(contentType, field) {
    return this.dataUtils.openFile(contentType, field);
  }
  previousState() {
    window.history.back();
  }
}

import { HttpErrorResponse, HttpResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import * as BalloonEditor from '@ckeditor/ckeditor5-build-balloon';
import { TranslateService } from '@ngx-translate/core';
import { IFacility } from 'app/shared/model/facility.model';
import { IRelease, Release, ReleaseStatus } from 'app/shared/model/release.model';
import { FacilityService } from 'app/views/facility';
import { JhiAlertService } from 'ng-jhipster';
import { Observable } from 'rxjs';
import { ReleaseService } from './release.service';
import { AlertService } from '../../../shared/services/alert.service';

@Component({
  selector: 'jhi-release-update',
  templateUrl: './release-update.component.html',
  styleUrls: ['./release-update.component.scss'],
})
export class ReleaseUpdateComponent implements OnInit {
  release: IRelease;
  isSaving: boolean;
  releaseStatus = Object.keys(ReleaseStatus);
  facilityid: number;
  Editor = BalloonEditor;
  editorConfig = {};
  isShowCreate: boolean;
  editForm = this.fb.group({
    notes: '',
    status: [null, [Validators.required]],
    releaseNumber: [],
  });

  action = '';

  constructor(
    protected jhiAlertService: JhiAlertService,
    protected releaseService: ReleaseService,
    protected facilityService: FacilityService,
    protected activatedRoute: ActivatedRoute,
    private translateService: TranslateService,
    private fb: FormBuilder,
    private alert: AlertService
  ) {
    this.editorConfig = {
      removePlugins: ['ImageUpload', 'MediaEmbed'],
      placeholder: translateService.instant('khanbankCpmsApp.release.notes'),
    };
  }

  ngOnInit() {
    window.scroll(0, 0);
    this.isSaving = false;
    this.isShowCreate = false;

    this.activatedRoute.data.subscribe(({ facility }) => {
      if (facility.release !== null) {
        this.updateForm(facility.release);
        this.release = facility.release;
        this.isShowCreate = true;
      }
      this.facilityid = facility.id;
    });
  }

  updateForm(release: IRelease) {
    this.editForm.patchValue({
      id: release.id,
      notes: release.notes,
      status: release.status,
      releaseNumber: release.releaseNumber,
    });
  }

  previousState() {
    window.history.back();
  }

  showCreate() {
    this.isShowCreate = true;
    this.editForm.reset();
  }
  save() {
    this.isSaving = true;
    const release = this.createFromForm();
    if (release.id !== undefined) {
      this.subscribeToSaveResponse(this.releaseService.update(release));
    } else {
      this.subscribeToSaveResponse(this.releaseService.create(this.facilityid, release));
    }
  }

  private createFromForm(): IRelease {
    const entity = {
      ...new Release(),
      notes: this.editForm.get('notes').value,
      status: this.editForm.get(['status']).value,
      releaseNumber: this.editForm.get(['releaseNumber']).value,
    };
    return entity;
  }

  protected subscribeToSaveResponse(result: Observable<HttpResponse<IRelease>>) {
    result.subscribe((res: HttpResponse<IRelease>) => this.onSaveSuccess(res.statusText), (res: HttpErrorResponse) => this.onSaveError(res.message));
  }

  protected onSaveSuccess(message) {
    this.isSaving = false;
    if (message === 'Created') {
      this.action = this.translateService.instant('khanbankCpmsApp.release.created', { param:  this.editForm.get('notes').value });
      this.alert.success(this.action, '', 3000);
    } else if (message === 'OK') {
      this.action = this.translateService.instant('khanbankCpmsApp.release.updated', { param:  this.editForm.get('notes').value });
      this.alert.success(this.action, '', 3000);
    }
  }

  protected onSaveError(message) {
    this.isSaving = false;
    this.alert.error(message, '', 3000);
  }
  protected onError(errorMessage: string) {
    this.jhiAlertService.error(errorMessage, null, null);
  }

  trackFacilityById(index: number, item: IFacility) {
    return item.id;
  }
}

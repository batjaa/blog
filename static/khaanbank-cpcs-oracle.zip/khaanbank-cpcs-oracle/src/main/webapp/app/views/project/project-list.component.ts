import { HttpErrorResponse, HttpHeaders, HttpResponse } from '@angular/common/http';
import { Component, OnDestroy, OnInit, ElementRef, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AccountService } from 'app/core';
import { ITEMS_PER_PAGE, HEADER_HEIGHT, ROW_HEIGHT } from 'app/shared';
import { IProject, ProjectStatus } from 'app/shared/model/project.model';
import { JhiAlertService, JhiDataUtils, JhiEventManager, JhiParseLinks } from 'ng-jhipster';
import { Subscription } from 'rxjs';
import { ProjectService } from './project.service';
import { ICompany } from 'app/shared/model/company.model';
import { DatatableComponent } from '@swimlane/ngx-datatable';

@Component({
  selector: 'jhi-project-list',
  templateUrl: './project-list.component.html',
  styleUrls: ['./project.component.scss'],
})
export class ProjectListComponent implements OnInit, OnDestroy {
  readonly rowHeight: number;
  readonly headerHeight: number;

  isLoading: boolean;
  projects: IProject[];
  companies: ICompany[];
  currentAccount: any;
  eventSubscriber: Subscription;
  itemsPerPage: number;
  links: any;
  page: any;
  predicates = [];
  totalItems: number;
  private filterStatus: ProjectStatus;
  private filterCompanyId: number;

  @ViewChild(DatatableComponent) ngxDatatable: DatatableComponent;

  constructor(
    protected activatedRoute: ActivatedRoute,
    protected projectService: ProjectService,
    protected jhiAlertService: JhiAlertService,
    protected dataUtils: JhiDataUtils,
    protected eventManager: JhiEventManager,
    protected parseLinks: JhiParseLinks,
    protected router: Router,
    protected accountService: AccountService,
    protected element: ElementRef
  ) {
    this.projects = [];
    this.companies = [];
    this.filterStatus = ProjectStatus.IN_PROGRESS;
    this.filterCompanyId = null;
    this.itemsPerPage = ITEMS_PER_PAGE;
    this.headerHeight = HEADER_HEIGHT;
    this.rowHeight = ROW_HEIGHT;
    this.page = 0;
    this.links = {
      last: 0,
    };
    this.predicates = [
      {
        name: 'name',
        reverse: false,
      },
      {
        name: 'company',
        reverse: false,
      },
    ];
  }
  loadAll() {
    this.isLoading = true;
    const queryParams = {
      page: this.page,
      size: this.itemsPerPage,
      sort: this.sort(),
      'filter[status]': this.filterStatus == null ? undefined : this.filterStatus,
      'filter[company_id]': this.filterCompanyId == null ? undefined : this.filterCompanyId,
    };

    this.projectService
      .query(queryParams)
      .subscribe(
        (res: HttpResponse<IProject[]>) => this.paginateProjects(res.body, res.headers),
        (res: HttpErrorResponse) => this.onError(res.message)
      );
  }

  onScroll(offsetY: number) {
    // харагдаж байгаа мөрүүдийн нийт өндөр
    const viewHeight = this.element.nativeElement.getBoundingClientRect().height - this.headerHeight;

    // scroll хамгийн доод хэсэгт очсон эсэхийг шалгах
    if (!this.isLoading && offsetY + viewHeight >= this.projects.length * this.rowHeight) {
      this.loadPage(this.page);
    }
  }

  search(keyword: string) {
    if (keyword.length === 0) {
      this.reset(true);
      return;
    } else if (keyword.length < 2) {
      return;
    }
    this.reset(false);
    this.projectService
      .search(keyword)  
      .subscribe(
        (res: HttpResponse<IProject[]>) => this.paginateProjects(res.body, res.headers),
        (res: HttpErrorResponse) => this.onError(res.message)
      );
  }

  reset(force: boolean) {
    this.page = 0;
    this.projects = [];
    this.ngxDatatable.bodyComponent.offsetY = 0;
    if (force) {
      this.loadAll();
    }
  }

  loadPage(page) {
    this.page = page + 1;
    if (this.page > this.links['last']) {
      return;
    }
    this.loadAll();
  }

  ngOnInit() {
    this.loadAll();
    this.accountService.identity().then(account => {
      this.currentAccount = account;
    });
    this.registerChangeInProjects();
  }

  ngOnDestroy() {
    this.eventManager.destroy(this.eventSubscriber);
  }

  trackId(index: number, item: IProject) {
    return item.id;
  }

  byteSize(field) {
    return this.dataUtils.byteSize(field);
  }

  openFile(contentType, field) {
    return this.dataUtils.openFile(contentType, field);
  }

  registerChangeInProjects() {
    this.eventSubscriber = this.eventManager.subscribe('projectListModification', response => this.reset(true));
  }

  sort() {
    const result = this.predicates.map(function(predicate) {
      return predicate.name + ',' + (predicate.reverse ? 'asc' : 'desc');
    });
    return result;
  }

  onSort(event) {
    const sort = event.sorts[0];
    this.predicates = [
      {
        name: sort.prop,
        reverse: !this.predicates[0].reverse,
      },
    ];
    this.reset(true);
  }

  onSelectChange(value, type: string) {
    if (type.match('status')) {
      this.filterStatus = value.match('null') ? undefined : value;
    } else if (type.match('company')) {
      this.filterCompanyId = value.match('null') ? undefined : value;
    }

    this.reset(true);
  }

  protected paginateProjects(data: IProject[], headers: HttpHeaders) {
    this.links = this.parseLinks.parse(headers.get('link'));
    this.totalItems = parseInt(headers.get('X-Total-Count'), 10);

    for (let i = 0; i < data.length; i++) {
      this.companies.push(data[i].company);
      this.projects.push(data[i]);
    }

    this.projects = [...this.projects];

    this.companies = this.getUnique(this.companies, 'id');
    this.isLoading = false;
  }

  protected onError(errorMessage: string) {
    this.jhiAlertService.error(errorMessage, null, null);
  }

  onSelect({ selected }) {
    this.router.navigate([selected[0].id], { relativeTo: this.activatedRoute });
  }

  onEdit(event, id) {
    this.router.navigate(['/project', id, 'edit']);
    event.stopPropagation();
  }

  onDelete(event, id) {
    this.router.navigate(['/project', { outlets: { popup: id + '/delete' } }]);
    event.stopPropagation();
  }

  getUnique(arr, comp) {
    const unique = arr
      .map(e => e[comp])
      .map((e, i, final) => final.indexOf(e) === i && i)
      .filter(e => arr[e])
      .map(e => arr[e]);

    return unique;
  }
}

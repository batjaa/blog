import { HttpErrorResponse, HttpResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Params } from '@angular/router';
import { IBuilding } from 'app/shared/model/building.model';
import { Facility, FacilityType, IFacility } from 'app/shared/model/facility.model';
import { IRelease } from 'app/shared/model/release.model';
import { ITrade } from 'app/shared/model/trade.model';
import { BuildingService } from 'app/views/building';
import { ReleaseService } from 'app/views/facility/release';
import { TradeService } from 'app/views/facility/trade';
import { JhiAlertService } from 'ng-jhipster';
import { Observable } from 'rxjs';
import { filter, map } from 'rxjs/operators';
import { FacilityService } from './facility.service';
import { AlertService } from '../../shared/services/alert.service';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'jhi-facility-update',
  templateUrl: './facility-update.component.html',
})
export class FacilityUpdateComponent implements OnInit {
  facility: IFacility;
  isSaving: boolean;
  id: number;
  facilityTypes = Object.keys(FacilityType);
  buildings: IBuilding[];
  action = '';

  editForm = this.fb.group({
    number: [null, [Validators.required]],
    area: [null, [Validators.required]],
    type: [null, [Validators.required]],
    building: [null, [Validators.required]],
  });

  constructor(
    protected jhiAlertService: JhiAlertService,
    protected facilityService: FacilityService,
    protected tradeService: TradeService,
    protected releaseService: ReleaseService,
    protected buildingService: BuildingService,
    protected activatedRoute: ActivatedRoute,
    private fb: FormBuilder,
    private alert: AlertService,
    private translateService: TranslateService
  ) {}

  ngOnInit() {
    this.isSaving = false;
    this.activatedRoute.parent.parent.params.subscribe((params: Params) => {
      this.id = params['id'];
    });
    this.activatedRoute.data.subscribe(({ facility }) => {
      this.updateForm(facility);
      this.facility = facility;
    });

    this.buildingService
      .findByProjectId(this.id)
      .pipe(
        filter((mayBeOk: HttpResponse<IBuilding[]>) => mayBeOk.ok),
        map((response: HttpResponse<IBuilding[]>) => response.body)
      )
      .subscribe((res: IBuilding[]) => (this.buildings = res), (res: HttpErrorResponse) => this.onError(res.message));
    this.editForm.get('type').patchValue(this.editForm.get('type').value || null);
  }

  updateForm(facility: IFacility) {
    this.editForm.patchValue({
      number: facility.number,
      area: facility.area,
      type: facility.type,
      updatedBy: facility.updatedBy,
      building: facility.building,
    });
  }

  previousState() {
    window.history.back();
  }

  save() {
    this.isSaving = true;
    const facility = this.createFromForm();
    if (facility.id !== undefined) {
      this.subscribeToSaveResponse(this.facilityService.update(facility));
    } else {
      this.subscribeToSaveResponse(this.facilityService.create(facility));
    }
  }

  private createFromForm(): IFacility {
    const entity = {
      ...new Facility(),
      id: this.id,
      number: this.editForm.get(['number']).value,
      area: this.editForm.get(['area']).value,
      type: this.editForm.get(['type']).value,
      building: this.editForm.get(['building']).value,
    };
    return entity;
  }

  protected subscribeToSaveResponse(result: Observable<HttpResponse<IFacility>>) {
    result.subscribe((res: HttpResponse<IFacility>) => this.onSaveSuccess(res.statusText), (res: HttpErrorResponse) => this.onSaveError(res.message));
  }

  protected onSaveSuccess(message) {
    this.isSaving = false;
    if (message === 'Created') {
      this.action = this.translateService.instant('khanbankCpmsApp.facility.created');
      this.alert.success(this.action, '', 3000);
    } else if (message === 'OK') {
      this.action = this.translateService.instant('khanbankCpmsApp.facility.updated');
      this.alert.success(this.action, '', 3000);
    }
  }

  protected onSaveError(message) {
    this.isSaving = false;
    this.alert.error(message, '', 3000);
  }
  protected onError(errorMessage: string) {
    this.jhiAlertService.error(errorMessage, null, null);
  }

  trackTradeById(index: number, item: ITrade) {
    return item.id;
  }

  trackReleaseById(index: number, item: IRelease) {
    return item.id;
  }

  trackBuildingById(index: number, item: IBuilding) {
    return item.id;
  }
}

import { HttpClient, HttpResponse, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { SERVER_API_URL } from 'app/app.constants';
import { createRequestOption } from 'app/shared';
import { IProjectCostEstimateSubmission } from 'app/shared/model/project-cost-estimate-submission.model';
import * as moment from 'moment';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { ProjectService } from '../project/project.service';
import { Project } from 'app/shared/model/project.model';

type EntityResponseType = HttpResponse<IProjectCostEstimateSubmission>;
type EntityArrayResponseType = HttpResponse<IProjectCostEstimateSubmission[]>;

@Injectable({ providedIn: 'root' })
export class ProjectCostEstimateSubmissionService {
  public resourceUrl = SERVER_API_URL + 'api/project-cost-estimate-submissions';
  public resourceParentUrl = SERVER_API_URL + 'api/projects';

  constructor(protected http: HttpClient, protected projectService: ProjectService) { }

  create(projectId: number, projectCostEstimateSubmission: IProjectCostEstimateSubmission): Observable<EntityResponseType> {
    return this.http
      .post<IProjectCostEstimateSubmission>(
        `${this.resourceParentUrl}/${projectId}/cost-estimate-submissions`,
        projectCostEstimateSubmission,
        { observe: 'response' }
      )
      .pipe(map((res: EntityResponseType) => this.convertDateFromServer(res)));
  }

  accept(submissionId: number): Observable<EntityResponseType> {
    return this.http
      .post<any>(`${this.resourceUrl}/${submissionId}/accept`, { observe: 'response' })
      .pipe(map((res: EntityResponseType) => this.convertDateFromServer(res)));
  }

  decline(submissionId: number): Observable<EntityResponseType> {
    return this.http
      .post<any>(`${this.resourceUrl}/${submissionId}/decline`, { observe: 'response' })
      .pipe(map((res: EntityResponseType) => this.convertDateFromServer(res)));
  }

  find(id: number): Observable<EntityResponseType> {
    return this.http
      .get<IProjectCostEstimateSubmission>(`${this.resourceUrl}/${id}`, { observe: 'response' })
      .pipe(map((res: EntityResponseType) => this.convertDateFromServer(res)));
  }

  query(req?: any): Observable<EntityArrayResponseType> {
    const options = createRequestOption(req);
    return this.http
      .get<IProjectCostEstimateSubmission[]>(this.resourceUrl, { params: options, observe: 'response' })
      .pipe(map((res: EntityArrayResponseType) => this.convertDateArrayFromServer(res)));
  }

  findByProjectId(projectId: number, req?: any): Observable<EntityArrayResponseType> {
    const options = createRequestOption(req);
    return this.http
      .get<IProjectCostEstimateSubmission[]>(`${this.resourceParentUrl}/${projectId}/cost-estimate-submissions`, {
        params: options,
        observe: 'response',
      })
      .pipe(
        map((res: EntityArrayResponseType) => this.convertDateArrayFromServer(res)),
        map((response: EntityArrayResponseType) => {
          const project: Project = this.projectService.projects.get(projectId);
          project.projectCostEstimate.projectCostEstimateSubmissions = response.body;
          return response;
        })
      );
  }

  delete(id: number): Observable<HttpResponse<any>> {
    return this.http.delete<any>(`${this.resourceUrl}/${id}`, { observe: 'response' });
  }

  parseFileData(fileId: number): Observable<HttpResponse<any>> {
    return this.http.post<any>(`${this.resourceUrl}/file/${fileId}`, { observe: 'response' });
  }

  getFileImageBlob(id: number): Observable<Blob> {
    return this.http.get(`${this.resourceUrl}/${id}/image/`, { responseType: 'blob' });
  }

  protected convertDateFromServer(res: EntityResponseType): EntityResponseType {
    if (res.body) {
      res.body.submittedAt = res.body.submittedAt != null ? moment(res.body.submittedAt) : null;
      res.body.respondedAt = res.body.respondedAt != null ? moment(res.body.respondedAt) : null;
      res.body.deletedAt = res.body.deletedAt != null ? moment(res.body.deletedAt) : null;
      res.body.updatedAt = res.body.updatedAt != null ? moment(res.body.updatedAt) : null;
      res.body.createdAt = res.body.createdAt != null ? moment(res.body.createdAt) : null;
    }
    return res;
  }

  protected convertDateArrayFromServer(res: EntityArrayResponseType): EntityArrayResponseType {
    if (res.body) {
      res.body.forEach((projectCostEstimateSubmission: IProjectCostEstimateSubmission) => {
        projectCostEstimateSubmission.submittedAt =
          projectCostEstimateSubmission.submittedAt != null ? moment(projectCostEstimateSubmission.submittedAt) : null;
        projectCostEstimateSubmission.respondedAt =
          projectCostEstimateSubmission.respondedAt != null ? moment(projectCostEstimateSubmission.respondedAt) : null;
        projectCostEstimateSubmission.deletedAt =
          projectCostEstimateSubmission.deletedAt != null ? moment(projectCostEstimateSubmission.deletedAt) : null;
        projectCostEstimateSubmission.updatedAt =
          projectCostEstimateSubmission.updatedAt != null ? moment(projectCostEstimateSubmission.updatedAt) : null;
        projectCostEstimateSubmission.createdAt =
          projectCostEstimateSubmission.createdAt != null ? moment(projectCostEstimateSubmission.createdAt) : null;
      });
    }
    return res;
  }
}

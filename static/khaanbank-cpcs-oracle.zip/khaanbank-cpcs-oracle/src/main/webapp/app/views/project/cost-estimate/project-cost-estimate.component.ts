import { Component, OnInit } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { ActivatedRoute } from '@angular/router';
import { ProjectCostEstimateSubmission, IProjectCostEstimateSubmission } from 'app/shared/model/project-cost-estimate-submission.model';
import { IProjectCostEstimate } from 'app/shared/model/project-cost-estimate.model';
import { ProjectCostEstimateSubmissionComponent, ProjectCostEstimateSubmissionService } from 'app/views/project-cost-estimate-submission';
import { JhiDataUtils } from 'ng-jhipster';

@Component({
  selector: 'jhi-project-cost-estimate',
  templateUrl: './project-cost-estimate.component.html',
  styleUrls: ['./project-cost-estimate.component.scss'],
})
export class ProjectCostEstimateComponent implements OnInit {
  projectCostEstimate: IProjectCostEstimate;
  private chosenImageUrl: any = null;
  private submissionId: number = null;
  chosenCostEstimateSubmission: IProjectCostEstimateSubmission = null;
  constructor(
    protected dataUtils: JhiDataUtils,
    protected activatedRoute: ActivatedRoute,
    protected submissionService: ProjectCostEstimateSubmissionService,
    private sanitizer: DomSanitizer
  ) {}

  ngOnInit() {
    this.activatedRoute.data.subscribe(({ projectCostEstimate }) => {
      this.projectCostEstimate = projectCostEstimate;
    });
  }

  previousState() {
    window.history.back();
  }

  onActivate(costEstimateSubmissionComponentRef: ProjectCostEstimateSubmissionComponent) {
    if (!costEstimateSubmissionComponentRef.submissionSelected) {
      return;
    }
    costEstimateSubmissionComponentRef.submissionSelected.subscribe((submission: ProjectCostEstimateSubmission) => {
      this.chosenCostEstimateSubmission = submission;
      if (!submission.imagePath) {
        this.submissionId = null;
        this.chosenImageUrl = null;
        return;
      }

      const changeImage = this.submissionId ? this.submissionId !== submission.id : true;
      this.submissionId = submission.id;

      // image byte data loop request security
      if (changeImage) {
        this.getCurrentImageBlob();
      }
    });
  }

  private getCurrentImageBlob() {
    this.submissionService.getFileImageBlob(this.submissionId).subscribe(
      value => {
        this.chosenImageUrl = this.sanitizer.bypassSecurityTrustUrl(URL.createObjectURL(value));
      },
      (error: any) => {
        console.error(error.message);
      }
    );
  }

  getCurrentImageUrl() {
    return this.chosenImageUrl;
  }
}

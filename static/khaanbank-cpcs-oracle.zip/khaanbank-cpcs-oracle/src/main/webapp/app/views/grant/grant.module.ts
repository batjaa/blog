import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { JhiLanguageHelper } from 'app/core';
import { KhanbankCpmsSharedModule } from 'app/shared';
import { JhiLanguageService } from 'ng-jhipster';
import { GrantComponent, GrantDetailComponent, grantRoute, GrantUpdateComponent } from './';

@NgModule({
  imports: [KhanbankCpmsSharedModule, RouterModule.forChild(grantRoute)],
  declarations: [GrantComponent, GrantDetailComponent, GrantUpdateComponent],
  entryComponents: [GrantComponent, GrantUpdateComponent],
  providers: [{ provide: JhiLanguageService, useClass: JhiLanguageService }],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class KhanbankCpmsGrantModule {
  constructor(private languageService: JhiLanguageService, private languageHelper: JhiLanguageHelper) {
    this.languageHelper.language.subscribe((languageKey: string) => {
      if (languageKey !== undefined) {
        this.languageService.changeLanguage(languageKey);
      }
    });
  }
}

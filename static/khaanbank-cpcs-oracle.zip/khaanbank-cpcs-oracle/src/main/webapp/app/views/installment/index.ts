export * from './installment.service';
export * from './installment-update.component';
export * from './installment-detail.component';
export * from './installment.component';
export * from './installment.route';

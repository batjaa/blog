import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import * as moment from 'moment';
import { DATE_FORMAT } from 'app/shared/constants/input.constants';
import { map } from 'rxjs/operators';

import { SERVER_API_URL } from 'app/app.constants';
import { createRequestOption } from 'app/shared';
import { IInstallment } from 'app/shared/model/installment.model';

type EntityResponseType = HttpResponse<IInstallment>;
type EntityArrayResponseType = HttpResponse<IInstallment[]>;

@Injectable({ providedIn: 'root' })
export class InstallmentService {
  public resourceUrl = SERVER_API_URL + 'api/installments';
  public resourceParentUrl = SERVER_API_URL + 'api/trades';

  constructor(protected http: HttpClient) {}

  create(tradeId: number, installment: IInstallment): Observable<EntityResponseType> {
    return this.http
      .post<IInstallment>(`${this.resourceParentUrl}/${tradeId}/installments`, installment, { observe: 'response' })
      .pipe(map((res: EntityResponseType) => this.convertDateFromServer(res)));
  }

  update(installment: IInstallment): Observable<EntityResponseType> {
    return this.http
      .put<IInstallment>(this.resourceUrl, installment, { observe: 'response' })
      .pipe(map((res: EntityResponseType) => this.convertDateFromServer(res)));
  }

  find(id: number): Observable<EntityResponseType> {
    return this.http
      .get<IInstallment>(`${this.resourceUrl}/${id}`, { observe: 'response' })
      .pipe(map((res: EntityResponseType) => this.convertDateFromServer(res)));
  }

  findByTradeId(tradeId: number, req?: any): Observable<EntityArrayResponseType> {
    const options = createRequestOption(req);
    return this.http
      .get<IInstallment[]>(`${this.resourceParentUrl}/${tradeId}/installments`, { params: options, observe: 'response' })
      .pipe(map((res: EntityArrayResponseType) => this.convertDateArrayFromServer(res)));
  }

  query(req?: any): Observable<EntityArrayResponseType> {
    const options = createRequestOption(req);
    return this.http
      .get<IInstallment[]>(this.resourceUrl, { params: options, observe: 'response' })
      .pipe(map((res: EntityArrayResponseType) => this.convertDateArrayFromServer(res)));
  }

  protected convertDateFromServer(res: EntityResponseType): EntityResponseType {
    if (res.body) {
      res.body.paidAt = res.body.paidAt != null ? moment(res.body.paidAt) : null;
      res.body.updatedAt = res.body.updatedAt != null ? moment(res.body.updatedAt) : null;
      res.body.createdAt = res.body.createdAt != null ? moment(res.body.createdAt) : null;
    }
    return res;
  }

  protected convertDateArrayFromServer(res: EntityArrayResponseType): EntityArrayResponseType {
    if (res.body) {
      res.body.forEach((installment: IInstallment) => {
        installment.paidAt = installment.paidAt != null ? moment(installment.paidAt) : null;
        installment.updatedAt = installment.updatedAt != null ? moment(installment.updatedAt) : null;
        installment.createdAt = installment.createdAt != null ? moment(installment.createdAt) : null;
      });
    }
    return res;
  }
}

import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { JhiDataUtils } from 'ng-jhipster';

import { ICompliance } from 'app/shared/model/compliance.model';

@Component({
  selector: 'jhi-compliance-detail',
  templateUrl: './compliance-detail.component.html',
})
export class ComplianceDetailComponent implements OnInit {
  compliance: ICompliance;

  constructor(protected dataUtils: JhiDataUtils, protected activatedRoute: ActivatedRoute) {}

  ngOnInit() {
    this.activatedRoute.data.subscribe(({ compliance }) => {
      this.compliance = compliance;
    });
  }

  byteSize(field) {
    return this.dataUtils.byteSize(field);
  }

  openFile(contentType, field) {
    return this.dataUtils.openFile(contentType, field);
  }

  previousState() {
    window.history.back();
  }
}

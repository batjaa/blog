import { HttpErrorResponse, HttpHeaders, HttpResponse } from '@angular/common/http';
import { Component, OnDestroy, OnInit, ElementRef, ViewChild } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { AccountService } from 'app/core';
import { ITEMS_PER_PAGE } from 'app/shared';
import { IGrant } from 'app/shared/model/grant.model';
import { IProject } from 'app/shared/model/project.model';
import { Moment } from 'moment';
import { JhiAlertService, JhiDataUtils, JhiEventManager, JhiParseLinks } from 'ng-jhipster';
import { Subscription } from 'rxjs';
import { filter, map } from 'rxjs/operators';
import { ProjectService } from '../project';
import { GrantService } from './grant.service';
import { DataTableBodyComponent, DatatableComponent } from '@swimlane/ngx-datatable';

@Component({
  selector: 'jhi-grant',
  templateUrl: './grant.component.html',
})
export class GrantComponent implements OnInit, OnDestroy {
  readonly headerHeight = 50;
  readonly rowHeight = 50;
  isLoading: boolean;
  grants: IGrant[];
  currentAccount: any;
  eventSubscriber: Subscription;
  projectId: number;
  itemsPerPage: number;
  links: any;
  page: any;
  predicates = [];
  reverse: any;
  totalItems: number;
  grantsOpenUntil: Moment;
  @ViewChild(DatatableComponent) ngxDatatable: DatatableComponent;
  constructor(
    protected activatedRoute: ActivatedRoute,
    protected grantService: GrantService,
    protected projectService: ProjectService,
    protected jhiAlertService: JhiAlertService,
    protected dataUtils: JhiDataUtils,
    protected eventManager: JhiEventManager,
    protected parseLinks: JhiParseLinks,
    protected accountService: AccountService,
    protected router: Router,
    protected element: ElementRef
  ) {
    this.grants = [];
    this.itemsPerPage = ITEMS_PER_PAGE;
    this.page = 0;
    this.links = {
      last: 0,
    };
    this.predicates = [
      {
        name: 'createdAt',
        reverse: true,
      },
    ];
    this.grantsOpenUntil = null;
  }

  loadAll() {
    this.isLoading = true;
    this.activatedRoute.parent.parent.params.subscribe((params: Params) => {
      this.projectId = params['id'];
    });
    this.grantService
      .findByProjectId(this.projectId, {
        page: this.page,
        size: this.itemsPerPage,
        sort: this.sort(),
      })
      .subscribe(
        (res: HttpResponse<IGrant[]>) => this.paginateGrants(res.body, res.headers),
        (res: HttpErrorResponse) => this.onError(res.message)
      );

    this.projectService
      .find(this.projectId)
      .pipe(
        filter((mayBeOk: HttpResponse<IProject>) => mayBeOk.ok),
        map((response: HttpResponse<IProject>) => response.body)
      )
      .subscribe((res: IProject) => (this.grantsOpenUntil = res.grantsOpenUntil), (res: HttpErrorResponse) => this.onError(res.message));
  }

  reset() {
    this.page = 0;
    this.grants = [];
    this.ngxDatatable.bodyComponent.offsetY = 0;
    this.loadAll();
  }

  onScroll(offsetY: number) {
    const viewHeight = this.element.nativeElement.getBoundingClientRect().height - this.headerHeight;
    if (!this.isLoading && offsetY + viewHeight >= this.grants.length * this.rowHeight) {
      this.loadPage(this.page);
    }
  }

  loadPage(page) {
    this.page = page + 1;
    if (this.page > this.links['last']) {
      return null;
    }
    this.loadAll();
  }

  ngOnInit() {
    this.loadAll();
    this.accountService.identity().then(account => {
      this.currentAccount = account;
    });
    this.registerChangeInGrants();
  }

  ngOnDestroy() {
    this.eventManager.destroy(this.eventSubscriber);
  }

  trackId(index: number, item: IGrant) {
    return item.id;
  }

  byteSize(field) {
    return this.dataUtils.byteSize(field);
  }

  openFile(contentType, field) {
    return this.dataUtils.openFile(contentType, field);
  }

  registerChangeInGrants() {
    this.eventSubscriber = this.eventManager.subscribe('grantListModification', response => this.reset());
  }

  sort() {
    const result = this.predicates.map(function(predicate) {
      return predicate.name + ',' + (predicate.reverse ? 'asc' : 'desc');
    });
    return result;
  }

  onSort(event) {
    const sort = event.sorts[0];
    this.predicates = [
      {
        name: sort.prop,
        reverse: !this.predicates[0].reverse,
      },
    ];
    this.reset();
  }

  protected paginateGrants(data: IGrant[], headers: HttpHeaders) {
    this.links = this.parseLinks.parse(headers.get('link'));
    this.totalItems = parseInt(headers.get('X-Total-Count'), 10);
    const rows = this.grants;
    for (let i = 0; i < data.length; i++) {
      rows.push(data[i]);
    }
    this.grants = rows;
    this.isLoading = false;
  }

  isGrantOpen() {
    if (this.grantsOpenUntil === null) {
      return false;
    }

    return this.grantsOpenUntil.isAfter(Date.now());
  }

  protected onError(errorMessage: string) {
    this.jhiAlertService.error(errorMessage, null, null);
  }

  onSelect({ selected }) {
    this.router.navigate([selected[0].id], { relativeTo: this.activatedRoute });
  }

  onEdit(event, id) {
    this.router.navigate([id, 'edit'], { relativeTo: this.activatedRoute });
    event.stopPropagation();
  }

  onDelete(event, id) {
    this.router.navigate([{ outlets: { popup: id + '/delete' } }], { relativeTo: this.activatedRoute });
    event.stopPropagation();
  }
}

import { HttpErrorResponse, HttpResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { IFacility } from 'app/shared/model/facility.model';
import { FacilityStatus, ITrade, PaymentTerm, Trade } from 'app/shared/model/trade.model';
import { FacilityService } from 'app/views/facility';
import { JhiAlertService } from 'ng-jhipster';
import { Observable } from 'rxjs';
import { TradeService } from './trade.service';
import { AlertService } from '../../../shared/services/alert.service';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'jhi-trade-update',
  templateUrl: './trade-update.component.html',
})
export class TradeUpdateComponent implements OnInit {
  trade: ITrade;
  tradeId: number;
  isSaving: boolean;
  isShowCreate: boolean;
  tradeStatus = Object.keys(FacilityStatus);
  paymentTerms = Object.keys(PaymentTerm);
  facility: IFacility;
  action = '';

  editForm = this.fb.group({
    id: [],
    status: [null, [Validators.required]],
    purchaser: [],
    purchasedAt: [],
    pricePerUnit: [null, [Validators.required]],
    discount: [],
    downPayment: [null, [Validators.required]],
    paymentTerm: [null, [Validators.required]],
    numberOfInstall: [],
  });

  constructor(
    protected jhiAlertService: JhiAlertService,
    protected tradeService: TradeService,
    protected facilityService: FacilityService,
    protected activatedRoute: ActivatedRoute,
    private fb: FormBuilder,
    private alert: AlertService,
    private translateService: TranslateService
  ) {}

  ngOnInit() {
    this.isSaving = false;
    this.isShowCreate = false;
    this.activatedRoute.data.subscribe(({ facility }) => {
      this.facility = facility;
      if (facility.trade !== null) {
        this.isShowCreate = true;
        this.updateForm(facility.trade);
        this.trade = facility.trade;
        this.tradeId = facility.trade.id;
      }
    });
  }

  updateForm(trade: ITrade) {
    this.editForm.patchValue({
      id: trade.id,
      status: trade.status,
      purchaser: trade.purchaser,
      purchasedAt: trade.purchasedAt,
      pricePerUnit: trade.pricePerUnit,
      discount: trade.discount,
      downPayment: trade.downPayment,
      paymentTerm: trade.paymentTerm,
      numberOfInstall: trade.numberOfInstall,
    });
  }

  previousState() {
    window.history.back();
  }

  showCreate() {
    this.isShowCreate = true;
    this.editForm.reset();
  }

  save() {
    this.isSaving = true;
    const trade = this.createFromForm();
    if (trade.id !== undefined) {
      this.subscribeToSaveResponse(this.tradeService.update(trade));
    } else {
      this.subscribeToSaveResponse(this.tradeService.create(this.facility.id, trade));
    }
  }

  private createFromForm(): ITrade {
    const entity = {
      ...new Trade(),
      id: this.tradeId,
      status: this.editForm.get(['status']).value,
      purchaser: this.editForm.get(['purchaser']).value,
      purchasedAt: this.editForm.get(['purchasedAt']).value,
      pricePerUnit: this.editForm.get(['pricePerUnit']).value,
      discount: this.editForm.get(['discount']).value,
      downPayment: this.editForm.get(['downPayment']).value,
      paymentTerm: this.editForm.get(['paymentTerm']).value,
      numberOfInstall: this.editForm.get(['numberOfInstall']).value,
    };
    return entity;
  }

  protected subscribeToSaveResponse(result: Observable<HttpResponse<ITrade>>) {
    result.subscribe((res: HttpResponse<ITrade>) => this.onSaveSuccess(res.statusText), (res: HttpErrorResponse) => this.onSaveError(res.message));
  }

  protected onSaveSuccess(message) {
    this.isSaving = false;
    if (message === 'Created') {
      this.action = this.translateService.instant('khanbankCpmsApp.trade.created', { param: this.editForm.get(['status']).value });
      this.alert.success(this.action, '', 3000);
    } else if (message === 'OK') {
      this.action = this.translateService.instant('khanbankCpmsApp.trade.updated', { param: this.editForm.get(['status']).value });
      this.alert.success(this.action, '', 3000);
    }
    this.previousState();
  }

  protected onSaveError(message) {
    this.isSaving = false;
    this.alert.error(message, '', 3000);
  }
  protected onError(errorMessage: string) {
    this.jhiAlertService.error(errorMessage, null, null);
  }

  trackFacilityById(index: number, item: IFacility) {
    return item.id;
  }
}

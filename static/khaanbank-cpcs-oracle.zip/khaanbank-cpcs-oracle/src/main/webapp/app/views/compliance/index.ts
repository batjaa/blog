export * from './compliance.service';
export * from './compliance-update.component';
export * from './compliance-detail.component';
export * from './compliance.component';
export * from './compliance.route';

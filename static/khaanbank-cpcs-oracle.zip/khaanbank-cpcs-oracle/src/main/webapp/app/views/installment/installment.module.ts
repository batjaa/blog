import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';
import { JhiLanguageService } from 'ng-jhipster';
import { JhiLanguageHelper } from 'app/core';

import { KhanbankCpmsSharedModule } from 'app/shared';
import { InstallmentComponent, InstallmentDetailComponent, InstallmentUpdateComponent, installmentRoute } from './';

@NgModule({
  imports: [KhanbankCpmsSharedModule, RouterModule.forChild(installmentRoute)],
  declarations: [InstallmentComponent, InstallmentDetailComponent, InstallmentUpdateComponent],
  entryComponents: [InstallmentComponent, InstallmentUpdateComponent],
  exports: [InstallmentComponent],
  providers: [{ provide: JhiLanguageService, useClass: JhiLanguageService }],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class KhanbankCpmsInstallmentModule {
  constructor(private languageService: JhiLanguageService, private languageHelper: JhiLanguageHelper) {
    this.languageHelper.language.subscribe((languageKey: string) => {
      if (languageKey !== undefined) {
        this.languageService.changeLanguage(languageKey);
      }
    });
  }
}

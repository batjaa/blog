import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { IProjectCostEstimateSubmission } from 'app/shared/model/project-cost-estimate-submission.model';
import { ProjectCostEstimateSubmissionService } from '.';
import { Observable } from 'rxjs';
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { JhiAlertService } from 'ng-jhipster';

@Component({
  selector: 'jhi-project-cost-estimate-submission-detail',
  templateUrl: './project-cost-estimate-submission-detail.component.html',
})
export class ProjectCostEstimateSubmissionDetailComponent implements OnInit {
  projectCostEstimateSubmission: IProjectCostEstimateSubmission;

  constructor(protected activatedRoute: ActivatedRoute, protected jhiAlertService: JhiAlertService) {}

  ngOnInit() {
    this.activatedRoute.data.subscribe(({ projectCostEstimateSubmission }) => {
      this.projectCostEstimateSubmission = projectCostEstimateSubmission;
    });
  }

  accept() {}
  decline() {}

  previousState() {
    window.history.back();
  }
}

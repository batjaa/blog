import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { JhiLoginModalComponent } from './login.component';

const routes: Routes = [
  {
    path: '',
    component: JhiLoginModalComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class LoginRoutingModule {}

import { HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot, Routes } from '@angular/router';
import { UserRouteAccessService } from 'app/core';
import { DeletePopupComponent } from 'app/shared';
import { EngineerAssessment, IEngineerAssessment } from 'app/shared/model/engineer-assessment.model';
import { Observable, of } from 'rxjs';
import { filter, map } from 'rxjs/operators';
import { EngineerAssessmentDetailComponent } from './engineer-assessment-detail.component';
import { EngineerAssessmentUpdateComponent } from './engineer-assessment-update.component';
import { EngineerAssessmentComponent } from './engineer-assessment.component';
import { EngineerAssessmentService } from './engineer-assessment.service';

@Injectable({ providedIn: 'root' })
export class EngineerAssessmentResolve implements Resolve<IEngineerAssessment> {
  constructor(private service: EngineerAssessmentService) {}

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<IEngineerAssessment> {
    const id = route.params['assessment-id'] ? route.params['assessment-id'] : null;
    if (id) {
      return this.service.find(id).pipe(
        filter((response: HttpResponse<EngineerAssessment>) => response.ok),
        map((engineerAssessment: HttpResponse<EngineerAssessment>) => engineerAssessment.body)
      );
    }
    return of(new EngineerAssessment());
  }
}

export const engineerAssessmentRoute: Routes = [
  {
    path: '',
    component: EngineerAssessmentComponent,
    resolve: {
      engineerAssessment: EngineerAssessmentResolve,
    },
    data: {
      authorities: ['ADMIN'],
      pageTitle: 'khanbankCpmsApp.engineerAssessment.home.title',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: 'new',
    component: EngineerAssessmentUpdateComponent,
    resolve: {
      engineerAssessment: EngineerAssessmentResolve,
    },
    data: {
      authorities: ['ADMIN'],
      pageTitle: 'khanbankCpmsApp.engineerAssessment.home.title',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':assessment-id',
    component: EngineerAssessmentDetailComponent,
    resolve: {
      engineerAssessment: EngineerAssessmentResolve,
    },
    data: {
      authorities: ['ADMIN'],
      pageTitle: 'khanbankCpmsApp.engineerAssessment.home.title',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':assessment-id/edit',
    component: EngineerAssessmentUpdateComponent,
    resolve: {
      engineerAssessment: EngineerAssessmentResolve,
    },
    data: {
      authorities: ['ADMIN'],
      pageTitle: 'khanbankCpmsApp.engineerAssessment.home.title',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':assessment-id/delete',
    component: DeletePopupComponent,
    resolve: {
      resourceToDelete: EngineerAssessmentResolve,
    },
    data: {
      authorities: ['ADMIN'],
      pageTitle: 'khanbankCpmsApp.engineerAssessment.home.title',
      deleteUrl: 'api/engineer-assessments',
      broadcastName: 'engineerAssessmentListModification',
    },
    canActivate: [UserRouteAccessService],
    outlet: 'popup',
  },
];

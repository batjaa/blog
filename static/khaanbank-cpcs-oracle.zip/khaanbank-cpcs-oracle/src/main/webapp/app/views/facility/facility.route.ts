import { HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot, Routes } from '@angular/router';
import { UserRouteAccessService } from 'app/core';
import { DeletePopupComponent } from 'app/shared';
import { Facility, IFacility } from 'app/shared/model/facility.model';
import { Observable, of } from 'rxjs';
import { filter, map } from 'rxjs/operators';
import { FacilityDetailComponent } from './facility-detail.component';
import { FacilityUpdateComponent } from './facility-update.component';
import { FacilityComponent } from './facility.component';
import { FacilityService } from './facility.service';

@Injectable({ providedIn: 'root' })
export class FacilityResolve implements Resolve<IFacility> {
  constructor(private service: FacilityService) {}

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<IFacility> {
    const id = route.params['facility-id'] ? route.params['facility-id'] : null;
    if (id) {
      return this.service.find(id).pipe(
        filter((response: HttpResponse<Facility>) => response.ok),
        map((facility: HttpResponse<Facility>) => facility.body)
      );
    }
    return of(new Facility());
  }
}

export const facilityRoutes: Routes = [
  {
    path: '',
    component: FacilityComponent,
    data: {
      authorities: ['ADMIN'],
      pageTitle: 'khanbankCpmsApp.facility.home.title',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: 'new',
    component: FacilityUpdateComponent,
    resolve: {
      facility: FacilityResolve,
    },
    data: {
      authorities: ['ADMIN'],
      pageTitle: 'khanbankCpmsApp.facility.home.title',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':facility-id',
    component: FacilityDetailComponent,
    resolve: {
      facility: FacilityResolve,
    },
    data: {
      authorities: ['ADMIN'],
      pageTitle: 'khanbankCpmsApp.facility.home.title',
    },
    loadChildren: '../installment/installment.module#KhanbankCpmsInstallmentModule',
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':facility-id/edit',
    component: FacilityUpdateComponent,
    resolve: {
      facility: FacilityResolve,
    },
    data: {
      authorities: ['ADMIN'],
      pageTitle: 'khanbankCpmsApp.facility.home.title',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':facility-id/delete',
    component: DeletePopupComponent,
    resolve: {
      resourceToDelete: FacilityResolve,
    },
    data: {
      authorities: ['ADMIN'],
      pageTitle: 'khanbankCpmsApp.facility.home.title',
      deleteUrl: 'api/facilities',
      broadcastName: 'facilityListModification',
    },
    canActivate: [UserRouteAccessService],
    outlet: 'popup',
  },
];

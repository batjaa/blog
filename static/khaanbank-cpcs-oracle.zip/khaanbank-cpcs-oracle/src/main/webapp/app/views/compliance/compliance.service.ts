import { HttpClient, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { SERVER_API_URL } from 'app/app.constants';
import { createRequestOption } from 'app/shared';
import { ICompliance } from 'app/shared/model/compliance.model';
import * as moment from 'moment';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

type EntityResponseType = HttpResponse<ICompliance>;
type EntityArrayResponseType = HttpResponse<ICompliance[]>;

@Injectable({ providedIn: 'root' })
export class ComplianceService {
  public resourceUrl = SERVER_API_URL + 'api/compliances';
  public projectUrl = SERVER_API_URL + 'api/projects';

  constructor(protected http: HttpClient) {}

  create(projectId: number, compliance: ICompliance): Observable<EntityResponseType> {
    return this.http
      .post<ICompliance>(`${this.projectUrl}/${projectId}/compliances`, compliance, { observe: 'response' })
      .pipe(map((res: EntityResponseType) => this.convertDateFromServer(res)));
  }

  update(compliance: ICompliance): Observable<EntityResponseType> {
    return this.http
      .put<ICompliance>(this.resourceUrl, compliance, { observe: 'response' })
      .pipe(map((res: EntityResponseType) => this.convertDateFromServer(res)));
  }

  find(id: number): Observable<EntityResponseType> {
    return this.http
      .get<ICompliance>(`${this.resourceUrl}/${id}`, { observe: 'response' })
      .pipe(map((res: EntityResponseType) => this.convertDateFromServer(res)));
  }

  findByProjectId(projectId: number, req?: any): Observable<EntityArrayResponseType> {
    const options = createRequestOption(req);
    return this.http
      .get<ICompliance[]>(`${this.projectUrl}/${projectId}/compliances`, { params: options, observe: 'response' })
      .pipe(map((res: EntityArrayResponseType) => this.convertDateArrayFromServer(res)));
  }

  query(req?: any): Observable<EntityArrayResponseType> {
    const options = createRequestOption(req);
    return this.http
      .get<ICompliance[]>(this.resourceUrl, { params: options, observe: 'response' })
      .pipe(map((res: EntityArrayResponseType) => this.convertDateArrayFromServer(res)));
  }

  delete(id: number): Observable<HttpResponse<any>> {
    return this.http.delete<any>(`${this.resourceUrl}/${id}`, { observe: 'response' });
  }

  protected convertDateFromServer(res: EntityResponseType): EntityResponseType {
    if (res.body) {
      res.body.dueDate = res.body.dueDate != null ? moment(res.body.dueDate) : null;
      res.body.updatedAt = res.body.updatedAt != null ? moment(res.body.updatedAt) : null;
      res.body.createdAt = res.body.createdAt != null ? moment(res.body.createdAt) : null;
    }
    return res;
  }

  protected convertDateArrayFromServer(res: EntityArrayResponseType): EntityArrayResponseType {
    if (res.body) {
      res.body.forEach((compliance: ICompliance) => {
        compliance.dueDate = compliance.dueDate != null ? moment(compliance.dueDate) : null;
        compliance.updatedAt = compliance.updatedAt != null ? moment(compliance.updatedAt) : null;
        compliance.createdAt = compliance.createdAt != null ? moment(compliance.createdAt) : null;
      });
    }
    return res;
  }
}

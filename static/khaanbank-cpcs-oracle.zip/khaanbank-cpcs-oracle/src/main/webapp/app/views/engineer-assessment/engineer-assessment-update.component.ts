import { HttpErrorResponse, HttpResponse } from '@angular/common/http';
import { TranslateService } from '@ngx-translate/core';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Params } from '@angular/router';
import { EngineerAssessment, IEngineerAssessment, EngineerAssessmentType } from 'app/shared/model/engineer-assessment.model';
import { IFile } from 'app/shared/model/file.model';
import { IGrant } from 'app/shared/model/grant.model';
import { IProject } from 'app/shared/model/project.model';
import { GrantService } from 'app/views/grant';
import { ProjectService } from 'app/views/project';
import { JhiAlertService, JhiDataUtils } from 'ng-jhipster';
import { Observable } from 'rxjs';
import { filter, map } from 'rxjs/operators';
import { EngineerAssessmentService } from './engineer-assessment.service';
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import { AlertService } from '../../shared/services/alert.service';

@Component({
  selector: 'jhi-engineer-assessment-update',
  templateUrl: './engineer-assessment-update.component.html',
  styleUrls: ['./engineer-assessment-update.component.scss'],
})
export class EngineerAssessmentUpdateComponent implements OnInit {
  engineerAssessment: IEngineerAssessment;
  isSaving: boolean;
  isAddedFile: boolean;

  engineerAssessmentTypes = Object.keys(EngineerAssessmentType);
  Editor = ClassicEditor;
  editorConfig = {};

  grants: IGrant[];
  fileIds: number[];
  projectId: number;
  engineerAssessmentId: number;
  action = '';

  editForm = this.fb.group({
    id: [],
    type: [null, [Validators.required]],
    notes: [],
    grant: [],
  });

  constructor(
    protected dataUtils: JhiDataUtils,
    protected jhiAlertService: JhiAlertService,
    protected engineerAssessmentService: EngineerAssessmentService,
    protected grantService: GrantService,
    protected projectService: ProjectService,
    protected activatedRoute: ActivatedRoute,
    private translateService: TranslateService,
    private fb: FormBuilder,
    private alert: AlertService
  ) {
    this.editorConfig = {
      removePlugins: ['ImageUpload', 'MediaEmbed'],
      placeholder: translateService.instant('khanbankCpmsApp.engineerAssessment.notes'),
    };
  }

  ngOnInit() {
    this.isSaving = false;
    this.fileIds = [];
    this.activatedRoute.data.subscribe(({ engineerAssessment }) => {
      this.updateForm(engineerAssessment);
      this.engineerAssessment = engineerAssessment;
    });

    this.activatedRoute.parent.parent.params.subscribe((params: Params) => {
      this.projectId = params['id'];
    });

    this.activatedRoute.params.subscribe((params: Params) => {
      this.engineerAssessmentId = params['assessment-id'];
    });

    this.grantService
      .findByProjectId(this.projectId)
      .pipe(
        filter((mayBeOk: HttpResponse<IGrant[]>) => mayBeOk.ok),
        map((response: HttpResponse<IGrant[]>) => response.body)
      )
      .subscribe(
        (res: IGrant[]) => {
          this.grants = res;
        },
        (res: HttpErrorResponse) => this.onError(res.message)
      );
    this.editForm.get('type').patchValue(this.editForm.get('type').value || null);
    this.editForm.get('grant').patchValue(this.editForm.get('grant').value || null);
  }

  updateForm(engineerAssessment: IEngineerAssessment) {
    this.editForm.patchValue({
      id: engineerAssessment.id,
      type: engineerAssessment.type,
      notes: engineerAssessment.notes,
      grant: engineerAssessment.grant,
      project: engineerAssessment.project,
    });
    if (engineerAssessment.files) {
      engineerAssessment.files.forEach(file => {
        this.fileIds.push(file.id);
      });
    }
  }

  byteSize(field) {
    return this.dataUtils.byteSize(field);
  }

  previousState() {
    window.history.back();
  }

  save() {
    this.isSaving = true;
    const engineerAssessment = this.createFromForm();
    if (engineerAssessment.id !== undefined) {
      this.subscribeToSaveResponse(this.engineerAssessmentService.update(engineerAssessment));
    } else {
      this.subscribeToSaveResponse(this.engineerAssessmentService.create(this.projectId, engineerAssessment));
    }
  }

  private createFromForm(): IEngineerAssessment {
    const entity = {
      ...new EngineerAssessment(),
      id: this.engineerAssessmentId,
      type: this.editForm.get(['type']).value,
      notes: this.editForm.get('notes').value,
      grant: this.editForm.get(['grant']).value,
      fileIds: this.fileIds,
    };
    return entity;
  }

  protected subscribeToSaveResponse(result: Observable<HttpResponse<IEngineerAssessment>>) {
    result.subscribe((res: HttpResponse<IEngineerAssessment>) => this.onSaveSuccess(res.statusText), (res: HttpErrorResponse) => this.onSaveError(res.message));
  }

  protected onSaveSuccess(message) {
    this.isSaving = false;
    if (message === 'Created') {
      this.action = this.translateService.instant('khanbankCpmsApp.engineerAssessment.created', { param: this.editForm.get(['type']).value });
      this.alert.success(this.action, '', 3000);
    } else if (message === 'OK') {
      this.action = this.translateService.instant('khanbankCpmsApp.engineerAssessment.updated', { param: this.editForm.get(['type']).value });
      this.alert.success(this.action, '', 3000);
    }
    this.previousState();
  }

  protected onSaveError(message) {
    this.isSaving = false;
    this.alert.error(message, '', 3000);
  }
  protected onError(errorMessage: string) {
    this.jhiAlertService.error(errorMessage, null, null);
  }

  trackGrantById(index: number, item: IGrant) {
    return item.id;
  }

  trackProjectById(index: number, item: IProject) {
    return item.id;
  }

  setFile(fileId: number) {
    this.isAddedFile = true;
    this.fileIds.push(fileId);
  }
}

import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { JhiLanguageHelper } from 'app/core';
import { KhanbankCpmsSharedModule } from 'app/shared';
import { JhiLanguageService } from 'ng-jhipster';
import {
  ProjectCostEstimateSubmissionComponent,
  ProjectCostEstimateSubmissionDetailComponent,
  projectCostEstimateSubmissionRoute,
  ProjectCostEstimateSubmissionUpdateComponent,
} from './';

@NgModule({
  imports: [KhanbankCpmsSharedModule, RouterModule.forChild(projectCostEstimateSubmissionRoute)],
  declarations: [
    ProjectCostEstimateSubmissionComponent,
    ProjectCostEstimateSubmissionDetailComponent,
    ProjectCostEstimateSubmissionUpdateComponent,
  ],
  entryComponents: [
    ProjectCostEstimateSubmissionComponent,
    ProjectCostEstimateSubmissionDetailComponent,
    ProjectCostEstimateSubmissionUpdateComponent,
  ],
  providers: [{ provide: JhiLanguageService, useClass: JhiLanguageService }],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class KhanbankCpmsProjectCostEstimateSubmissionModule {
  constructor(private languageService: JhiLanguageService, private languageHelper: JhiLanguageHelper) {
    this.languageHelper.language.subscribe((languageKey: string) => {
      if (languageKey !== undefined) {
        this.languageService.changeLanguage(languageKey);
      }
    });
  }
}

import { Component, OnInit } from '@angular/core';
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { filter, map } from 'rxjs/operators';
import { JhiAlertService } from 'ng-jhipster';
import { IBuilding, Building } from 'app/shared/model/building.model';
import { BuildingService } from './building.service';
import { IProject } from 'app/shared/model/project.model';
import { ProjectService } from 'app/views/project';
import { AlertService } from '../../shared/services/alert.service';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'jhi-building-update',
  templateUrl: './building-update.component.html',
})
export class BuildingUpdateComponent implements OnInit {
  building: IBuilding;
  isSaving: boolean;

  projects: IProject[];
  action = '';

  editForm = this.fb.group({
    id: [],
    name: [null, [Validators.required]],
    project: [],
  });

  constructor(
    protected jhiAlertService: JhiAlertService,
    protected buildingService: BuildingService,
    protected projectService: ProjectService,
    protected activatedRoute: ActivatedRoute,
    private fb: FormBuilder,
    private alert: AlertService,
    private translateService: TranslateService
  ) {}

  ngOnInit() {
    this.isSaving = false;
    this.activatedRoute.data.subscribe(({ building }) => {
      this.updateForm(building);
      this.building = building;
    });
    this.projectService
      .query()
      .pipe(
        filter((mayBeOk: HttpResponse<IProject[]>) => mayBeOk.ok),
        map((response: HttpResponse<IProject[]>) => response.body)
      )
      .subscribe((res: IProject[]) => (this.projects = res), (res: HttpErrorResponse) => this.onError(res.message));
  }

  updateForm(building: IBuilding) {
    this.editForm.patchValue({
      id: building.id,
      name: building.name,
      project: building.project,
    });
  }

  previousState() {
    window.history.back();
  }

  save() {
    this.isSaving = true;
    const building = this.createFromForm();
    if (building.id !== undefined) {
      this.subscribeToSaveResponse(this.buildingService.update(building));
    } else {
      this.subscribeToSaveResponse(this.buildingService.create(building));
    }
  }

  private createFromForm(): IBuilding {
    const entity = {
      ...new Building(),
      id: this.editForm.get(['id']).value,
      name: this.editForm.get(['name']).value,
      project: this.editForm.get(['project']).value,
    };
    return entity;
  }

  protected subscribeToSaveResponse(result: Observable<HttpResponse<IBuilding>>) {
    result.subscribe((res: HttpResponse<IBuilding>) => this.onSaveSuccess(res.statusText), (res: HttpErrorResponse) => this.onSaveError(res.message));
  }

  protected onSaveSuccess(message) {
    this.isSaving = false;
    if (message === 'Created') {
      this.action = this.translateService.instant('khanbankCpmsApp.building.created', { param: this.editForm.get(['name']).value });
      this.alert.success(this.action, '', 3000);
    } else if (message === 'OK') {
      this.action = this.translateService.instant('khanbankCpmsApp.building.updated', { param: this.editForm.get(['name']).value });
      this.alert.success(this.action, '', 3000);
    }
    this.previousState();
  }

  protected onSaveError(message) {
    this.isSaving = false;
    this.alert.error(message, '', 3000);
  }
  protected onError(errorMessage: string) {
    this.alert.error(errorMessage, '', 3000);
  }

  trackProjectById(index: number, item: IProject) {
    return item.id;
  }
}

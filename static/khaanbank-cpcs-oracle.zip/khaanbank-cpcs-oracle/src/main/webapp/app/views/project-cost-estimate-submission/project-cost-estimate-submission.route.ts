import { HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot, Routes } from '@angular/router';
import { UserRouteAccessService } from 'app/core';
import { IProjectCostEstimateSubmission, ProjectCostEstimateSubmission } from 'app/shared/model/project-cost-estimate-submission.model';
import { Observable, of } from 'rxjs';
import { filter, map } from 'rxjs/operators';
import { ProjectCostEstimateSubmissionDetailComponent } from './project-cost-estimate-submission-detail.component';
import { ProjectCostEstimateSubmissionUpdateComponent } from './project-cost-estimate-submission-update.component';
import { ProjectCostEstimateSubmissionComponent } from './project-cost-estimate-submission.component';
import { ProjectCostEstimateSubmissionService } from './project-cost-estimate-submission.service';
import { DeletePopupComponent } from 'app/shared';

@Injectable({ providedIn: 'root' })
export class ProjectCostEstimateSubmissionResolve implements Resolve<IProjectCostEstimateSubmission> {
  constructor(private service: ProjectCostEstimateSubmissionService) {}

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<IProjectCostEstimateSubmission> {
    const id = route.params['submission-id'] ? route.params['submission-id'] : null;
    if (id) {
      return this.service.find(id).pipe(
        filter((response: HttpResponse<ProjectCostEstimateSubmission>) => response.ok),
        map((projectCostEstimateSubmission: HttpResponse<ProjectCostEstimateSubmission>) => projectCostEstimateSubmission.body)
      );
    }
    return of(new ProjectCostEstimateSubmission());
  }
}

export const projectCostEstimateSubmissionRoute: Routes = [
  {
    path: '',
    component: ProjectCostEstimateSubmissionComponent,
    canActivate: [UserRouteAccessService],
  },
  {
    path: 'submission/new',
    component: ProjectCostEstimateSubmissionUpdateComponent,
    resolve: {
      projectCostEstimateSubmission: ProjectCostEstimateSubmissionResolve,
    },
    data: {
      authorities: ['ADMIN'],
      pageTitle: 'khanbankCpmsApp.projectCostEstimateSubmission.home.title',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: 'submission/:submission-id',
    component: ProjectCostEstimateSubmissionDetailComponent,
    resolve: {
      projectCostEstimateSubmission: ProjectCostEstimateSubmissionResolve,
    },
    data: {
      authorities: ['ADMIN'],
      pageTitle: 'khanbankCpmsApp.projectCostEstimateSubmission.home.title',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: 'submission/:submission-id/edit',
    component: ProjectCostEstimateSubmissionUpdateComponent,
    resolve: {
      projectCostEstimateSubmission: ProjectCostEstimateSubmissionResolve,
    },
    data: {
      authorities: ['ROLE_USER'],
      pageTitle: 'khanbankCpmsApp.projectCostEstimateSubmission.home.title',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':submission-id/delete',
    component: DeletePopupComponent,
    resolve: {
      resourceToDelete: ProjectCostEstimateSubmissionResolve,
    },
    data: {
      authorities: ['ADMIN'],
      pageTitle: 'khanbankCpmsApp.projectCostEstimateSubmission.home.title',
      deleteUrl: 'api/project-cost-estimate-submissions',
      broadcastName: 'projectCostEstimateSubmissionListModification',
    },
    canActivate: [UserRouteAccessService],
    outlet: 'popup',
  },
];

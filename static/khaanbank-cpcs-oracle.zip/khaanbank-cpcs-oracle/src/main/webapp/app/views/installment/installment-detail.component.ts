import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { IInstallment } from 'app/shared/model/installment.model';

@Component({
  selector: 'jhi-installment-detail',
  templateUrl: './installment-detail.component.html',
})
export class InstallmentDetailComponent implements OnInit {
  installment: IInstallment;

  constructor(protected activatedRoute: ActivatedRoute) {}

  ngOnInit() {
    this.activatedRoute.data.subscribe(({ installment }) => {
      this.installment = installment;
    });
  }

  previousState() {
    window.history.back();
  }
}

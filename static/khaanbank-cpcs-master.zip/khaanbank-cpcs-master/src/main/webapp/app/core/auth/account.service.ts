import { HttpClient, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { SERVER_API_URL } from 'app/app.constants';
import { Account } from 'app/core/user/account.model';
import { JhiLanguageService } from 'ng-jhipster';
import { LocalStorageService, SessionStorageService } from 'ngx-webstorage';
import { Observable, Subject } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class AccountService {
  private userIdentity: any;
  private authenticated = false;
  private authenticationState = new Subject<any>();
  private resourceUrl = SERVER_API_URL + 'api/account';

  constructor(
    private languageService: JhiLanguageService,
    private localStorage: LocalStorageService,
    private sessionStorage: SessionStorageService,
    private http: HttpClient
  ) {}

  authenticate(identity) {
    this.userIdentity = identity;
    this.authenticated = identity !== null;
    this.authenticationState.next(this.userIdentity);
  }

  hasAnyAuthority(authorities: string[]): boolean {
    if (!this.authenticated || !this.userIdentity || !this.userIdentity.authorities) {
      return false;
    }

    for (let i = 0; i < authorities.length; i++) {
      if (this.userIdentity.authorities.includes(authorities[i])) {
        return true;
      }
    }
    return false;
  }

  hasAuthority(authority: string): Promise<boolean> {
    if (!this.authenticated) {
      return Promise.resolve(false);
    }

    return this.identity().then(
      account => {
        return Promise.resolve(account.authorities && account.authorities.includes(authority));
      },
      () => {
        return Promise.resolve(false);
      }
    );
  }

  identity(force?: boolean): Promise<Account> {
    if (force) {
      this.userIdentity = undefined;
    }
    return new Promise((resolve, reject) => {
      // check and see if we have retrieved the userIdentity data from the server.
      // if we have, reuse it by immediately resolving
      if (this.userIdentity) {
        resolve(this.userIdentity);
        return;
      }

      const accessToken = this.localStorage.retrieve('authenticationToken') || this.sessionStorage.retrieve('authenticationToken');

      if (accessToken) {
        this.getUserAccount().subscribe(
          response => {
            if (response.ok) {
              this.loginSubcribe(response.body);
              resolve(this.userIdentity);
            } else {
              this.loginSubcribe(null);
              resolve(this.userIdentity);
            }
          },
          () => {
            this.loginSubcribe(null);
            resolve(this.userIdentity);
          }
        );
      } else {
        resolve(this.userIdentity);
      }
    });
  }

  loginSubcribe(currentAccount: Account) {
    if (currentAccount) {
      this.userIdentity = currentAccount;
      this.authenticated = true;
      // After retrieve the account info, the language will be changed to
      // the user's preferred language configured in the account setting
      if (this.userIdentity.langKey) {
        const langKey = this.sessionStorage.retrieve('locale') || this.userIdentity.langKey;
        this.languageService.changeLanguage(langKey);
      }
    } else {
      this.userIdentity = null;
      this.authenticated = false;
    }

    this.authenticationState.next(this.userIdentity);
  }

  getUserAccount(): Observable<HttpResponse<Account>> {
    return this.http.get<Account>(this.resourceUrl, { observe: 'response' });
  }

  isAuthenticated(): boolean {
    return this.authenticated;
  }

  isIdentityResolved(): boolean {
    return this.userIdentity !== undefined;
  }

  getAuthenticationState(): Observable<any> {
    return this.authenticationState.asObservable();
  }

  getImageUrl(): string {
    return this.isIdentityResolved() ? this.userIdentity.imageUrl : null;
  }
}

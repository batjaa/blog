import { Moment } from 'moment';

export interface INotification {
  id?: number;
  message?: string;
  acknowledgedAt?: Moment;
  createdAt?: Moment;
}

export class Notification implements INotification {
  constructor(public id?: number, public message?: string, public acknowledgedAt?: Moment, public createdAt?: Moment) {}
}

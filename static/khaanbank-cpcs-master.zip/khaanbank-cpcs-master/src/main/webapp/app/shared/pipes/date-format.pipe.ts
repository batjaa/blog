import { Pipe, PipeTransform } from '@angular/core';
import { DatePipe } from '@angular/common';
import { Moment } from 'moment';

@Pipe({
  name: 'dateFormatPipe',
})
export class DateFormatPipe implements PipeTransform {
  transform(value: Moment): string {
    const datePipe = new DatePipe('en-US');
    const formedDate = datePipe.transform(value, 'yyyy-MM-dd');
    return formedDate;
  }
}

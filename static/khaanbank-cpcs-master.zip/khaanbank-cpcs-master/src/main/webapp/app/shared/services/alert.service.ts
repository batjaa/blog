import { TranslateService } from '@ngx-translate/core';
import { JhiEventManager } from 'ng-jhipster';
import { Subscription } from 'rxjs';
import { ToastrService } from 'ngx-toastr';
import { Injectable } from '@angular/core';

@Injectable({
    providedIn: 'root',
})
export class AlertService {

    httpListener: Subscription;

    constructor(
        public toastr: ToastrService,
        private eventManager: JhiEventManager,
        private translateService: TranslateService
    ) {

        this.httpListener = eventManager.subscribe('khanbankCpmsApp.httpError', response => {
            let i;
            const httpErrorResponse = response.content;
            switch (httpErrorResponse.status) {
                // connection refused, server not reachable
                case 0:
                    this.error('Server not reachable', 'error.server.not.reachable', 5000);
                    break;

                case 400:
                    const arr = httpErrorResponse.headers.keys();
                    let errorHeader = null;
                    let entityKey = null;
                    arr.forEach(entry => {
                        if (entry.toLowerCase().endsWith('app-error')) {
                            errorHeader = httpErrorResponse.headers.get(entry);
                        } else if (entry.toLowerCase().endsWith('app-params')) {
                            entityKey = httpErrorResponse.headers.get(entry);
                        }
                    });
                    if (errorHeader) {
                        const entityName = translateService.instant('global.menu.views.' + entityKey);
                        this.error(entityName, errorHeader, 5000);
                    } else if (httpErrorResponse.error !== '' && httpErrorResponse.error.fieldErrors) {
                        const fieldErrors = httpErrorResponse.error.fieldErrors;
                        for (i = 0; i < fieldErrors.length; i++) {
                            const fieldError = fieldErrors[i];
                            if (['Min', 'Max', 'DecimalMin', 'DecimalMax'].includes(fieldError.message)) {
                                fieldError.message = 'Size';
                            }
                            // convert 'something[14].other[4].id' to 'something[].other[].id' so translations can be written to it
                            const convertedField = fieldError.field.replace(/\[\d*\]/g, '[]');
                            const fieldName = translateService.instant('khanbankCpmsApp.' + fieldError.objectName + '.' + convertedField);
                            this.error(fieldError.message, fieldName, 3000);
                        }
                    } else if (httpErrorResponse.error !== '' && httpErrorResponse.error.message) {
                        this.error(httpErrorResponse.error.message, '', 5000);
                    } else {
                        this.error(httpErrorResponse.error, '', 3000);
                    }
                    break;

                case 404:
                    this.error('Not found', 'error.url.not.found', 3000);
                    break;

                default:
                    if (httpErrorResponse.error !== '' && httpErrorResponse.error.message) {
                        this.error(httpErrorResponse.error.message, '', 3000);
                    } else {
                        this.error(httpErrorResponse.error, '', 3000);
                    }
            }
        });
    }

    success(message, title, fade) {
        this.toastr.success(message, title, { timeOut: fade });
    }

    error(message, title, fade) {
        this.toastr.error(message, title, { timeOut: fade });
    }

    info(message, title, fade) {
        this.toastr.show(message, title, { timeOut: fade });
    }

}

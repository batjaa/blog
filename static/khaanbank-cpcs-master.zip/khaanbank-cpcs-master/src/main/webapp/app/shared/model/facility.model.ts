import { ITrade } from 'app/shared/model/trade.model';
import { IRelease } from 'app/shared/model/release.model';
import { IBuilding } from 'app/shared/model/building.model';

export enum FacilityType {
  SERVICE = 'SERVICE',
  GARAGE = 'GARAGE',
  FLAT = 'FLAT',
}

export interface IFacility {
  id?: number;
  number?: string;
  area?: number;
  type?: FacilityType;
  updatedBy?: string;
  trade?: ITrade;
  release?: IRelease;
  building?: IBuilding;
}

export interface IFacilityRange {
  min: number;
  max: number;
}

export class Facility implements IFacility {
  constructor(
    public id?: number,
    public number?: string,
    public area?: number,
    public type?: FacilityType,
    public updatedBy?: string,
    public trade?: ITrade,
    public release?: IRelease,
    public building?: IBuilding
  ) {}
}

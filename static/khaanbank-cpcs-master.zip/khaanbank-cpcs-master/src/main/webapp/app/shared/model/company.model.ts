import { Moment } from 'moment';
import { IProject } from 'app/shared/model/project.model';

export interface ICompany {
  id?: number;
  name?: string;
  createdBy?: string;
  updatedBy?: string;
  updatedAt?: Moment;
  createdAt?: Moment;
  projects?: IProject[];
}

export class Company implements ICompany {
  constructor(
    public id?: number,
    public name?: string,
    public createdBy?: string,
    public updatedBy?: string,
    public updatedAt?: Moment,
    public createdAt?: Moment,
    public projects?: IProject[]
  ) {}
}

export const FACILITY_AREA_FILTER_VALUES = [
  {
    min: 0,
    max: 10,
  },
  {
    min: 10,
    max: 30,
  },
  {
    min: 30,
    max: 50,
  },
  {
    min: 50,
    max: 100,
  },
  {
    min: 100,
    max: 200,
  },
];
export const FACILITY_PRICE_FILTER_VALUES = [
  {
    min: 500000,
    max: 1000000,
  },
  {
    min: 1000000,
    max: 1500000,
  },
  {
    min: 1500000,
    max: 2000000,
  },
];

export const PROJECT_AMOUNT_FILTER_VALUES = [
  {
    min: 100000000,
    max: 500000000,
  },
  {
    min: 500000000,
    max: 1000000000,
  },
  {
    min: 1000000000,
    max: 10000000000,
  },
  {
    min: 10000000000,
    max: 50000000000,
  },
  {
    min: 50000000000,
    max: 100000000000,
  },
  {
    min: 100000000000,
    max: 1000000000000,
  },
];

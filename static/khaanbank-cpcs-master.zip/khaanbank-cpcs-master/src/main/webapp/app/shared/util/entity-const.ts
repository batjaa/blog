/** Router нэршил авах хэсэг */
export class EntityConst {
  public static ENTITY_PROJECT_NAME = 'project';
  public static ENTITY_ESTIMATE_NAME = 'cost-estimate';
  public static ENTITY_SUBMISSION_NAME = 'cost-estimate-submission';
}

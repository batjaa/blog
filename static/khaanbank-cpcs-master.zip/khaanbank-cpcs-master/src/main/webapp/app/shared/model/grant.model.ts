import { Moment } from 'moment';
import { IProject } from 'app/shared/model/project.model';
import { IFile } from 'app/shared/model/file.model';

export interface IGrant {
  id?: number;
  name?: string;
  notes?: any;
  purpose?: any;
  comment?: any;
  amount?: number;
  createdBy?: string;
  updatedBy?: string;
  updatedAt?: Moment;
  createdAt?: Moment;
  project?: IProject;
  files?: IFile[];
}

export class Grant implements IGrant {
  constructor(
    public id?: number,
    public name?: string,
    public notes?: any,
    public purpose?: any,
    public comment?: any,
    public amount?: number,
    public createdBy?: string,
    public updatedBy?: string,
    public updatedAt?: Moment,
    public createdAt?: Moment,
    public project?: IProject,
    public files?: IFile[]
  ) {}
}

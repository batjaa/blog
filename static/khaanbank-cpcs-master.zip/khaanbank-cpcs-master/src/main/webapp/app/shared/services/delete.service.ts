import { HttpClient, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { SERVER_API_URL } from 'app/app.constants';

@Injectable({ providedIn: 'root' })
export class DeleteService {
  constructor(protected http: HttpClient) {}

  delete(id: number, resourceUrl: string): Observable<HttpResponse<any>> {
    return this.http.delete<any>(`${SERVER_API_URL + resourceUrl}/${id}`, { observe: 'response' });
  }
}

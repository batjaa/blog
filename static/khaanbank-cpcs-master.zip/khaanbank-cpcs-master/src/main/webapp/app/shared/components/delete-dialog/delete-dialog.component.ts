import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgbActiveModal, NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { JhiEventManager } from 'ng-jhipster';
import { DeleteService } from '../../services/delete.service';
import { AlertService } from '../../services/alert.service';

@Component({
  selector: 'jhi-delete-dialog',
  templateUrl: './delete-dialog.component.html',
})
export class DeleteDialogComponent {
  url: any;
  resourceToDelete: any;
  broadcastName: any;

  constructor(
    protected deleteService: DeleteService,
    public activeModal: NgbActiveModal,
    protected eventManager: JhiEventManager,
    private alert: AlertService
  ) {}

  clear() {
    this.activeModal.dismiss('cancel');
    window.history.back();
  }

  confirmDelete(id: number, url: string, broadcastName: string) {
    this.deleteService.delete(id, url).subscribe(response => {
      this.eventManager.broadcast({
        name: broadcastName,
        content: 'Deleted a content',
      });
      this.alert.success(response.headers.get('X-khanbankCpmsApp-alert'), '', 3000);
      this.activeModal.dismiss(true);
    });
  }
}

@Component({
  selector: 'jhi-delete-popup',
  template: '',
})
export class DeletePopupComponent implements OnInit, OnDestroy {
  protected ngbModalRef: NgbModalRef;

  constructor(protected router: Router, protected activatedRoute: ActivatedRoute, protected modalService: NgbModal) {}

  ngOnInit() {
    this.activatedRoute.data.subscribe(({ resourceToDelete, deleteUrl, broadcastName }) => {
      setTimeout(() => {
        this.ngbModalRef = this.modalService.open(DeleteDialogComponent as Component, { size: 'sm', backdrop: 'static', centered: true });
        this.ngbModalRef.componentInstance.resourceToDelete = resourceToDelete;
        this.ngbModalRef.componentInstance.url = deleteUrl;
        this.ngbModalRef.componentInstance.broadcastName = broadcastName;
        this.ngbModalRef.result.then(
          result => {
            this.router.navigate([{ outlets: { popup: null } }], { relativeTo: this.activatedRoute.parent });
            this.ngbModalRef = null;
          },
          reason => {
            this.router.navigate([{ outlets: { popup: null } }], { relativeTo: this.activatedRoute.parent });
            this.ngbModalRef = null;
          }
        );
      }, 0);
    });
  }

  ngOnDestroy() {
    this.ngbModalRef = null;
  }
}

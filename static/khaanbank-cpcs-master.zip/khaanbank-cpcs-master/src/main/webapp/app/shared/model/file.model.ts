import { Moment } from 'moment';
import { IGrant } from 'app/shared/model/grant.model';
import { IEngineerAssessment } from 'app/shared/model/engineer-assessment.model';

export interface IFile {
  id?: number;
  name?: string;
  path?: string;
  createdBy?: string;
  updatedBy?: string;
  createdAt?: Moment;
  grant?: IGrant;
  engineerAssessment?: IEngineerAssessment;
}

export class File implements IFile {
  constructor(
    public id?: number,
    public name?: string,
    public path?: string,
    public createdBy?: string,
    public updatedBy?: string,
    public createdAt?: Moment,
    public grant?: IGrant,
    public engineerAssessment?: IEngineerAssessment
  ) {}
}

import { IProject } from 'app/shared/model/project.model';
import { IFacility } from 'app/shared/model/facility.model';

export interface IBuilding {
  id?: number;
  name?: string;
  project?: IProject;
  facilities?: IFacility[];
}

export class Building implements IBuilding {
  constructor(public id?: number, public name?: string, public project?: IProject, public facilities?: IFacility[]) {}
}

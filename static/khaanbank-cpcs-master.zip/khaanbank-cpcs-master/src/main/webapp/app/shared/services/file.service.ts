import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

import { SERVER_API_URL } from 'app/app.constants';

@Injectable({ providedIn: 'root' })
export class FileService {
    public resourceUrl = SERVER_API_URL + 'api/files';

    constructor(protected http: HttpClient) { }

    downloadFile(id: number): Observable<Blob> {
        const apiUrl = `${this.resourceUrl}/${id}/download`;
        console.log('download file : ' + apiUrl);
        return this.http.get(apiUrl, { responseType: 'blob' });
    }

}

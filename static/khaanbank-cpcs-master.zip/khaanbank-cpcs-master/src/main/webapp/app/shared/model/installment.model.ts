import { Moment } from 'moment';
import { ITrade } from 'app/shared/model/trade.model';

export interface IInstallment {
  id?: number;
  amount?: number;
  createdBy?: string;
  updatedBy?: string;
  updatedAt?: Moment;
  createdAt?: Moment;
  paidAt?: Moment;
  trade?: ITrade;
}

export class Installment implements IInstallment {
  constructor(
    public id?: number,
    public amount?: number,
    public createdBy?: string,
    public updatedBy?: string,
    public updatedAt?: Moment,
    public createdAt?: Moment,
    public paidAt?: Moment,
    public trade?: ITrade
  ) {}
}

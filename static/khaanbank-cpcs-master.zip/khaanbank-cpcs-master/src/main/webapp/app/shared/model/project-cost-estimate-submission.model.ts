import { Moment } from 'moment';
import { IFile } from 'app/shared/model/file.model';
import { IProjectCostEstimate } from 'app/shared/model/project-cost-estimate.model';

export enum ProjectCostEstimateSubmissionStatus {
  SUBMITTED = 'SUBMITTED',
  ACCEPTED = 'ACCEPTED',
  DECLINED = 'DECLINED',
}

export interface IProjectCostEstimateSubmission {
  id?: number;
  status?: ProjectCostEstimateSubmissionStatus;
  submittedBy?: string;
  respondedBy?: string;
  submittedAt?: Moment;
  respondedAt?: Moment;
  notes?: string;
  currentTotal?: number;
  deletedAt?: Moment;
  updatedAt?: Moment;
  createdAt?: Moment;
  file?: IFile;
  imagePath?: string;
  projectCostEstimate?: IProjectCostEstimate;
}

export class ProjectCostEstimateSubmission implements IProjectCostEstimateSubmission {
  constructor(
    public id?: number,
    public status?: ProjectCostEstimateSubmissionStatus,
    public submittedBy?: string,
    public respondedBy?: string,
    public submittedAt?: Moment,
    public respondedAt?: Moment,
    public notes?: string,
    public currentTotal?: number,
    public deletedAt?: Moment,
    public updatedAt?: Moment,
    public createdAt?: Moment,
    public file?: IFile,
    public imagePath?: string,
    public projectCostEstimate?: IProjectCostEstimate
  ) { }
}

import { Moment } from 'moment';
import { ICompany } from 'app/shared/model/company.model';
import { IProjectCostEstimate } from 'app/shared/model/project-cost-estimate.model';
import { IGrant } from 'app/shared/model/grant.model';
import { IBuilding } from 'app/shared/model/building.model';
import { ICompliance } from 'app/shared/model/compliance.model';
import { IEngineerAssessment } from 'app/shared/model/engineer-assessment.model';

export enum ProjectStatus {
  IN_PROGRESS = 'IN_PROGRESS',
  FINISHED = 'FINISHED',
  CANCELLED = 'CANCELLED',
}

export interface IProjectLoanAmount {
  min: number;
  max: number;
}

export interface IProject {
  id?: number;
  name?: string;
  status?: ProjectStatus;
  dueDate?: Moment;
  loanAmount?: number;
  grantsOpenUntil?: Moment;
  users?: any;
  createdBy?: string;
  updatedBy?: string;
  updatedAt?: Moment;
  createdAt?: Moment;
  company?: ICompany;
  projectCostEstimate?: IProjectCostEstimate;
  grant?: IGrant[];
  buildings?: IBuilding[];
  compliances?: ICompliance[];
  engineerAssessments?: IEngineerAssessment[];
}

export class Project implements IProject {
  constructor(
    public id?: number,
    public name?: string,
    public status?: ProjectStatus,
    public dueDate?: Moment,
    public loanAmount?: number,
    public grantsOpenUntil?: Moment,
    public users?: any,
    public createdBy?: string,
    public updatedBy?: string,
    public updatedAt?: Moment,
    public createdAt?: Moment,
    public company?: ICompany,
    public projectCostEstimate?: IProjectCostEstimate,
    public grant?: IGrant[],
    public buildings?: IBuilding[],
    public compliances?: ICompliance[],
    public engineerAssessments?: IEngineerAssessment[]
  ) {}
}

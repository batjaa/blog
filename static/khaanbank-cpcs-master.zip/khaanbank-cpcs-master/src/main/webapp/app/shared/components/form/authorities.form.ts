import { IMenuItem } from '../../services/navigation.service';

export interface IAuthorityForm {
  getMenusItem(): IMenuItem[];

  getSeeAnyAuthority(): String[];

  getNewAnyAuthority(): String[];

  getUpdateAnyAuthority(): String[];

  getDeleteAnyAuthority(): String[];
}

export abstract class AuthoritiesForm implements IAuthorityForm {
  private newAnyAuthority: String[];
  private updateAnyAuthority: String[];
  private deleteAnyAuthority: String[];
  private seeAnyAuthority: String[];

  private menus: IMenuItem[];

  setMenuItem(menus: IMenuItem[]) {
    this.menus = menus;
  }

  getMenusItem() {
    return this.menus;
  }

  setSeeAnyAuthority(authority: String[]) {
    this.seeAnyAuthority = authority;
  }

  setUpdateAnyAuthority(authority: String[]) {
    this.updateAnyAuthority = authority;
  }

  setDeleteAnyAuthority(authority: String[]) {
    this.deleteAnyAuthority = authority;
  }

  setNewAnyAuthority(authority: String[]) {
    this.newAnyAuthority = authority;
  }

  getUpdateAnyAuthority() {
    return this.updateAnyAuthority;
  }

  getDeleteAnyAuthority() {
    return this.deleteAnyAuthority;
  }

  getNewAnyAuthority() {
    return this.newAnyAuthority;
  }

  getSeeAnyAuthority() {
    return this.seeAnyAuthority;
  }
}

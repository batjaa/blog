export class AuthoritiesConst {
  public static ROLE_BO: String = 'BUSINESS_OWNER';
  public static ROLE_CS: String = 'CONTROL_SPECIALIST';
  public static ROLE_CA: String = 'CUSTOMER_ASSOCIATE';
  public static ROLE_ADMIN: String = 'ADMIN';
  public static ROLE_CLIENT: String = 'CLIENT';
  public static ROLE_ENGINEER: String = 'ENGINEER';
}

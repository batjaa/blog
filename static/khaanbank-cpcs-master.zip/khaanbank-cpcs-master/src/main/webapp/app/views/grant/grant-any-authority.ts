import { AuthoritiesForm } from 'app/shared/components/form/authorities.form';
import { AuthoritiesConst } from 'app/shared/util/authorities-const';

export class GrantAuthority extends AuthoritiesForm {
  constructor() {
    super();

    this.setNewAnyAuthority([AuthoritiesConst.ROLE_ADMIN, AuthoritiesConst.ROLE_CS]);
    this.setDeleteAnyAuthority([AuthoritiesConst.ROLE_ADMIN, AuthoritiesConst.ROLE_CS]);
    this.setUpdateAnyAuthority([AuthoritiesConst.ROLE_ADMIN, AuthoritiesConst.ROLE_CS]);
  }
}

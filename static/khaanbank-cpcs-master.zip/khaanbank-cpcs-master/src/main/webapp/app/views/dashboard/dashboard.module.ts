import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

import { KhanbankCpmsSharedModule } from 'app/shared';
import { DASHBOARD_ROUTE, DashboardComponent } from '.';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { JhiLanguageService } from 'ng-jhipster';
import { JhiLanguageHelper } from 'app/core';

@NgModule({
  imports: [KhanbankCpmsSharedModule, NgxDatatableModule, RouterModule.forChild([DASHBOARD_ROUTE])],
  declarations: [DashboardComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  providers: [{ provide: JhiLanguageService, useClass: JhiLanguageService }],
})
export class KhanbankCpmsDashboardModule {
  constructor(private languageService: JhiLanguageService, private languageHelper: JhiLanguageHelper) {
    this.languageHelper.language.subscribe((languageKey: string) => {
      if (languageKey !== undefined) {
        this.languageService.changeLanguage(languageKey);
      }
    });
  }
}

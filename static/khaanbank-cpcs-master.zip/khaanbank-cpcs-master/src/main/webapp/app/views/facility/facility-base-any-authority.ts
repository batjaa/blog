import { AuthoritiesForm, IAuthorityForm } from 'app/shared/components/form/authorities.form';
import { AuthoritiesConst } from 'app/shared/util/authorities-const';

export class FacilityAuthority extends AuthoritiesForm {
  private seeReleaseAnyAuthority: String[];
  private seeTradeAnyAuthority: String[];

  constructor() {
    super();

    this.setNewAnyAuthority([AuthoritiesConst.ROLE_ADMIN, AuthoritiesConst.ROLE_CLIENT]);
    this.setUpdateAnyAuthority([AuthoritiesConst.ROLE_ADMIN, AuthoritiesConst.ROLE_CLIENT]);
    this.setDeleteAnyAuthority([AuthoritiesConst.ROLE_ADMIN, AuthoritiesConst.ROLE_CLIENT]);
  }

  setSeeReleaseAnyAuthority(authority: String[]) {
    this.seeReleaseAnyAuthority = authority;
  }

  setSeeTradeAnyAuthority(authority: String[]) {
    this.seeTradeAnyAuthority = authority;
  }

  getSeeReleaseAnyAuthority() {
    return this.seeReleaseAnyAuthority;
  }

  getSeeTradeAnyAuthority() {
    return this.seeTradeAnyAuthority;
  }
}

import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { IProjectCostEstimateSubmission } from 'app/shared/model/project-cost-estimate-submission.model';
import { JhiAlertService } from 'ng-jhipster';
import { ProjectCostEstimateSubAuthority } from './project-cost-estimate-submission-any-authority';

@Component({
  selector: 'jhi-project-cost-estimate-submission-detail',
  templateUrl: './project-cost-estimate-submission-detail.component.html',
})
export class ProjectCostEstimateSubmissionDetailComponent extends ProjectCostEstimateSubAuthority implements OnInit {
  projectCostEstimateSubmission: IProjectCostEstimateSubmission;

  constructor(protected activatedRoute: ActivatedRoute, protected jhiAlertService: JhiAlertService) {
    super();
  }

  ngOnInit() {
    this.activatedRoute.data.subscribe(({ projectCostEstimateSubmission }) => {
      this.projectCostEstimateSubmission = projectCostEstimateSubmission;
    });
  }

  accept() {}
  decline() {}

  previousState() {
    window.history.back();
  }
}

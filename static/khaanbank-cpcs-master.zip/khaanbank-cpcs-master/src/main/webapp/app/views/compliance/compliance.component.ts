import { HttpErrorResponse, HttpHeaders, HttpResponse } from '@angular/common/http';
import { Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { DatatableComponent } from '@swimlane/ngx-datatable';
import { AccountService } from 'app/core';
import { HEADER_HEIGHT, ITEMS_PER_PAGE, ROW_HEIGHT } from 'app/shared';
import { Compliance, ComplianceType, ICompliance } from 'app/shared/model/compliance.model';
import { FileService } from 'app/shared/services/file.service';
import { JhiAlertService, JhiDataUtils, JhiEventManager, JhiParseLinks } from 'ng-jhipster';
import { Subscription } from 'rxjs';
import { ComplianceService } from './compliance.service';
import { ComplianceAuthority } from './compliance-any-authority';

@Component({
  selector: 'jhi-compliance',
  templateUrl: './compliance.component.html',
})
export class ComplianceComponent extends ComplianceAuthority implements OnInit, OnDestroy {
  readonly headerHeight: number;
  readonly rowHeight: number;
  isLoading: boolean;
  compliances: ICompliance[];
  currentAccount: any;
  eventSubscriber: Subscription;
  itemsPerPage: number;
  links: any;
  projectId: number;
  page: any;
  predicates = [];
  totalItems: number;
  complianceTypes = Object.keys(ComplianceType);
  manualDatas = [];
  rowClass: string;
  row: any;
  @ViewChild(DatatableComponent) ngxDatatable: DatatableComponent;
  constructor(
    protected activatedRoute: ActivatedRoute,
    protected complianceService: ComplianceService,
    protected storageService: FileService,
    protected jhiAlertService: JhiAlertService,
    protected dataUtils: JhiDataUtils,
    protected eventManager: JhiEventManager,
    protected parseLinks: JhiParseLinks,
    protected accountService: AccountService,
    protected router: Router,
    protected element: ElementRef
  ) {
    super();

    this.compliances = [];
    this.itemsPerPage = ITEMS_PER_PAGE;
    this.headerHeight = HEADER_HEIGHT;
    this.rowHeight = ROW_HEIGHT;
    this.page = 0;
    this.projectId = null;
    this.links = {
      last: 0,
    };
    this.predicates = [
      {
        name: 'createdAt',
        reverse: true,
      },
    ];
  }

  loadAll() {
    this.isLoading = true;
    this.activatedRoute.parent.parent.params.subscribe((params: Params) => {
      this.projectId = params['id'];
    });
    this.complianceService
      .findByProjectId(this.projectId, {
        page: this.page,
        size: this.itemsPerPage,
        sort: this.sort(),
      })
      .subscribe(
        (res: HttpResponse<ICompliance[]>) => this.paginateCompliances(res.body, res.headers),
        (res: HttpErrorResponse) => this.onError(res.message)
      );
  }

  reset() {
    this.page = 0;
    this.compliances = [];
    this.ngxDatatable.bodyComponent.offsetY = 0;
    this.loadAll();
  }

  onScroll(offsetY: number) {
    const viewHeight = this.element.nativeElement.getBoundingClientRect().height - this.headerHeight;
    if (!this.isLoading && offsetY + viewHeight >= this.compliances.length * this.rowHeight) {
      this.loadPage(this.page);
    }
  }

  loadPage(page) {
    this.page = page + 1;
    if (this.page > this.links['last']) {
      return null;
    }
    this.loadAll();
  }

  loadTypeManualDatas() {
    this.manualDatas = [];
    this.manualDatas.push(...this.complianceTypes);
  }

  ngOnInit() {
    this.loadTypeManualDatas();
    this.loadAll();
    this.accountService.identity().then(account => {
      this.currentAccount = account;
    });
    this.registerChangeInCompliances();
  }

  ngOnDestroy() {
    this.eventManager.destroy(this.eventSubscriber);
  }

  trackId(index: number, item: ICompliance) {
    return item.id;
  }

  byteSize(field) {
    return this.dataUtils.byteSize(field);
  }

  openFile(contentType, field) {
    return this.dataUtils.openFile(contentType, field);
  }

  registerChangeInCompliances() {
    this.eventSubscriber = this.eventManager.subscribe('complianceListModification', response => this.reset());
  }

  sort() {
    const result = this.predicates.map(function(predicate) {
      return predicate.name + ',' + (predicate.reverse ? 'asc' : 'desc');
    });
    return result;
  }

  onSort(event) {
    const sort = event.sorts[0];
    this.predicates = [
      {
        name: sort.prop,
        reverse: !this.predicates[0].reverse,
      },
    ];
    this.reset();
  }

  getRowClass(row) {
    return {
      'empty-data': row.value === undefined && row.file === undefined,
    };
  }

  protected paginateCompliances(data: ICompliance[], headers: HttpHeaders) {
    this.links = this.parseLinks.parse(headers.get('link'));
    const rows: ICompliance[] = [];
    for (let i = 0; i < data.length; i++) {
      const compliance = data[i];
      const type = this.complianceTypes[compliance.type];
      if (type !== compliance.type) {
        rows.push(data[i]);
      }
    }

    this.manualDatas.forEach(v => {
      const comp = new Compliance();
      comp.type = v;
      rows.push(comp);
    });

    this.compliances = rows;
    this.isLoading = false;
  }

  protected onError(errorMessage: string) {
    this.jhiAlertService.error(errorMessage, null, null);
  }
  onSelect({ selected }) {
    this.router.navigate([selected[0].id], { relativeTo: this.activatedRoute });
  }

  onEdit(event, id) {
    if (id !== undefined) {
      this.router.navigate([id, 'edit'], { relativeTo: this.activatedRoute });
    } else {
      this.router.navigate(['new'], { relativeTo: this.activatedRoute });
    }
    event.stopPropagation();
  }

  onDelete(event, id) {
    this.router.navigate([{ outlets: { popup: id + '/delete' } }], { relativeTo: this.activatedRoute });
    event.stopPropagation();
  }
  onFileDownload(event: any, fileId: number, fileName: string) {
    this.storageService.downloadFile(fileId).subscribe(
      value => {
        if (window.navigator && window.navigator.msSaveOrOpenBlob) {
          // save file for IE
          window.navigator.msSaveOrOpenBlob(value, fileName);
        } else {
          // save for other browsers: Chrome, Firefox
          const url = window.URL.createObjectURL(value);

          const anchor = document.createElement('a');
          document.body.appendChild(anchor);

          anchor.href = url;
          anchor.download = fileName;
          anchor.click();

          window.URL.revokeObjectURL(url);
          document.body.removeChild(anchor);
        }
      },
      error => {
        console.log(error.message);
      }
    );
    event.stopPropagation();
  }
  protected onSaveSuccess() {
    this.jhiAlertService.success('Success', null, null);
  }

  protected onSaveError() {
    this.jhiAlertService.error('Error', null, null);
  }
}

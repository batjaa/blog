import { HttpErrorResponse, HttpHeaders, HttpResponse } from '@angular/common/http';
import { Component, OnDestroy, OnInit, Input, ElementRef, ViewChild } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { AccountService } from 'app/core';
import { ITEMS_PER_PAGE, HEADER_HEIGHT, ROW_HEIGHT, FACILITY_AREA_FILTER_VALUES, FACILITY_PRICE_FILTER_VALUES } from 'app/shared';
import { IFacility, FacilityType, IFacilityRange } from 'app/shared/model/facility.model';
import { FacilityStatus } from 'app/shared/model/trade.model';
import { ReleaseStatus } from 'app/shared/model/release.model';
import { JhiAlertService, JhiEventManager, JhiParseLinks } from 'ng-jhipster';
import { Subscription } from 'rxjs';
import { FacilityService } from './facility.service';
import { DatatableComponent } from '@swimlane/ngx-datatable';
import { IBuilding } from 'app/shared/model/building.model';
import { Utils } from 'app/shared/util/utils';
import { FacilityAuthority } from './facility-base-any-authority';

@Component({
  selector: 'jhi-facility',
  templateUrl: './facility.component.html',
})
export class FacilityComponent extends FacilityAuthority implements OnInit, OnDestroy {
  @ViewChild(DatatableComponent) ngxDatatable: DatatableComponent;
  @Input() parentId: number;
  readonly headerHeight: number;
  readonly rowHeight: number;
  isLoading: boolean;
  projectId: number;
  facilities: IFacility[];
  buildings: IBuilding[];
  currentAccount: any;
  eventSubscriber: Subscription;
  itemsPerPage: number;
  links: any;
  page: any;
  predicate: any;
  reverse: any;
  totalItems: number;
  private facilityType: FacilityType;
  private facilityStatus: FacilityStatus;
  private releaseStatus: ReleaseStatus;

  facilityTypes = Object.keys(FacilityType);
  facilityStatuses = Object.keys(FacilityStatus);
  releaseStatuses = Object.keys(ReleaseStatus);

  areaToSelect: IFacilityRange[];
  priceToSelect: IFacilityRange[];
  selectedArea: IFacilityRange;
  selectedPrice: IFacilityRange;
  buildingId: any;

  constructor(
    protected activatedRoute: ActivatedRoute,
    protected facilityService: FacilityService,
    protected jhiAlertService: JhiAlertService,
    protected eventManager: JhiEventManager,
    protected router: Router,
    protected parseLinks: JhiParseLinks,
    protected accountService: AccountService,
    protected element: ElementRef
  ) {
    super();

    this.facilities = [];
    this.buildings = [];
    this.parentId = null;
    this.itemsPerPage = ITEMS_PER_PAGE;
    this.headerHeight = HEADER_HEIGHT;
    this.rowHeight = ROW_HEIGHT;
    this.page = 0;
    this.links = {
      last: 0,
    };
    this.projectId = null;
    this.predicate = 'id';
    this.reverse = false;
    this.facilityType = null;
    this.facilityStatus = null;
    this.releaseStatus = null;
    this.areaToSelect = FACILITY_AREA_FILTER_VALUES;
    this.priceToSelect = FACILITY_PRICE_FILTER_VALUES;
  }

  loadAll() {
    this.isLoading = true;

    if (this.parentId != null) {
      this.projectId = this.parentId;
    }

    this.facilityService
      .findByProjectId(this.projectId)
      .subscribe((res: HttpResponse<IFacility[]>) => this.setBuildings(res.body), (res: HttpErrorResponse) => this.onError(res.message));

    this.facilityService
      .findByProjectId(this.projectId, {
        page: this.page,
        size: this.itemsPerPage,
        sort: this.sort(),
        'filter[type]': this.facilityType == null ? undefined : this.facilityType,
        'filter[status]': this.facilityStatus == null ? undefined : this.facilityStatus,
        'filter[release_status]': this.releaseStatus == null ? undefined : this.releaseStatus,
        'filter[building_id]': this.buildingId == null ? undefined : this.buildingId,
        'pricePerUnit[gte]': this.selectedPrice == null ? undefined : this.selectedPrice.min,
        'pricePerUnit[lte]': this.selectedPrice == null ? undefined : this.selectedPrice.max,
        'area[gte]': this.selectedArea == null ? undefined : this.selectedArea.min,
        'area[lte]': this.selectedArea == null ? undefined : this.selectedArea.max,
      })
      .subscribe(
        (res: HttpResponse<IFacility[]>) => this.paginateFacilities(res.body, res.headers),
        (res: HttpErrorResponse) => this.onError(res.message)
      );
  }

  reset() {
    this.page = 0;
    this.facilities = [];
    this.ngxDatatable.bodyComponent.offsetY = 0;
    this.loadAll();
  }

  onScroll(offsetY: number) {
    // харагдаж байгаа мөрүүдийн нийт өндөр
    const viewHeight = this.element.nativeElement.getBoundingClientRect().height - this.headerHeight;

    // scroll хамгийн доод хэсэгт очсон эсэхийг шалгах
    if (!this.isLoading && offsetY + viewHeight >= this.facilities.length * this.rowHeight) {
      this.loadPage(this.page);
    }
  }

  loadPage(page) {
    this.page = page + 1;
    if (this.page > this.links['last']) {
      return null;
    }
    this.loadAll();
  }

  ngOnInit() {
    this.loadAll();
    this.accountService.identity().then(account => {
      this.currentAccount = account;
    });
    this.registerChangeInFacilities();
  }

  ngOnDestroy() {
    this.eventManager.destroy(this.eventSubscriber);
  }

  trackId(index: number, item: IFacility) {
    return item.id;
  }

  registerChangeInFacilities() {
    this.eventSubscriber = this.eventManager.subscribe('facilityListModification', response => this.reset());
  }

  sort() {
    const result = [this.predicate + ',' + (this.reverse ? 'asc' : 'desc')];
    if (this.predicate !== 'id') {
      result.push('id');
    }
    return result;
  }

  onSort(event) {
    const sort = event.sorts[0];
    this.predicate = sort.prop;
    this.reverse = !this.reverse;
    this.reset();
  }

  onFilterChange(value: any, type: string) {
    switch (type) {
      case 'facilityType': {
        this.facilityType = value.match('null') ? undefined : value;
        break;
      }
      case 'facilityStatus': {
        this.facilityStatus = value.match('null') ? undefined : value;
        break;
      }
      case 'releaseStatus': {
        this.releaseStatus = value.match('null') ? undefined : value;
        break;
      }
      case 'area': {
        this.selectedArea = value.match('null') ? undefined : JSON.parse(value);
        break;
      }
      case 'price': {
        this.selectedPrice = value.match('null') ? undefined : JSON.parse(value);
        break;
      }
      case 'building': {
        this.buildingId = value.match('null') ? undefined : value;
        break;
      }
      default: {
        this.reset();
        break;
      }
    }

    this.reset();
  }

  protected paginateFacilities(data: IFacility[], headers: HttpHeaders) {
    this.links = this.parseLinks.parse(headers.get('link'));
    this.totalItems = parseInt(headers.get('X-Total-Count'), 10);
    for (let i = 0; i < data.length; i++) {
      this.facilities.push(data[i]);
    }
    this.facilities = [...this.facilities];
    this.isLoading = false;
  }

  protected setBuildings(data: IFacility[]) {
    for (let i = 0; i < data.length; i++) {
      this.buildings.push(data[i].building);
    }
    this.buildings = Utils.getUniqueFromArray(this.buildings, 'id');
  }

  protected onError(errorMessage: string) {
    this.jhiAlertService.error(errorMessage, null, null);
  }

  onSelect({ selected }) {
    this.router.navigate(['facility', selected[0].id], { relativeTo: this.activatedRoute });
  }

  onEdit(event, id) {
    this.router.navigate(['facility', id, 'edit'], { relativeTo: this.activatedRoute });
    event.stopPropagation();
  }

  onDelete(event, id) {
    this.router.navigate(['facility', { outlets: { popup: id + '/delete' } }], { relativeTo: this.activatedRoute });
    event.stopPropagation();
  }
}

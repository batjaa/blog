import { HttpErrorResponse, HttpHeaders, HttpResponse } from '@angular/common/http';
import { Component, ElementRef, Input, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { AccountService } from 'app/core';
import { HEADER_HEIGHT, ITEMS_PER_PAGE, ROW_HEIGHT } from 'app/shared';
import { IEngineerAssessment } from 'app/shared/model/engineer-assessment.model';
import { Project } from 'app/shared/model/project.model';
import { FileService } from 'app/shared/services/file.service';
import { JhiAlertService, JhiDataUtils, JhiEventManager, JhiParseLinks } from 'ng-jhipster';
import { Subscription } from 'rxjs';
import { EngineerAssessmentService } from './engineer-assessment.service';
import { DatatableComponent } from '@swimlane/ngx-datatable';
import { EngineerAssessmentAuthority } from './engineer-assessment-any-authority';

@Component({
  selector: 'jhi-engineer-assessment',
  templateUrl: `./engineer-assessment.component.html`,
})
export class EngineerAssessmentComponent extends EngineerAssessmentAuthority implements OnInit, OnDestroy {
  @Input() project: Project;
  readonly headerHeight: number;
  readonly rowHeight: number;
  isLoading: boolean;
  engineerAssessments: IEngineerAssessment[];
  currentAccount: any;
  eventSubscriber: Subscription;
  itemsPerPage: number;
  projectId: number;
  links: any;
  page: any;
  predicate: any;
  reverse: any;
  totalItems: number;
  @ViewChild(DatatableComponent) ngxDatatable: DatatableComponent;
  constructor(
    protected accountService: AccountService,
    protected activatedRoute: ActivatedRoute,
    protected router: Router,
    protected storageService: FileService,
    protected engineerAssessmentService: EngineerAssessmentService,
    protected element: ElementRef,
    protected jhiAlertService: JhiAlertService,
    protected dataUtils: JhiDataUtils,
    protected eventManager: JhiEventManager,
    protected parseLinks: JhiParseLinks
  ) {
    super();

    this.engineerAssessments = [];
    this.itemsPerPage = ITEMS_PER_PAGE;
    this.headerHeight = HEADER_HEIGHT;
    this.rowHeight = ROW_HEIGHT;
    this.projectId = null;
    this.page = 0;
    this.links = {
      last: 0,
    };
    this.predicate = 'id';
    this.reverse = false;
  }

  loadAll() {
    this.isLoading = true;
    this.activatedRoute.parent.parent.params.subscribe((params: Params) => {
      this.projectId = params['id'];
    });
    this.engineerAssessmentService
      .findByProjectId(this.projectId, {
        page: this.page,
        size: this.itemsPerPage,
        sort: this.sort(),
      })
      .subscribe(
        (res: HttpResponse<IEngineerAssessment[]>) => this.paginateEngineerAssessments(res.body, res.headers),
        (res: HttpErrorResponse) => this.onError(res.message)
      );
  }

  onScroll(offsetY: number) {
    // харагдаж байгаа мөрүүдийн нийт өндөр
    const viewHeight = this.element.nativeElement.getBoundingClientRect().height - this.headerHeight;

    // scroll хамгийн доод хэсэгт очсон эсэхийг шалгах
    if (!this.isLoading && offsetY + viewHeight >= this.engineerAssessments.length * this.rowHeight) {
      this.loadPage(this.page);
    }
  }

  reset() {
    this.page = 0;
    this.engineerAssessments = [];
    this.ngxDatatable.bodyComponent.offsetY = 0;
    this.loadAll();
  }

  loadPage(page) {
    this.page = page + 1;
    if (this.page > this.links['last']) {
      return null;
    }
    this.loadAll();
  }

  ngOnInit() {
    this.loadAll();
    this.accountService.identity().then(account => {
      this.currentAccount = account;
    });
    this.registerChangeInEngineerAssessments();
  }

  ngOnDestroy() {
    this.eventManager.destroy(this.eventSubscriber);
  }

  trackId(index: number, item: IEngineerAssessment) {
    return item.id;
  }

  byteSize(field) {
    return this.dataUtils.byteSize(field);
  }

  openFile(contentType, field) {
    return this.dataUtils.openFile(contentType, field);
  }

  registerChangeInEngineerAssessments() {
    this.eventSubscriber = this.eventManager.subscribe('engineerAssessmentListModification', response => this.reset());
  }

  sort() {
    const result = [this.predicate + ',' + (this.reverse ? 'asc' : 'desc')];
    if (this.predicate !== 'id') {
      result.push('id');
    }
    return result;
  }
  onSort(event) {
    const sort = event.sorts[0];
    this.predicate = sort.prop;
    this.reverse = !this.reverse;
    this.reset();
  }

  protected paginateEngineerAssessments(data: IEngineerAssessment[], headers: HttpHeaders) {
    this.links = this.parseLinks.parse(headers.get('link'));
    this.totalItems = parseInt(headers.get('X-Total-Count'), 10);
    const rows = this.engineerAssessments;
    for (let i = 0; i < data.length; i++) {
      rows.push(data[i]);
    }
    this.engineerAssessments = rows;
    this.isLoading = false;
  }

  protected onError(errorMessage: string) {
    this.jhiAlertService.error(errorMessage, null, null);
  }

  onSelect({ selected }) {
    this.router.navigate([selected[0].id], { relativeTo: this.activatedRoute });
  }

  onEdit(event, id) {
    this.router.navigate([id, 'edit'], { relativeTo: this.activatedRoute });
    event.stopPropagation();
  }

  onDelete(event, id) {
    this.router.navigate([{ outlets: { popup: id + '/delete' } }], { relativeTo: this.activatedRoute });
    event.stopPropagation();
  }
  onFileDownload(event: any, fileId: number, fileName: string) {
    this.storageService.downloadFile(fileId).subscribe(
      value => {
        if (window.navigator && window.navigator.msSaveOrOpenBlob) {
          // save file for IE
          window.navigator.msSaveOrOpenBlob(value, fileName);
        } else {
          // save for other browsers: Chrome, Firefox
          const url = window.URL.createObjectURL(value);

          const anchor = document.createElement('a');
          document.body.appendChild(anchor);

          anchor.href = url;
          anchor.download = fileName;
          anchor.click();

          window.URL.revokeObjectURL(url);
          document.body.removeChild(anchor);
        }
      },
      error => {
        console.log(error.message);
      }
    );
    event.stopPropagation();
  }
  protected onSaveSuccess() {
    this.jhiAlertService.success('Success', null, null);
  }

  protected onSaveError() {
    this.jhiAlertService.error('Error', null, null);
  }
}

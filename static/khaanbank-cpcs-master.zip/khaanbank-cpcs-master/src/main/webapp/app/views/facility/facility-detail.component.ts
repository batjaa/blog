import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { IFacility } from 'app/shared/model/facility.model';
import { FacilityAuthority } from './facility-base-any-authority';
import { AuthoritiesConst } from 'app/shared/util/authorities-const';

@Component({
  selector: 'jhi-facility-detail',
  templateUrl: './facility-detail.component.html',
})
export class FacilityDetailComponent extends FacilityAuthority implements OnInit {
  facility: IFacility;

  constructor(protected activatedRoute: ActivatedRoute) {
    super();
    this.setSeeReleaseAnyAuthority([
      AuthoritiesConst.ROLE_ADMIN,
      AuthoritiesConst.ROLE_BO,
      AuthoritiesConst.ROLE_CS,
      AuthoritiesConst.ROLE_CA,
      AuthoritiesConst.ROLE_CLIENT,
    ]);

    this.setSeeTradeAnyAuthority([
      AuthoritiesConst.ROLE_ADMIN,
      AuthoritiesConst.ROLE_BO,
      AuthoritiesConst.ROLE_CS,
      AuthoritiesConst.ROLE_CA,
      AuthoritiesConst.ROLE_CLIENT,
    ]);
  }

  ngOnInit() {
    this.activatedRoute.data.subscribe(({ facility }) => {
      this.facility = facility;
    });
  }

  previousState() {
    window.history.back();
  }
}

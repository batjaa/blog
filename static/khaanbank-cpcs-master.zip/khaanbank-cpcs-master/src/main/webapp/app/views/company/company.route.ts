import { Injectable } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot, Routes } from '@angular/router';
import { UserRouteAccessService } from 'app/core';
import { Observable, of } from 'rxjs';
import { filter, map } from 'rxjs/operators';
import { Company } from 'app/shared/model/company.model';
import { CompanyService } from './company.service';
import { CompanyComponent } from './company.component';
import { CompanyDetailComponent } from './company-detail.component';
import { CompanyUpdateComponent } from './company-update.component';
import { ICompany } from 'app/shared/model/company.model';
import { DeletePopupComponent } from 'app/shared';
import { AuthoritiesConst } from 'app/shared/util/authorities-const';

@Injectable({ providedIn: 'root' })
export class CompanyResolve implements Resolve<ICompany> {
  constructor(private service: CompanyService) {}

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<ICompany> {
    const id = route.params['id'] ? route.params['id'] : null;
    if (id) {
      return this.service.find(id).pipe(
        filter((response: HttpResponse<Company>) => response.ok),
        map((company: HttpResponse<Company>) => company.body)
      );
    }
    return of(new Company());
  }
}

export const companyRoute: Routes = [
  {
    path: '',
    component: CompanyComponent,
    data: {
      authorities: [AuthoritiesConst.ROLE_ADMIN, AuthoritiesConst.ROLE_BO, AuthoritiesConst.ROLE_CA],
      pageTitle: 'khanbankCpmsApp.company.home.title',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: 'new',
    component: CompanyUpdateComponent,
    resolve: {
      company: CompanyResolve,
    },
    data: {
      authorities: [AuthoritiesConst.ROLE_ADMIN, AuthoritiesConst.ROLE_CA],
      pageTitle: 'khanbankCpmsApp.company.home.title',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':id',
    component: CompanyDetailComponent,
    resolve: {
      company: CompanyResolve,
    },
    data: {
      authorities: [AuthoritiesConst.ROLE_ADMIN, AuthoritiesConst.ROLE_BO],
      pageTitle: 'khanbankCpmsApp.company.home.title',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':id/edit',
    component: CompanyUpdateComponent,
    resolve: {
      company: CompanyResolve,
    },
    data: {
      authorities: [AuthoritiesConst.ROLE_ADMIN, AuthoritiesConst.ROLE_CA],
      pageTitle: 'khanbankCpmsApp.company.home.title',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':id/delete',
    component: DeletePopupComponent,
    resolve: {
      resourceToDelete: CompanyResolve,
    },
    data: {
      authorities: [AuthoritiesConst.ROLE_ADMIN, AuthoritiesConst.ROLE_CA],
      pageTitle: 'khanbankCpmsApp.company.home.title',
      deleteUrl: 'api/companies',
      broadcastName: 'companyListModification',
    },
    canActivate: [UserRouteAccessService],
    outlet: 'popup',
  },
];

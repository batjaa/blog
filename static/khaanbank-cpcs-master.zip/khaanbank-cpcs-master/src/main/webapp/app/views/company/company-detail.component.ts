import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { ICompany } from 'app/shared/model/company.model';
import { AuthoritiesForm } from 'app/shared/components/form/authorities.form';
import { AuthoritiesConst } from 'app/shared/util/authorities-const';
import { ComplianceAuthority } from '../compliance/compliance-any-authority';
import { CompanyAuthority } from './company-any-authority';

@Component({
  selector: 'jhi-company-detail',
  templateUrl: './company-detail.component.html',
})
export class CompanyDetailComponent extends CompanyAuthority implements OnInit {
  company: ICompany;

  constructor(protected activatedRoute: ActivatedRoute) {
    super();
  }

  ngOnInit() {
    this.activatedRoute.data.subscribe(({ company }) => {
      this.company = company;
    });
  }

  previousState() {
    window.history.back();
  }
}

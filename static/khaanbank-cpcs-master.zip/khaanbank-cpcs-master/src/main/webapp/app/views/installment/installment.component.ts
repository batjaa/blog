import { HttpErrorResponse, HttpHeaders, HttpResponse } from '@angular/common/http';
import { Component, OnDestroy, OnInit, ElementRef, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AccountService } from 'app/core';
import { ITEMS_PER_PAGE } from 'app/shared';
import { IInstallment } from 'app/shared/model/installment.model';
import { ITrade } from 'app/shared/model/trade.model';
import { JhiAlertService, JhiEventManager, JhiParseLinks } from 'ng-jhipster';
import { Subscription } from 'rxjs';
import { InstallmentService } from './installment.service';
import { DatatableComponent } from '@swimlane/ngx-datatable';
import { InstallmentAuthority } from './installment-any-authority';

@Component({
  selector: 'jhi-installment',
  templateUrl: './installment.component.html',
})
export class InstallmentComponent extends InstallmentAuthority implements OnInit, OnDestroy {
  readonly headerHeight = 50;
  readonly rowHeight = 50;
  isLoading: boolean;
  installments: IInstallment[];
  currentAccount: any;
  eventSubscriber: Subscription;
  itemsPerPage: number;
  links: any;
  page: any;
  predicate: any;
  reverse: any;
  totalItems: number;
  trade: ITrade;
  @ViewChild(DatatableComponent) ngxDatatable: DatatableComponent;
  constructor(
    protected installmentService: InstallmentService,
    protected jhiAlertService: JhiAlertService,
    protected eventManager: JhiEventManager,
    protected parseLinks: JhiParseLinks,
    protected accountService: AccountService,
    protected activatedRoute: ActivatedRoute,
    protected router: Router,
    protected element: ElementRef
  ) {
    super();

    this.installments = [];
    this.itemsPerPage = ITEMS_PER_PAGE;
    this.page = 0;
    this.links = {
      last: 0,
    };
    this.predicate = 'id';
    this.reverse = true;
  }

  loadAll() {
    this.isLoading = true;
    this.activatedRoute.data.subscribe(({ facility }) => {
      if (facility.trade == null) {
        return;
      }
      this.trade = facility.trade;
      this.installmentService
        .findByTradeId(this.trade.id, {
          page: this.page,
          size: this.itemsPerPage,
          sort: this.sort(),
        })
        .subscribe(
          (res: HttpResponse<IInstallment[]>) => this.paginateInstallments(res.body, res.headers),
          (res: HttpErrorResponse) => this.onError(res.message)
        );
    });
  }

  reset() {
    this.page = 0;
    this.installments = [];
    this.ngxDatatable.bodyComponent.offsetY = 0;
    this.loadAll();
  }

  onScroll(offsetY: number) {
    const viewHeight = this.element.nativeElement.getBoundingClientRect().height - this.headerHeight;
    if (!this.isLoading && offsetY + viewHeight >= this.installments.length * this.rowHeight) {
      this.loadPage(this.page);
    }
  }

  loadPage(page) {
    this.page = page + 1;
    if (this.page > this.links['last']) {
      return null;
    }
    this.loadAll();
  }

  ngOnInit() {
    this.loadAll();
    this.accountService.identity().then(account => {
      this.currentAccount = account;
    });
    this.registerChangeInInstallments();
  }

  ngOnDestroy() {
    this.eventManager.destroy(this.eventSubscriber);
  }

  trackId(index: number, item: IInstallment) {
    return item.id;
  }

  registerChangeInInstallments() {
    this.eventSubscriber = this.eventManager.subscribe('installmentListModification', response => this.reset());
  }

  sort() {
    const result = [this.predicate + ',' + (this.reverse ? 'asc' : 'desc')];
    if (this.predicate !== 'id') {
      result.push('id');
    }
    return result;
  }

  onSort(event) {
    const sort = event.sorts[0];
    this.predicate = sort.prop;
    this.reverse = !this.reverse;
    this.reset();
  }

  onSelect({ selected }) {
    this.router.navigate(['trade/installment/', selected[0].id], { relativeTo: this.activatedRoute });
  }

  onEdit(event, id) {
    this.router.navigate(['trade/installment/' + id + '/edit'], { relativeTo: this.activatedRoute });
    event.stopPropagation();
  }

  onDelete(event, id) {
    this.router.navigate(['trade/installment/', { outlets: { popup: [id + '/delete'] } }], { relativeTo: this.activatedRoute });
    event.stopPropagation();
  }

  protected paginateInstallments(data: IInstallment[], headers: HttpHeaders) {
    this.links = this.parseLinks.parse(headers.get('link'));
    this.totalItems = parseInt(headers.get('X-Total-Count'), 10);
    const rows = this.installments;
    for (let i = 0; i < data.length; i++) {
      rows.push(data[i]);
    }
    this.installments = rows;
    this.isLoading = false;
  }

  protected onError(errorMessage: string) {
    this.jhiAlertService.error(errorMessage, null, null);
  }
}

import { HttpErrorResponse, HttpResponse } from '@angular/common/http';
import { TranslateService } from '@ngx-translate/core';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Params } from '@angular/router';
import { DATE_FORMAT } from 'app/shared/constants/input.constants';
import { Compliance, ICompliance, ComplianceType } from 'app/shared/model/compliance.model';
import { IFile } from 'app/shared/model/file.model';
import { ProjectService } from 'app/views/project';
import * as moment from 'moment';
import { JhiAlertService, JhiDataUtils } from 'ng-jhipster';
import { Observable } from 'rxjs';
import { ComplianceService } from './compliance.service';
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import { AlertService } from '../../shared/services/alert.service';

@Component({
  selector: 'jhi-compliance-update',
  templateUrl: './compliance-update.component.html',
  styleUrls: ['./compliance-update.component.scss'],
})
export class ComplianceUpdateComponent implements OnInit {
  compliance: ICompliance;
  isSaving: boolean;
  projectId: number;
  file: IFile;
  id: number;
  complianceTypes = Object.keys(ComplianceType);
  Editor = ClassicEditor;
  editorConfig = {};
  action = '';

  editForm = this.fb.group({
    id: null,
    notes: '',
    dueDate: [null, [Validators.required]],
    type: [null, [Validators.required]],
    file: [],
  });

  constructor(
    protected dataUtils: JhiDataUtils,
    protected jhiAlertService: JhiAlertService,
    protected complianceService: ComplianceService,
    protected projectService: ProjectService,
    protected activatedRoute: ActivatedRoute,
    private translateService: TranslateService,
    private fb: FormBuilder,
    private alert: AlertService
  ) {
    this.editorConfig = {
      removePlugins: ['ImageUpload', 'MediaEmbed'],
      placeholder: translateService.instant('khanbankCpmsApp.compliance.notes'),
    };
  }

  ngOnInit() {
    this.isSaving = false;
    this.activatedRoute.data.subscribe(({ compliance }) => {
      this.updateForm(compliance);
      this.compliance = compliance;
    });
    this.activatedRoute.parent.parent.params.subscribe((params: Params) => {
      this.projectId = params['id'];
    });
    this.activatedRoute.params.subscribe((params: Params) => {
      this.id = params['compliance-id'];
    });
    this.editForm.get('type').patchValue(this.editForm.get('type').value || null);
  }

  updateForm(compliance: ICompliance) {
    this.editForm.patchValue({
      id: this.id,
      notes: compliance.notes,
      dueDate: compliance.dueDate != null ? compliance.dueDate.format(DATE_FORMAT) : null,
      type: compliance.type,
      file: compliance.file,
      project: compliance.project,
    });
  }

  byteSize(field) {
    return this.dataUtils.byteSize(field);
  }

  openFile(contentType, field) {
    return this.dataUtils.openFile(contentType, field);
  }

  previousState() {
    window.history.back();
  }

  save() {
    this.isSaving = true;
    const compliance = this.createFromForm();
    if (compliance.id !== undefined) {
      this.subscribeToSaveResponse(this.complianceService.update(compliance));
    } else {
      this.subscribeToSaveResponse(this.complianceService.create(this.projectId, compliance));
    }
  }

  private createFromForm(): ICompliance {
    const entity = {
      ...new Compliance(),
      id: this.id,
      notes: this.editForm.get('notes').value,
      dueDate: this.editForm.get(['dueDate']).value != null ? moment(this.editForm.get(['dueDate']).value, DATE_FORMAT) : undefined,
      type: this.editForm.get(['type']).value,
      file: this.file,
    };
    return entity;
  }

  protected subscribeToSaveResponse(result: Observable<HttpResponse<ICompliance>>) {
    result.subscribe((res: HttpResponse<ICompliance>) => this.onSaveSuccess(res.statusText), (res: HttpErrorResponse) => this.onSaveError(res.message));
  }

  protected onSaveSuccess(message) {
    this.isSaving = false;
    if (message === 'Created') {
      this.action = this.translateService.instant('khanbankCpmsApp.compliance.created', { param: this.editForm.get(['type']).value });
      this.alert.success(this.action, '', 3000);
    } else if (message === 'OK') {
      this.action = this.translateService.instant('khanbankCpmsApp.compliance.updated', { param: this.editForm.get(['type']).value });
      this.alert.success(this.action, '', 3000);
    }
    this.previousState();
  }

  protected onSaveError(message) {
    this.isSaving = false;
    this.alert.error(message, '', 3000);
  }
  protected onError(errorMessage: string) {
    this.jhiAlertService.error(errorMessage, null, null);
  }

  setFile(file: IFile) {
    this.file = file;
  }
}

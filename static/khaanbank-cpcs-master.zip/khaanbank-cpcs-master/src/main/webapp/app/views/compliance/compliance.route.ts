import { Injectable } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot, Routes } from '@angular/router';
import { UserRouteAccessService } from 'app/core';
import { Observable, of } from 'rxjs';
import { filter, map } from 'rxjs/operators';
import { Compliance } from 'app/shared/model/compliance.model';
import { ComplianceService } from './compliance.service';
import { ComplianceComponent } from './compliance.component';
import { ComplianceDetailComponent } from './compliance-detail.component';
import { ComplianceUpdateComponent } from './compliance-update.component';
import { ICompliance } from 'app/shared/model/compliance.model';
import { DeletePopupComponent } from 'app/shared';
import { AuthoritiesConst } from 'app/shared/util/authorities-const';

@Injectable({ providedIn: 'root' })
export class ComplianceResolve implements Resolve<ICompliance> {
  constructor(private service: ComplianceService) {}

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<ICompliance> {
    const id = route.params['compliance-id'] ? route.params['compliance-id'] : null;
    if (id) {
      return this.service.find(id).pipe(
        filter((response: HttpResponse<Compliance>) => response.ok),
        map((compliance: HttpResponse<Compliance>) => compliance.body)
      );
    }
    return of(new Compliance());
  }
}

export const complianceRoute: Routes = [
  {
    path: '',
    component: ComplianceComponent,
    data: {
      pageTitle: 'khanbankCpmsApp.compliance.home.title',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: 'new',
    component: ComplianceUpdateComponent,
    resolve: {
      compliance: ComplianceResolve,
    },
    data: {
      authorities: [AuthoritiesConst.ROLE_ADMIN, AuthoritiesConst.ROLE_CS, AuthoritiesConst.ROLE_CA],
      pageTitle: 'khanbankCpmsApp.compliance.home.title',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':compliance-id',
    component: ComplianceDetailComponent,
    resolve: {
      compliance: ComplianceResolve,
    },
    data: {
      pageTitle: 'khanbankCpmsApp.compliance.home.title',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':compliance-id/edit',
    component: ComplianceUpdateComponent,
    resolve: {
      compliance: ComplianceResolve,
    },
    data: {
      authorities: [AuthoritiesConst.ROLE_ADMIN, AuthoritiesConst.ROLE_CS, AuthoritiesConst.ROLE_CA],
      pageTitle: 'khanbankCpmsApp.compliance.home.title',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':compliance-id/delete',
    component: DeletePopupComponent,
    resolve: {
      resourceToDelete: ComplianceResolve,
    },
    data: {
      authorities: [AuthoritiesConst.ROLE_ADMIN, AuthoritiesConst.ROLE_CS, AuthoritiesConst.ROLE_CA],
      pageTitle: 'khanbankCpmsApp.compliance.home.title',
      deleteUrl: 'api/compliances',
      broadcastName: 'complianceListModification',
    },
    canActivate: [UserRouteAccessService],
    outlet: 'popup',
  },
];

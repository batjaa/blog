import { HttpErrorResponse, HttpResponse } from '@angular/common/http';
import { TranslateService } from '@ngx-translate/core';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Params } from '@angular/router';
import { Grant, IGrant } from 'app/shared/model/grant.model';
import { JhiAlertService, JhiDataUtils } from 'ng-jhipster';
import { Observable } from 'rxjs';
import { GrantService } from './grant.service';
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import { AlertService } from '../../shared/services/alert.service';

@Component({
  selector: 'jhi-grant-update',
  templateUrl: './grant-update.component.html',
  styleUrls: ['./grant-update.component.scss'],
})
export class GrantUpdateComponent implements OnInit {
  grant: IGrant;
  isSaving: boolean;
  isAddedFile: boolean;
  projectId: number;
  grantId: number;
  Editor = ClassicEditor;
  notesConfig = {};
  purposeConfig = {};
  commentConfig = {};
  action = '';

  editForm = this.fb.group({
    id: [],
    notes: '',
    purpose: '',
    comment: '',
    amount: [null, [Validators.required, Validators.minLength(1), Validators.maxLength(15)]],
  });
  private fileIds: number[];
  constructor(
    protected dataUtils: JhiDataUtils,
    protected jhiAlertService: JhiAlertService,
    protected grantService: GrantService,
    protected activatedRoute: ActivatedRoute,
    private translateService: TranslateService,
    private fb: FormBuilder,
    private alert: AlertService
  ) {
    (this.notesConfig = {
      removePlugins: ['ImageUpload', 'MediaEmbed'],
      placeholder: translateService.instant('khanbankCpmsApp.grant.notes'),
    }),
      (this.commentConfig = {
        removePlugins: ['ImageUpload', 'MediaEmbed'],
        placeholder: translateService.instant('khanbankCpmsApp.grant.comment'),
      }),
      (this.purposeConfig = {
        removePlugins: ['ImageUpload', 'MediaEmbed'],
        placeholder: translateService.instant('khanbankCpmsApp.grant.purpose'),
      });
  }

  ngOnInit() {
    this.isSaving = false;
    this.fileIds = [];
    this.activatedRoute.data.subscribe(({ grant }) => {
      this.updateForm(grant);
      this.grant = grant;
    });

    this.activatedRoute.parent.parent.params.subscribe((params: Params) => {
      this.projectId = params['id'];
    });

    this.activatedRoute.params.subscribe((params: Params) => {
      this.grantId = params['compliance-id'];
    });
  }

  updateForm(grant: IGrant) {
    this.editForm.patchValue({
      id: grant.id,
      notes: grant.notes,
      purpose: grant.purpose,
      comment: grant.comment,
      amount: grant.amount,
      project: grant.project,
    });
    if (grant.files) {
      grant.files.forEach(file => {
        this.isAddedFile = true;
        this.fileIds.push(file.id);
      });
    }
  }

  previousState() {
    window.history.back();
  }

  save() {
    this.isSaving = true;
    const grant = this.createFromForm();
    if (grant.id !== undefined) {
      this.subscribeToSaveResponse(this.grantService.update(grant));
    } else {
      this.subscribeToSaveResponse(this.grantService.create(this.projectId, grant));
    }
  }

  private createFromForm(): IGrant {
    const entity = {
      ...new Grant(),
      id: this.grantId,
      notes: this.editForm.get('notes').value,
      purpose: this.editForm.get('purpose').value,
      comment: this.editForm.get('comment').value,
      amount: this.editForm.get(['amount']).value,
      fileIds: this.fileIds,
    };
    return entity;
  }

  protected subscribeToSaveResponse(result: Observable<HttpResponse<IGrant>>) {
    result.subscribe((res: HttpResponse<IGrant>) => this.onSaveSuccess(res.statusText), (res: HttpErrorResponse) => this.onSaveError(res.message));
  }

  protected onSaveSuccess(message) {
    this.isSaving = false;
    if (message === 'Created') {
      this.action = this.translateService.instant('khanbankCpmsApp.grant.created');
      this.alert.success(this.action, '', 3000);
    } else if (message === 'OK') {
      this.action = this.translateService.instant('khanbankCpmsApp.grant.updated');
      this.alert.success(this.action, '', 3000);
    }
    this.previousState();
  }

  protected onSaveError(message) {
    this.isSaving = false;
    this.alert.error(message, '', 3000);
  }

  protected onError(errorMessage: string) {
    this.jhiAlertService.error(errorMessage, null, null);
  }

  setFile(fileId: number) {
    this.isAddedFile = true;
    this.fileIds.push(fileId);
  }
}

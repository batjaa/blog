import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Params } from '@angular/router';
import { Observable } from 'rxjs';
import { filter, map } from 'rxjs/operators';
import * as moment from 'moment';
import { DATE_TIME_FORMAT, DATE_FORMAT } from 'app/shared/constants/input.constants';
import { JhiAlertService } from 'ng-jhipster';
import { IProjectCostEstimateSubmission, ProjectCostEstimateSubmission } from 'app/shared/model/project-cost-estimate-submission.model';
import { ProjectCostEstimateSubmissionService } from './project-cost-estimate-submission.service';
import { IFile } from 'app/shared/model/file.model';
import { IProjectCostEstimate } from 'app/shared/model/project-cost-estimate.model';
import { ProjectCostEstimateService } from 'app/views/project/cost-estimate';
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import { AlertService } from '../../shared/services/alert.service';

@Component({
  selector: 'jhi-project-cost-estimate-submission-update',
  templateUrl: './project-cost-estimate-submission-update.component.html',
  styleUrls: ['./project-cost-estimate-submission-update.component.scss'],
})
export class ProjectCostEstimateSubmissionUpdateComponent implements OnInit {
  projectCostEstimateSubmission: IProjectCostEstimateSubmission;
  isSaving: boolean;
  projectId: number;

  file: IFile;

  projectCostEstimate: IProjectCostEstimate;
  Editor = ClassicEditor;
  editorConfig = {};
  action = '';

  editForm = this.fb.group({
    id: [],
    status: [],
    submittedBy: [],
    respondedBy: [],
    submittedAt: [],
    respondedAt: [],
    notes: '',
    deletedAt: [],
    file: [],
    projectCostEstimate: [],
  });

  constructor(
    protected jhiAlertService: JhiAlertService,
    protected projectCostEstimateSubmissionService: ProjectCostEstimateSubmissionService,
    protected projectCostEstimateService: ProjectCostEstimateService,
    protected activatedRoute: ActivatedRoute,
    private translateService: TranslateService,
    private fb: FormBuilder,
    private alert: AlertService
  ) {
    this.editorConfig = {
      removePlugins: ['ImageUpload', 'MediaEmbed'],
      placeholder: translateService.instant('khanbankCpmsApp.projectCostEstimateSubmission.notes'),
    };
  }

  ngOnInit() {
    this.isSaving = false;
    this.activatedRoute.data.subscribe(({ projectCostEstimateSubmission }) => {
      this.projectCostEstimateSubmission = projectCostEstimateSubmission;
    });

    this.activatedRoute.parent.parent.params.subscribe((params: Params) => {
      this.projectId = params['id'];
    });

    this.projectCostEstimateService
      .findByProjectId(this.projectId)
      .pipe(
        filter((mayBeOk: HttpResponse<IProjectCostEstimate>) => mayBeOk.ok),
        map((response: HttpResponse<IProjectCostEstimate>) => response.body)
      )
      .subscribe((res: IProjectCostEstimate) => (this.projectCostEstimate = res), (res: HttpErrorResponse) => this.onError(res.message));
    this.editForm.get('status').patchValue(this.editForm.get('status').value || null);
  }

  previousState() {
    window.history.back();
  }

  save() {
    this.isSaving = true;
    const projectCostEstimateSubmission = this.createFromForm();
    this.subscribeToSaveResponse(this.projectCostEstimateSubmissionService.create(this.projectId, projectCostEstimateSubmission));
  }

  private createFromForm(): IProjectCostEstimateSubmission {
    const entity = {
      ...new ProjectCostEstimateSubmission(),
      status: this.editForm.get(['status']).value,
      notes: this.editForm.get('notes').value,
      file: this.file,
      projectCostEstimate: this.projectCostEstimate,
    };
    return entity;
  }

  protected subscribeToSaveResponse(result: Observable<HttpResponse<IProjectCostEstimateSubmission>>) {
    result.subscribe(
      (res: HttpResponse<IProjectCostEstimateSubmission>) => this.onSaveSuccess(res.statusText),
      (res: HttpErrorResponse) => this.onSaveError(res.message)
    );
  }

  protected onSaveSuccess(message) {
    this.isSaving = false;
    if (message === 'Created') {
      this.action = this.translateService.instant('khanbankCpmsApp.projectCostEstimateSubmission.created');
      this.alert.success(this.action, '', 3000);
    } else if (message === 'OK') {
      this.action = this.translateService.instant('khanbankCpmsApp.projectCostEstimateSubmission.updated');
      this.alert.success(this.action, '', 3000);
    }
    this.previousState();
  }

  protected onSaveError(message) {
    this.isSaving = false;
    this.alert.error(message, '', 3000);
  }
  protected onError(errorMessage: string) {
    this.jhiAlertService.error(errorMessage, null, null);
  }

  trackFileById(index: number, item: IFile) {
    return item.id;
  }

  trackProjectCostEstimateById(index: number, item: IProjectCostEstimate) {
    return item.id;
  }

  setFile(file: IFile) {
    this.file = file;
  }
}

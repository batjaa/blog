export * from './building.service';
export * from './building-update.component';
export * from './building-detail.component';
export * from './building.component';
export * from './building.route';

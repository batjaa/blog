import { HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot, Routes } from '@angular/router';
import { UserRouteAccessService } from 'app/core';
import { DeletePopupComponent } from 'app/shared';
import { Building, IBuilding } from 'app/shared/model/building.model';
import { Observable, of } from 'rxjs';
import { filter, map } from 'rxjs/operators';
import { BuildingDetailComponent } from './building-detail.component';
import { BuildingUpdateComponent } from './building-update.component';
import { BuildingComponent } from './building.component';
import { BuildingService } from './building.service';
import { AuthoritiesConst } from 'app/shared/util/authorities-const';

@Injectable({ providedIn: 'root' })
export class BuildingResolve implements Resolve<IBuilding> {
  constructor(private service: BuildingService) {}

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<IBuilding> {
    const id = route.params['building-id'] ? route.params['building-id'] : null;
    if (id) {
      return this.service.find(id).pipe(
        filter((response: HttpResponse<Building>) => response.ok),
        map((building: HttpResponse<Building>) => building.body)
      );
    }
    return of(new Building());
  }
}

export const buildingRoute: Routes = [
  {
    path: '',
    component: BuildingComponent,
    resolve: {
      building: BuildingResolve,
    },
    data: {
      authorities: [AuthoritiesConst.ROLE_ADMIN, AuthoritiesConst.ROLE_CLIENT],
      pageTitle: 'khanbankCpmsApp.building.home.title',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: 'new',
    component: BuildingUpdateComponent,
    resolve: {
      building: BuildingResolve,
    },
    data: {
      authorities: [AuthoritiesConst.ROLE_ADMIN, AuthoritiesConst.ROLE_CLIENT],
      pageTitle: 'khanbankCpmsApp.building.home.title',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':building-id',
    component: BuildingDetailComponent,
    resolve: {
      building: BuildingResolve,
    },
    data: {
      authorities: [AuthoritiesConst.ROLE_ADMIN, AuthoritiesConst.ROLE_CLIENT],
      pageTitle: 'khanbankCpmsApp.building.home.title',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':building-id/edit',
    component: BuildingUpdateComponent,
    resolve: {
      building: BuildingResolve,
    },
    data: {
      authorities: [AuthoritiesConst.ROLE_ADMIN, AuthoritiesConst.ROLE_CLIENT],
      pageTitle: 'khanbankCpmsApp.building.home.title',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':building-id/delete',
    component: DeletePopupComponent,
    resolve: {
      resourceToDelete: BuildingResolve,
    },
    data: {
      authorities: [AuthoritiesConst.ROLE_ADMIN, AuthoritiesConst.ROLE_CLIENT],
      pageTitle: 'khanbankCpmsApp.building.home.title',
      deleteUrl: 'api/buildings',
      broadcastName: 'companyListModification',
    },
    canActivate: [UserRouteAccessService],
    outlet: 'popup',
  },
];

import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';

import { SERVER_API_URL } from 'app/app.constants';
import { createRequestOption } from 'app/shared';
import { IEngineerAssessment } from 'app/shared/model/engineer-assessment.model';

type EntityResponseType = HttpResponse<IEngineerAssessment>;
type EntityArrayResponseType = HttpResponse<IEngineerAssessment[]>;

@Injectable({ providedIn: 'root' })
export class EngineerAssessmentService {
  public resourceUrl = SERVER_API_URL + 'api/engineer-assessments';
  public projectApiUrl = SERVER_API_URL + 'api/projects';

  constructor(protected http: HttpClient) { }

  create(projectId: number, engineerAssessment: IEngineerAssessment): Observable<EntityResponseType> {
    return this.http.post<IEngineerAssessment>(`${this.projectApiUrl}/${projectId}/engineer-assessments`, engineerAssessment, {
      observe: 'response',
    });
  }

  update(engineerAssessment: IEngineerAssessment): Observable<EntityResponseType> {
    return this.http.put<IEngineerAssessment>(this.resourceUrl, engineerAssessment, { observe: 'response' });
  }

  find(id: number): Observable<EntityResponseType> {
    return this.http.get<IEngineerAssessment>(`${this.resourceUrl}/${id}`, { observe: 'response' });
  }

  findByProjectId(projectId: number, req?: any): Observable<EntityArrayResponseType> {
    const options = createRequestOption(req);
    return this.http.get<IEngineerAssessment[]>(`${this.projectApiUrl}/${projectId}/engineer-assessments`, {
      params: options,
      observe: 'response',
    });
  }

  query(req?: any): Observable<EntityArrayResponseType> {
    const options = createRequestOption(req);
    return this.http.get<IEngineerAssessment[]>(this.resourceUrl, { params: options, observe: 'response' });
  }

  delete(id: number): Observable<HttpResponse<any>> {
    return this.http.delete<any>(`${this.resourceUrl}/${id}`, { observe: 'response' });
  }
}

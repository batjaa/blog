import { AuthoritiesForm } from 'app/shared/components/form/authorities.form';
import { AuthoritiesConst } from 'app/shared/util/authorities-const';

export class InstallmentAuthority extends AuthoritiesForm {
  constructor() {
    super();

    this.setNewAnyAuthority([AuthoritiesConst.ROLE_ADMIN, AuthoritiesConst.ROLE_CS, AuthoritiesConst.ROLE_CA]);
    this.setUpdateAnyAuthority([AuthoritiesConst.ROLE_ADMIN, AuthoritiesConst.ROLE_CS, AuthoritiesConst.ROLE_CA]);
    this.setDeleteAnyAuthority([AuthoritiesConst.ROLE_ADMIN, AuthoritiesConst.ROLE_CS, AuthoritiesConst.ROLE_CA]);
  }
}

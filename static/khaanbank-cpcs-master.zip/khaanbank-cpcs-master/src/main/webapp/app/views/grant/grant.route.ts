import { HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot, Routes } from '@angular/router';
import { UserRouteAccessService } from 'app/core';
import { DeletePopupComponent } from 'app/shared';
import { Grant, IGrant } from 'app/shared/model/grant.model';
import { Observable, of } from 'rxjs';
import { filter, map } from 'rxjs/operators';
import { GrantDetailComponent } from './grant-detail.component';
import { GrantUpdateComponent } from './grant-update.component';
import { GrantComponent } from './grant.component';
import { GrantService } from './grant.service';
import { AuthoritiesConst } from 'app/shared/util/authorities-const';

@Injectable({ providedIn: 'root' })
export class GrantResolve implements Resolve<IGrant> {
  constructor(private service: GrantService) {}

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<IGrant> {
    const id = route.params['grant-id'] ? route.params['grant-id'] : null;
    if (id) {
      return this.service.find(id).pipe(
        filter((response: HttpResponse<Grant>) => response.ok),
        map((grant: HttpResponse<Grant>) => grant.body)
      );
    }
    return of(new Grant());
  }
}

export const grantRoute: Routes = [
  {
    path: '',
    component: GrantComponent,
    data: {
      pageTitle: 'khanbankCpmsApp.grant.home.title',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: 'new',
    component: GrantUpdateComponent,
    resolve: {
      grant: GrantResolve,
    },
    data: {
      authorities: [AuthoritiesConst.ROLE_ADMIN, AuthoritiesConst.ROLE_CS],
      pageTitle: 'khanbankCpmsApp.grant.home.title',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':grant-id',
    component: GrantDetailComponent,
    resolve: {
      grant: GrantResolve,
    },
    data: {
      pageTitle: 'khanbankCpmsApp.grant.home.title',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':grant-id/edit',
    component: GrantUpdateComponent,
    resolve: {
      grant: GrantResolve,
    },
    data: {
      authorities: [AuthoritiesConst.ROLE_ADMIN, AuthoritiesConst.ROLE_CS],
      pageTitle: 'khanbankCpmsApp.grant.home.title',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':grant-id/delete',
    component: DeletePopupComponent,
    resolve: {
      resourceToDelete: GrantResolve,
    },
    data: {
      authorities: [AuthoritiesConst.ROLE_ADMIN],
      pageTitle: 'khanbankCpmsApp.grant.home.title',
      deleteUrl: 'api/grants',
      broadcastName: 'grantListModification',
    },
    canActivate: [UserRouteAccessService],
    outlet: 'popup',
  },
];

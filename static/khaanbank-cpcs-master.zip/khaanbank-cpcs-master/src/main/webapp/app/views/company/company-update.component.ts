import { Component, OnInit } from '@angular/core';
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Params } from '@angular/router';
import { Observable } from 'rxjs';
import { ICompany, Company } from 'app/shared/model/company.model';
import { CompanyService } from './company.service';
import { AlertService } from '../../shared/services/alert.service';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'jhi-company-update',
  templateUrl: './company-update.component.html',
})
export class CompanyUpdateComponent implements OnInit {
  company: ICompany;
  isSaving: boolean;
  id: number;
  action = '';

  editForm = this.fb.group({
    name: [null, [Validators.required]],
  });

  constructor(
    protected route: ActivatedRoute,
    protected companyService: CompanyService,
    protected activatedRoute: ActivatedRoute,
    private fb: FormBuilder,
    private alert: AlertService,
    private translateService: TranslateService
  ) { }

  ngOnInit() {
    this.isSaving = false;
    this.route.params.subscribe((params: Params) => {
      this.id = params['id'];
    });
    this.activatedRoute.data.subscribe(({ company }) => {
      this.updateForm(company);
      this.company = company;
    });
  }

  updateForm(company: ICompany) {
    this.editForm.patchValue({
      name: company.name,
    });

  }

  previousState() {
    window.history.back();
  }

  save() {
    this.isSaving = true;
    const company = this.createFromForm();
    if (company.id !== undefined) {
      this.subscribeToSaveResponse(this.companyService.update(company));
    } else {
      this.subscribeToSaveResponse(this.companyService.create(company));
    }
  }

  private createFromForm(): ICompany {
    const entity = {
      ...new Company(),
      id: this.id,
      name: this.editForm.get(['name']).value,
    };
    return entity;
  }

  protected subscribeToSaveResponse(result: Observable<HttpResponse<ICompany>>) {
    result.subscribe((res: HttpResponse<ICompany>) => this.onSaveSuccess(res.statusText), (res: HttpErrorResponse) => this.onSaveError(res.message));
  }

  protected onSaveSuccess(message) {
    this.isSaving = false;
    if (message === 'Created') {
      this.action = this.translateService.instant('khanbankCpmsApp.company.created', { param: this.editForm.get(['name']).value });
      this.alert.success(this.action, '', 3000);
    } else if (message === 'OK') {
      this.action = this.translateService.instant('khanbankCpmsApp.company.updated', { param: this.editForm.get(['name']).value });
      this.alert.success(this.action, '', 3000);
    }
    this.previousState();
  }

  protected onSaveError(message) {
    this.isSaving = false;
    this.alert.error(message, '', 3000);
  }
}

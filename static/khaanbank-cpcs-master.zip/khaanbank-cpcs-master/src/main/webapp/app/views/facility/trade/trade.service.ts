import { HttpClient, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SERVER_API_URL } from 'app/app.constants';
import { ITrade } from 'app/shared/model/trade.model';
import * as moment from 'moment';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

type EntityResponseType = HttpResponse<ITrade>;
type EntityArrayResponseType = HttpResponse<ITrade[]>;

@Injectable({ providedIn: 'root' })
export class TradeService {
  public resourceUrl = SERVER_API_URL + 'api/trades';
  public facilityUrl = SERVER_API_URL + 'api/facilities';

  constructor(protected http: HttpClient, private router: Router, protected route: ActivatedRoute) {}

  create(facilityId: number, trade: ITrade): Observable<EntityResponseType> {
    return this.http
      .post<ITrade>(`${this.facilityUrl}/${facilityId}/trades`, trade, { observe: 'response' })
      .pipe(map((res: EntityResponseType) => this.convertDateFromServer(res)));
  }

  update(trade: ITrade): Observable<EntityResponseType> {
    return this.http
      .put<ITrade>(this.resourceUrl, trade, { observe: 'response' })
      .pipe(map((res: EntityResponseType) => this.convertDateFromServer(res)));
  }

  findByFacilityId(facilityId: number): Observable<EntityResponseType> {
    return this.http
      .get<ITrade>(`${this.facilityUrl}/${facilityId}/trade`, { observe: 'response' })
      .pipe(map((res: EntityResponseType) => this.convertDateFromServer(res)));
  }

  protected convertDateFromServer(res: EntityResponseType): EntityResponseType {
    if (res.body) {
      res.body.purchasedAt = res.body.purchasedAt != null ? moment(res.body.purchasedAt) : null;
      res.body.updatedAt = res.body.updatedAt != null ? moment(res.body.updatedAt) : null;
      res.body.createdAt = res.body.createdAt != null ? moment(res.body.createdAt) : null;
    }
    return res;
  }

  protected convertDateArrayFromServer(res: EntityArrayResponseType): EntityArrayResponseType {
    if (res.body) {
      res.body.forEach((trade: ITrade) => {
        trade.purchasedAt = trade.purchasedAt != null ? moment(trade.purchasedAt) : null;
        trade.updatedAt = trade.updatedAt != null ? moment(trade.updatedAt) : null;
        trade.createdAt = trade.createdAt != null ? moment(trade.createdAt) : null;
      });
    }
    return res;
  }
}

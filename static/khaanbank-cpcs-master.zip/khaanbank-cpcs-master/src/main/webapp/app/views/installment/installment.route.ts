import { Injectable } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot, Routes } from '@angular/router';
import { UserRouteAccessService } from 'app/core';
import { Observable, of } from 'rxjs';
import { filter, map } from 'rxjs/operators';
import { Installment } from 'app/shared/model/installment.model';
import { InstallmentService } from './installment.service';
import { InstallmentComponent } from './installment.component';
import { InstallmentDetailComponent } from './installment-detail.component';
import { InstallmentUpdateComponent } from './installment-update.component';
import { IInstallment } from 'app/shared/model/installment.model';
import { DeletePopupComponent } from 'app/shared';
import { AuthoritiesConst } from 'app/shared/util/authorities-const';

@Injectable({ providedIn: 'root' })
export class InstallmentResolve implements Resolve<IInstallment> {
  constructor(private service: InstallmentService) {}

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<IInstallment> {
    const id = route.params['installment-id'] ? route.params['installment-id'] : null;
    if (id) {
      return this.service.find(id).pipe(
        filter((response: HttpResponse<Installment>) => response.ok),
        map((installment: HttpResponse<Installment>) => installment.body)
      );
    }
    return of(new Installment());
  }
}

export const installmentRoute: Routes = [
  {
    path: '',
    component: InstallmentComponent,
    data: {
      pageTitle: 'khanbankCpmsApp.installment.home.title',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: 'trade/installment/new',
    component: InstallmentUpdateComponent,
    resolve: {
      installment: InstallmentResolve,
    },
    data: {
      authorities: [AuthoritiesConst.ROLE_ADMIN, AuthoritiesConst.ROLE_CS, AuthoritiesConst.ROLE_CA],
      pageTitle: 'khanbankCpmsApp.installment.home.title',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: 'trade/installment/:installment-id',
    component: InstallmentDetailComponent,
    resolve: {
      installment: InstallmentResolve,
    },
    data: {
      pageTitle: 'khanbankCpmsApp.installment.home.title',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: 'trade/installment/:installment-id/edit',
    component: InstallmentUpdateComponent,
    resolve: {
      installment: InstallmentResolve,
    },
    data: {
      authorities: [AuthoritiesConst.ROLE_ADMIN, AuthoritiesConst.ROLE_CS, AuthoritiesConst.ROLE_CA],
      pageTitle: 'khanbankCpmsApp.installment.home.title',
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: 'trade/installment/:installment-id/delete',
    component: DeletePopupComponent,
    resolve: {
      resourceToDelete: InstallmentResolve,
    },
    data: {
      authorities: [AuthoritiesConst.ROLE_ADMIN, AuthoritiesConst.ROLE_CS, AuthoritiesConst.ROLE_CA],
      pageTitle: 'khanbankCpmsApp.installment.home.title',
      deleteUrl: 'api/installments',
      broadcastName: 'installmentListModification',
    },
    canActivate: [UserRouteAccessService],
    outlet: 'popup',
  },
];

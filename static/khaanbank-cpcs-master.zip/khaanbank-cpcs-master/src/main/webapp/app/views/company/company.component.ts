import { Component, OnInit, OnDestroy, ElementRef } from '@angular/core';
import { HttpErrorResponse, HttpHeaders, HttpResponse } from '@angular/common/http';
import { Subscription } from 'rxjs';
import { JhiEventManager, JhiParseLinks, JhiAlertService } from 'ng-jhipster';

import { ICompany } from 'app/shared/model/company.model';
import { AccountService } from 'app/core';

import { ITEMS_PER_PAGE, ROW_HEIGHT, HEADER_HEIGHT } from 'app/shared';
import { CompanyService } from './company.service';
import { Router, ActivatedRoute } from '@angular/router';
import { CompanyAuthority } from './company-any-authority';

@Component({
  selector: 'jhi-company',
  templateUrl: './company.component.html',
})
export class CompanyComponent extends CompanyAuthority implements OnInit, OnDestroy {
  readonly headerHeight: number;
  readonly rowHeight: number;

  isLoading: boolean;

  companies: ICompany[];
  currentAccount: any;
  eventSubscriber: Subscription;
  itemsPerPage: number;
  links: any;
  page: any;
  predicates = [];
  totalItems: number;
  sortType: string;
  constructor(
    protected companyService: CompanyService,
    protected jhiAlertService: JhiAlertService,
    protected eventManager: JhiEventManager,
    protected parseLinks: JhiParseLinks,
    protected accountService: AccountService,
    protected router: Router,
    protected activatedRoute: ActivatedRoute,
    protected element: ElementRef
  ) {
    super();

    this.companies = [];
    this.itemsPerPage = ITEMS_PER_PAGE;
    this.headerHeight = HEADER_HEIGHT;
    this.rowHeight = ROW_HEIGHT;
    this.page = 0;
    this.links = {
      last: 0,
    };
    this.predicates = [
      {
        name: 'name',
        reverse: true,
      },
      {
        name: 'updatedAt',
        reverse: false,
      },
    ];
  }

  loadAll() {
    this.isLoading = true;

    this.companyService
      .query({
        page: this.page,
        size: this.itemsPerPage,
        sort: this.sort(),
      })
      .subscribe(
        (res: HttpResponse<ICompany[]>) => this.paginateCompanies(res.body, res.headers),
        (res: HttpErrorResponse) => this.onError(res.message)
      );
  }

  reset() {
    this.page = 0;
    this.companies = [];
    this.loadAll();
  }

  onScroll(offsetY: number) {
    // харагдаж байгаа мөрүүдийн нийт өндөр
    const viewHeight = this.element.nativeElement.getBoundingClientRect().height - this.headerHeight;

    // scroll хамгийн доод хэсэгт очсон эсэхийг шалгах
    if (!this.isLoading && offsetY + viewHeight >= this.companies.length * this.rowHeight) {
      this.loadPage(this.page);
    }
  }

  loadPage(page) {
    this.page = page + 1;
    if (this.page > this.links['last']) {
      return null;
    }
    this.loadAll();
  }

  ngOnInit() {
    this.loadAll();
    this.accountService.identity().then(account => {
      this.currentAccount = account;
    });
    this.registerChangeInCompanies();
  }

  ngOnDestroy() {
    this.eventManager.destroy(this.eventSubscriber);
  }

  trackId(index: number, item: ICompany) {
    return item.id;
  }

  registerChangeInCompanies() {
    this.eventSubscriber = this.eventManager.subscribe('companyListModification', response => this.reset());
  }

  sort() {
    const result = this.predicates.map(function(predicate) {
      return predicate.name + ',' + (predicate.reverse ? 'asc' : 'desc');
    });
    return result;
  }

  onSort(event) {
    const sort = event.sorts[0];
    this.predicates = [
      {
        name: sort.prop,
        reverse: !this.predicates[0].reverse,
      },
    ];
    this.reset();
  }

  protected paginateCompanies(data: ICompany[], headers: HttpHeaders) {
    this.links = this.parseLinks.parse(headers.get('link'));
    this.totalItems = parseInt(headers.get('X-Total-Count'), 10);
    const rows = this.companies;
    for (let i = 0; i < data.length; i++) {
      rows.push(data[i]);
    }
    this.companies = rows;
    this.isLoading = false;
  }

  protected onError(errorMessage: string) {
    this.jhiAlertService.error(errorMessage, null, null);
  }

  onSelect({ selected }) {
    this.router.navigate(['/company', selected[0].id], { relativeTo: this.activatedRoute });
  }

  onEdit(event, id) {
    this.router.navigate([id, 'edit'], { relativeTo: this.activatedRoute });
    event.stopPropagation();
  }

  onDelete(event, id) {
    this.router.navigate([{ outlets: { popup: id + '/delete' } }], { relativeTo: this.activatedRoute });
    event.stopPropagation();
  }
}

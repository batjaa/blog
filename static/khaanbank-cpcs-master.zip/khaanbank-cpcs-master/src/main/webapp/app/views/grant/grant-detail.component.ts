import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { JhiDataUtils } from 'ng-jhipster';

import { IGrant } from 'app/shared/model/grant.model';
import { GrantAuthority } from './grant-any-authority';

@Component({
  selector: 'jhi-grant-detail',
  templateUrl: './grant-detail.component.html',
})
export class GrantDetailComponent extends GrantAuthority implements OnInit {
  grant: IGrant;

  constructor(protected dataUtils: JhiDataUtils, protected activatedRoute: ActivatedRoute) {
    super();
  }

  ngOnInit() {
    this.activatedRoute.data.subscribe(({ grant }) => {
      this.grant = grant;
    });
  }

  byteSize(field) {
    return this.dataUtils.byteSize(field);
  }

  openFile(contentType, field) {
    return this.dataUtils.openFile(contentType, field);
  }
  previousState() {
    window.history.back();
  }
}

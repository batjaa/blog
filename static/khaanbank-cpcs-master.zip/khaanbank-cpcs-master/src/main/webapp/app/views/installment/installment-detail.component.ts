import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { IInstallment } from 'app/shared/model/installment.model';
import { AuthoritiesForm } from 'app/shared/components/form/authorities.form';
import { AuthoritiesConst } from 'app/shared/util/authorities-const';
import { InstallmentAuthority } from './installment-any-authority';

@Component({
  selector: 'jhi-installment-detail',
  templateUrl: './installment-detail.component.html',
})
export class InstallmentDetailComponent extends InstallmentAuthority implements OnInit {
  installment: IInstallment;

  constructor(protected activatedRoute: ActivatedRoute) {
    super();
  }

  ngOnInit() {
    this.activatedRoute.data.subscribe(({ installment }) => {
      this.installment = installment;
    });
  }

  previousState() {
    window.history.back();
  }
}

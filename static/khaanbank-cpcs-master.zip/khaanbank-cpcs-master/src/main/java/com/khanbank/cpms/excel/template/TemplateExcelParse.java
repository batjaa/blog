package com.khanbank.cpms.excel.template;

import java.io.InputStream;
import java.util.List;

import com.khanbank.cpms.excel.SheetCellView;

public interface TemplateExcelParse {

    InputStream getInputStream();

    boolean isLockedGroupSheet();

    List<SheetCellView> getSheetCellViews();

    Class<?> getMapperType();

}

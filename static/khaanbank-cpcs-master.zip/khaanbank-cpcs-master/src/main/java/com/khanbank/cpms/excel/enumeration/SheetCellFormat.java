package com.khanbank.cpms.excel.enumeration;

public enum SheetCellFormat {
    NONE(""), YEAR_DATE("YYYY-MM");
    
    private String format;

    SheetCellFormat(String format) {
        this.format = format;
    }

    public String getFormat() {
        return format;
    }

    public void setFormat(String format) {
        this.format = format;
    }

}

/**
 * Spring Data JPA repositories.
 */
package com.khanbank.cpms.repository;

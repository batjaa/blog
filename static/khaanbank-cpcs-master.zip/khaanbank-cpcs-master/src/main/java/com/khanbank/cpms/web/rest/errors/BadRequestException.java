package com.khanbank.cpms.web.rest.errors;

import java.util.Map;

import org.zalando.problem.AbstractThrowableProblem;
import org.zalando.problem.Status;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true, value = { "status", "title" })
public class BadRequestException extends AbstractThrowableProblem {
    private static final long serialVersionUID = 1L;

    @JsonProperty
    private final String code;
    @JsonProperty
    private final String message;
    @JsonProperty
    private final Map<String, Object> details;

    public BadRequestException(Status status, String code, String message, Map<String, Object> details) {
        super(null, message, status, null, null, null, details);
        this.code = code;
        this.message = message;
        this.details = details;
    }

    public BadRequestException(Status status, String code, String message) {
        super(ErrorConstants.DEFAULT_TYPE, message, status, null, null, null, null);
        this.code = code;
        this.message = message;
        this.details = null;
    }

    public String getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }

    public Map<String, Object> getDetails() {
        return details;
    }

}

package com.khanbank.cpms.excel.exception;

public class TemplateException extends Exception {

    private static final long serialVersionUID = 1L;

    public TemplateException(String messageException) {
        super(messageException);
    }

}

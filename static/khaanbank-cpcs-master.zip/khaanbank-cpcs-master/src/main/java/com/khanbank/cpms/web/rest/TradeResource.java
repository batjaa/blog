package com.khanbank.cpms.web.rest;

import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.khanbank.cpms.domain.Installment;
import com.khanbank.cpms.domain.Project;
import com.khanbank.cpms.domain.Trade;
import com.khanbank.cpms.repository.InstallmentRepository;
import com.khanbank.cpms.repository.ProjectRepository;
import com.khanbank.cpms.repository.TradeRepository;
import com.khanbank.cpms.service.util.HelperUtil;

import io.github.jhipster.web.util.HeaderUtil;
import io.github.jhipster.web.util.PaginationUtil;
import io.github.jhipster.web.util.ResponseUtil;

/**
 * REST controller for managing {@link com.khanbank.cpms.domain.Trade}.
 */
@RestController
@RequestMapping("/api")
public class TradeResource {

    private final Logger log = LoggerFactory.getLogger(TradeResource.class);

    private static final String ENTITY_NAME = "trade";

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final TradeRepository tradeRepository;

    @Autowired
    private InstallmentRepository installmentRepo;

    @Autowired
    private ProjectRepository projectRepo;

    @Autowired
    private ProjectResource projectResource;

    public TradeResource(TradeRepository tradeRepository) {
        this.tradeRepository = tradeRepository;
    }

    /**
     * {@code PUT  /trades} : Updates an existing trade.
     *
     * @param trade
     *            the trade to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated trade, or with status {@code 400 (Bad Request)} if the trade is not valid, or with status
     *         {@code 500 (Internal Server Error)} if the trade couldn't be updated.
     * @throws URISyntaxException
     *             if the Location URI syntax is incorrect.
     */
    @PutMapping("/trades")
    public ResponseEntity<Trade> updateTrade(@Valid @RequestBody Trade trade) throws URISyntaxException {
        log.debug("REST request to update Trade : {}", trade);

        Optional<Trade> optOldTrade = tradeRepository.findById(trade.getId());

        boolean updateEntity = HelperUtil.updateObjectRequiredFields(optOldTrade, trade, "facility");

        if (!updateEntity)
            return ResponseEntity.badRequest().build();

        Trade result = tradeRepository.save(trade);

        String message = "Борлуулалтын мэдээлэл шинчлэгдлээ";
        sendNotification(result, message);

        return ResponseEntity.ok().headers(
                HeaderUtil.createEntityUpdateAlert(applicationName, true, ENTITY_NAME, trade.getId().toString()))
                .body(result);
    }

    /**
     * {@code GET  /trades/:id} : get the "id" trade.
     *
     * @param id
     *            the id of the trade to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the trade, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/trades/{id}")
    public ResponseEntity<Trade> getTrade(@PathVariable Long id) {
        log.debug("REST request to get Trade : {}", id);
        Optional<Trade> trade = tradeRepository.findById(id);
        return ResponseUtil.wrapOrNotFound(trade);
    }

    /**
     * {@code DELETE  /trades/:id} : delete the "id" trade.
     *
     * @param id
     *            the id of the trade to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/trades/{id}")
    public ResponseEntity<Void> deleteTrade(@PathVariable Long id) {
        log.debug("REST request to delete Trade : {}", id);
        tradeRepository.deleteById(id);
        return ResponseEntity.noContent()
                .headers(HeaderUtil.createEntityDeletionAlert(applicationName, true, ENTITY_NAME, id.toString()))
                .build();
    }

    @PostMapping("/trades/{id}/installments")
    public ResponseEntity<Installment> createTradeIntallment(@PathVariable Long id,
            @RequestBody Installment installment) {

        // TODO Allow: Everyone who access to the project except engineer

        if (installment.getId() != null)
            return ResponseEntity.badRequest().build();

        Optional<Trade> optTrade = tradeRepository.findById(id);
        if (optTrade.isPresent()) {
            Trade trade = optTrade.get();

            installment.setTrade(trade);

            Installment result = installmentRepo.save(installment);

            // TODO notify owning CS about new entry
            String message = "Шинэ төлбөр төлөлт нэмэгдлээ.";
            sendNotification(trade, message);

            return ResponseEntity.ok(result);
        }

        return ResponseEntity.badRequest().build();
    }

    private void sendNotification(Trade trade, String message) {
        Long facilityId = trade.getFacility().getId();
        Project project = projectRepo.findByBuildingsFacilitiesId(facilityId);

        // TODO filter userId CS role khaan bank api connected
        projectResource.sendNotification(project, message);
    }

    @GetMapping("/trades/{id}/installments")
    public ResponseEntity<List<Installment>> getTradeInstallments(@PathVariable Long id, Pageable pageable,
            UriComponentsBuilder uriBuilder) {

        Page<Installment> page = installmentRepo.findByTradeId(id, pageable);

        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(uriBuilder, page);

        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }
}

package com.khanbank.cpms.domain.enumeration;

/**
 * The ProjectCostStatus enumeration.
 */
public enum ProjectCostStatus {
    STATUS1, STATUS2
}

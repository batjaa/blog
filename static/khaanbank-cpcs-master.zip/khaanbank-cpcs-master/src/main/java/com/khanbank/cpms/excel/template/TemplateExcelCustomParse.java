package com.khanbank.cpms.excel.template;

import java.io.InputStream;

public class TemplateExcelCustomParse extends TemplateExcelAbstractParse {

    public TemplateExcelCustomParse(InputStream inputStream) {
        super(inputStream, null);
    }

}

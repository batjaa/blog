package com.khanbank.cpms.web.rest;

import java.net.URISyntaxException;
import java.util.Optional;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.khanbank.cpms.domain.Compliance;
import com.khanbank.cpms.repository.ComplianceRepository;
import com.khanbank.cpms.service.util.HelperUtil;

import io.github.jhipster.web.util.HeaderUtil;
import io.github.jhipster.web.util.ResponseUtil;

/**
 * REST controller for managing {@link com.khanbank.cpms.domain.Compliance}.
 */
@RestController
@RequestMapping("/api")
public class ComplianceResource {

    private final Logger log = LoggerFactory.getLogger(ComplianceResource.class);

    private static final String ENTITY_NAME = "compliance";

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final ComplianceRepository complianceRepository;

    public ComplianceResource(ComplianceRepository complianceRepository) {
        this.complianceRepository = complianceRepository;
    }

    /**
     * {@code PUT  /compliances} : Updates an existing compliance.
     *
     * @param compliance
     *            the compliance to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated compliance, or with status {@code 400 (Bad Request)} if the compliance is not valid, or with status
     *         {@code 500 (Internal Server Error)} if the compliance couldn't be updated.
     * @throws URISyntaxException
     *             if the Location URI syntax is incorrect.
     */
    @PutMapping("/compliances")
    public ResponseEntity<Compliance> updateCompliance(@Valid @RequestBody Compliance compliance)
            throws URISyntaxException {
        log.debug("REST request to update Compliance : {}", compliance);

        Optional<Compliance> optOldCompliance = complianceRepository.findById(compliance.getId());

        boolean updateEntity = HelperUtil.updateObjectRequiredFields(optOldCompliance, compliance, "project");

        if (!updateEntity)
            return ResponseEntity.badRequest().build();

        Compliance result = complianceRepository.save(compliance);

        return ResponseEntity.ok().headers(
                HeaderUtil.createEntityUpdateAlert(applicationName, true, ENTITY_NAME, compliance.getId().toString()))
                .body(result);
    }

    /**
     * {@code GET  /compliances/:id} : get the "id" compliance.
     *
     * @param id
     *            the id of the compliance to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the compliance, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/compliances/{id}")
    public ResponseEntity<Compliance> getCompliance(@PathVariable Long id) {
        log.debug("REST request to get Compliance : {}", id);
        Optional<Compliance> compliance = complianceRepository.findById(id);
        return ResponseUtil.wrapOrNotFound(compliance);
    }

    /**
     * {@code DELETE  /compliances/:id} : delete the "id" compliance.
     *
     * @param id
     *            the id of the compliance to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/compliances/{id}")
    public ResponseEntity<Void> deleteCompliance(@PathVariable Long id) {
        log.debug("REST request to delete Compliance : {}", id);
        complianceRepository.deleteById(id);
        return ResponseEntity.noContent()
                .headers(HeaderUtil.createEntityDeletionAlert(applicationName, true, ENTITY_NAME, id.toString()))
                .build();
    }
}

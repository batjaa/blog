package com.khanbank.cpms.service;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RequestCallback;
import org.springframework.web.client.ResponseExtractor;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.khanbank.cpms.domain.Authority;
import com.khanbank.cpms.service.dto.AppUser;
import com.khanbank.cpms.service.dto.LoggedInUser;
import com.khanbank.cpms.service.dto.UserDTO;
import com.khanbank.cpms.service.param.JsonNodeParam;
import com.khanbank.cpms.service.util.JsonUtil;

@Service
public class KhaanBankServiceImpl implements KhaanBankService {

    private final Logger logger = LoggerFactory.getLogger(KhaanBankServiceImpl.class);

    private static final String KHAAN_BANK_API_AUTH = "https://doob.world:6442/v1/auth/token";

    private static final String KHAAN_BANK_API_USERS = "https://doob.world:6442/v1/identity/users/";

    private static final String API_USERNAME_DEFAULT = "IfKgywFNhPmrCA57Afheka8jquqVRgN6";
    private static final String API_PASSWORD_DEFAULT = "HTGvIKVR5zicRbGi";

    @Autowired
    private RestTemplate restTemplate;

    @Override
    public String refreshAccessToken(AppUser appUser) {

        String refreshAccessToken = getTestAccessToken();

        if (refreshAccessToken == null) {
            logger.debug("refresh accessToken bad request");
            return null;
        }

        appUser.setRefreshAccessToken(refreshAccessToken);

        return refreshAccessToken;
    }

    /** TEST user accessToken */
    private String getTestAccessToken() {
        return getAccessToken(API_USERNAME_DEFAULT, API_PASSWORD_DEFAULT);
    }

    private String getAccessToken(String username, String password) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        headers.setBasicAuth(username, password, StandardCharsets.UTF_8);

        String uriParams = "?grant_type=client_credentials&username=" + username + "&password=" + password;

        String apiUrlAuth = KHAAN_BANK_API_AUTH + uriParams;

        HttpEntity<String> request = new HttpEntity<>(headers);

        try {
            ResponseEntity<JsonNode> postResponse = restTemplate.postForEntity(apiUrlAuth, request, JsonNode.class);

            if (postResponse.getStatusCode().equals(HttpStatus.OK)) {
                JsonNode jsonNode = postResponse.getBody().get("access_token");

                if (jsonNode == null || jsonNode.isNull())
                    throw new RestClientException("Bad Credentials.");

                String accessToken = jsonNode.asText();

                return accessToken;
            }
        } catch (Exception xe) {
            logger.error(xe.getMessage());
        }

        return null;
    }

    @Override
    public UsernamePasswordAuthenticationToken authenticationUser(String username, String password) {
        String accessToken = getTestAccessToken();

        if (accessToken == null) {
            logger.debug("username and password bad request !!!");
            return new UsernamePasswordAuthenticationToken(null, null);
        }

        // Demo Authority
        Set<Authority> authorities = new HashSet<>();
        Authority authority = new Authority();
        authority.setName(username.toUpperCase());
        authorities.add(authority);

        LoggedInUser loggedInUser = new LoggedInUser(username, password, authorities);
        loggedInUser.setAccessToken(accessToken);

        return new UsernamePasswordAuthenticationToken(loggedInUser, password, authorities);

    }

    private <T> ResponseEntity<T> getKhaanBankUsers(String accessToken, String uriParams, Class<T> responseType) {

        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(accessToken);
        HttpEntity<String> request = new HttpEntity<>(headers);

        if (uriParams == null)
            uriParams = "";

        String apiUrlAuth = KHAAN_BANK_API_USERS + uriParams;

        try {
            RequestCallback httpEntityCallback = restTemplate.httpEntityCallback(request, responseType);

            ResponseExtractor<ResponseEntity<T>> responseExtractor = restTemplate.responseEntityExtractor(responseType);

            ResponseEntity<T> response = restTemplate.execute(apiUrlAuth, HttpMethod.GET, httpEntityCallback,
                    responseExtractor);

            return response;
        } catch (Exception ex) {
            logger.error(ex.getMessage());
        }

        return ResponseEntity.badRequest().build();
    }

    @Override
    public List<UserDTO> getUsers(String accessToken) {

        String uriParams = "5038/branch";

        ResponseEntity<ArrayNode> response = getKhaanBankUsers(accessToken, uriParams, ArrayNode.class);

        if (response.getStatusCode().equals(HttpStatus.OK)) {
            try {
                ArrayNode objectNodes = response.getBody();
                List<JsonNodeParam> datas = new ArrayList<>();

                objectNodes.forEach(objectNode -> datas.add(new JsonNodeParam(objectNode, UserDTO.class)));

                List<Object> khaanBankUsers = JsonUtil.parseMapperJsonNodesToObjects(datas);

                List<UserDTO> resultUsers = khaanBankUsers.stream().map(UserDTO.class::cast)
                        .filter(u -> u.isActivated() && (u.getClaims() == null || u.getClaims().getTitle() == null
                                || !u.getClaims().getTitle().matches("^.+(З|з)ахирал.+$|(З|з)ахирал.+$")))
                        .collect(Collectors.toList());

                return resultUsers;

            } catch (Exception e) {
                logger.error(e.getMessage());
            }
        }

        return new ArrayList<>();

    }

    @Override
    public Optional<UserDTO> getUser(String accessToken, String userId) {
        UserDTO result = null;
        
        ResponseEntity<JsonNode> response = getKhaanBankUsers(accessToken, userId, JsonNode.class);

        if (response.getStatusCode().equals(HttpStatus.OK)) {
            try {
                JsonNode objectNode = response.getBody();

                JsonNodeParam nodeParam = new JsonNodeParam(objectNode, UserDTO.class);

                result = (UserDTO) JsonUtil.parseMapperJsonNodeToObject(nodeParam);

            } catch (Exception e) {
                logger.error(e.getMessage());
            }
        }

        return Optional.ofNullable(result);
    }

}

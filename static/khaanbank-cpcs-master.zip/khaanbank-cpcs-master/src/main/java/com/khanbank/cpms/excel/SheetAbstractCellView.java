package com.khanbank.cpms.excel;

import com.khanbank.cpms.excel.template.TemplateField;

public abstract class SheetAbstractCellView implements SheetCellView {

    public enum SheetReadType {
        COL, ROW
    }

    private String key;
    private TemplateField template;
    private SheetReadType readType;

    public SheetAbstractCellView(String key, SheetReadType readType) {
        this.key = key;
        this.readType = readType;
    }

    public void setKey(String key) {
        this.key = key;
    }

    @Override
    public String getKey() {
        return key;
    }

    public void setTemplate(TemplateField template) {
        this.template = template;
    }

    @Override
    public TemplateField getTemplate() {
        return template;
    }

    @Override
    public SheetReadType getReadType() {
        return readType;
    }

    public void setReadType(SheetReadType readType) {
        this.readType = readType;
    }

    @Override
    public boolean anyMatchType(SheetReadType readType) {
        return this.readType != null && readType != null && this.readType.equals(readType);
    }

    @Override
    public boolean anyMatchKey(String key) {
        return this.key != null && this.key.matches(key);
    }

}

package com.khanbank.cpms.web.rest;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.khanbank.cpms.security.SecurityUtils;
import com.khanbank.cpms.service.KhaanBankService;
import com.khanbank.cpms.service.dto.AppUser;
import com.khanbank.cpms.service.dto.UserDTO;

import io.github.jhipster.web.util.ResponseUtil;

/**
 * REST controller for managing {@link com.khanbank.cpms.service.dto.UserDTO}.
 */
@RestController
@RequestMapping("/api")
public class UsersResource {
    private final Logger logger = LoggerFactory.getLogger(UsersResource.class);

    @Autowired
    private KhaanBankService khaanBankService;

    @GetMapping("/users")
    public ResponseEntity<List<UserDTO>> getUsers() {
        AppUser appUser = SecurityUtils.getAppUser();

        String accessToken = appUser.getAccessToken();

        List<UserDTO> users = khaanBankService.getUsers(accessToken);

        if (users.isEmpty()) {
            logger.debug(" call two request khaanbank api refresh access token");

            accessToken = khaanBankService.refreshAccessToken(appUser);

            users = khaanBankService.getUsers(accessToken);
        }

        return ResponseEntity.ok().body(users);
    }

    @GetMapping("/users/{id}")
    public ResponseEntity<UserDTO> getUser(@PathVariable String id) {
        AppUser appUser = SecurityUtils.getAppUser();

        String accessToken = appUser.getAccessToken();

        Optional<UserDTO> optUser = khaanBankService.getUser(accessToken, id);

        if (!optUser.isPresent()) {
            logger.debug(" call two request khaanbank api ");

            accessToken = khaanBankService.refreshAccessToken(appUser);

            optUser = khaanBankService.getUser(accessToken, id);
        }

        return ResponseUtil.wrapOrNotFound(optUser);
    }
}

package com.khanbank.cpms.domain.enumeration;

/**
 * The ProjectStatus enumeration.
 */
public enum ProjectStatus {
    IN_PROGRESS, FINISHED, CANCELLED
}

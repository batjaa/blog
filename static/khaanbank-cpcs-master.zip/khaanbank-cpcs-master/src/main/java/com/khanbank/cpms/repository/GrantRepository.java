package com.khanbank.cpms.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.khanbank.cpms.domain.Grant;

/**
 * Spring Data repository for the Grant entity.
 */
@Repository
public interface GrantRepository extends JpaRepository<Grant, Long> {

	Page<Grant> findByProjectId(Long id, Pageable pageable);

	Long countByProjectId(Long id);
}
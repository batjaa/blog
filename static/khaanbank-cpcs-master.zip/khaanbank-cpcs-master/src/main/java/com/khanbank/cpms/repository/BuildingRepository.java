package com.khanbank.cpms.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.khanbank.cpms.domain.Building;

/**
 * Spring Data repository for the Building entity.
 */
@Repository
public interface BuildingRepository extends JpaRepository<Building, Long> {

	Page<Building> findByProjectId(Long projectId, Pageable pageable);

}

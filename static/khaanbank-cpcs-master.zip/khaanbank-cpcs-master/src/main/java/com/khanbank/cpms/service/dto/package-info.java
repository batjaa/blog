/**
 * Data Transfer Objects.
 */
package com.khanbank.cpms.service.dto;

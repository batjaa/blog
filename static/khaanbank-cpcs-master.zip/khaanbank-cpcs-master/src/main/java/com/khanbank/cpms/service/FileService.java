package com.khanbank.cpms.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.persistence.Entity;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.khanbank.cpms.config.Constants;
import com.khanbank.cpms.excel.ExcelSheetParser;
import com.khanbank.cpms.excel.SheetCellView;
import com.khanbank.cpms.excel.SheetData;
import com.khanbank.cpms.excel.exception.TemplateException;
import com.khanbank.cpms.excel.template.TemplateExcelAbstractParse;
import com.khanbank.cpms.excel.template.TemplateExcelCustomParse;
import com.khanbank.cpms.excel.template.TemplateExcelEntityParse;
import com.khanbank.cpms.service.mapper.ExcelSheetToImage;
import com.khanbank.cpms.service.param.JsonNodeParam;
import com.khanbank.cpms.service.util.FileUtil;
import com.khanbank.cpms.service.util.JsonUtil;
import com.khanbank.cpms.service.util.ReflectionUtil;

@Service
public class FileService implements StorageService {

    @Value("${app.upload-director}")
    private String uploadDirector = "";

    @Value("${app.python-director}")
    private String pythonDirector = "";

    private final Logger logger = LoggerFactory.getLogger(FileService.class);

    @Override
    public void init() {

    }

    @Override
    public File store(MultipartFile uploadFile) {
        // TODO Implement file storage
        return createFile(uploadFile);
    }

    public File createFile(MultipartFile uploadFile) {

        if (uploadFile == null)
            return null;

        String fileName = FileUtil.createTempFilename(uploadFile.getOriginalFilename());
        String subFolder = new SimpleDateFormat(Constants.FOLDER_DATE_FORMAT).format(Date.from(Instant.now()));
        String destPath = uploadDirector + subFolder;
        File destFolder = new File(destPath);
        destFolder.mkdirs();
        try {

            File destFile = new File(destFolder.getAbsolutePath() + "/" + fileName);

            uploadFile.transferTo(destFile);
            return destFile;
        } catch (Exception e) {
            logger.error(e.getMessage());
            return null;
        }
    }

    @Override
    public <T> Set<T> loadParserSheetDatas(com.khanbank.cpms.domain.File file, Class<T> entityClass) throws Exception {

        ExcelSheetParser excelParser = buildExcelFileMapper(file, entityClass);

        List<SheetData> sheetDatas = excelParser.getSheetDatas();

        sheetDatas.forEach(sheetData -> sheetData.getErrorMessages().forEach(logger::error));

        List<JsonNodeParam> jsonNodeParams = JsonUtil.parseMapperJsonNodes(sheetDatas);

        List<Object> parseObjects = JsonUtil.parseMapperJsonNodesToObjects(jsonNodeParams);

        Set<T> result = parseObjects.stream().map(entityClass::cast).collect(Collectors.toSet());

        return result;
    }

    @SuppressWarnings("unchecked")
    @Override
    public <T> T loadParserSheetData(com.khanbank.cpms.domain.File file, Class<T> entityClass) throws Exception {

        ExcelSheetParser excelParser = buildExcelFileMapper(file, entityClass);

        SheetData firstSheetData = excelParser.getFirstSheetData();

        JsonNodeParam jsonNodeParam = JsonUtil.parseMapperJsonNode(firstSheetData);

        T result = (T) JsonUtil.parseMapperJsonNodeToObject(jsonNodeParam);

        return result;
    }

    private InputStream getFileToInputStream(com.khanbank.cpms.domain.File file) throws FileNotFoundException {
        String absolutePath = file.getPath();

        InputStream inputStream = new FileInputStream(new File(absolutePath));
        return inputStream;
    }

    private ExcelSheetParser buildExcelFileMapper(com.khanbank.cpms.domain.File file, Class<?> entityClass)
            throws Exception {

        InputStream inputStream = getFileToInputStream(file);

        TemplateExcelEntityParse entityTemplate = new TemplateExcelEntityParse(inputStream, false, entityClass);

        if (!entityClass.isAnnotationPresent(Entity.class))
            throw new TemplateException("Таны өгсөн class Entity anno байхгүй байна !!!");

        List<SheetCellView> sheetCellViews = ReflectionUtil.getSheetCellViews(entityClass);

        entityTemplate.setSheetCellViews(sheetCellViews);

        ExcelSheetParser excelParser = buildExcelParse(entityTemplate);

        return excelParser;
    }

    private ExcelSheetParser buildExcelParse(TemplateExcelAbstractParse template) throws Exception {
        logger.debug("\"****** --- Орж ирсэн еxcel file parse хийх : `{}` --- ******\"");

        ExcelSheetParser excelParser = new ExcelSheetParser(template);

        if (excelParser.isEmptySheetDatas())
            throw new Exception(" Алдаатай excel file байна");

        logger.debug("\"****** --- Орж ирсэн еxcel file задлаж дуусан. --- ******\"");
        return excelParser;
    }

    @Override
    public SheetData customParserSheetData(com.khanbank.cpms.domain.File file, Class<?>... classes) throws Exception {
        List<SheetCellView> sheetCellViews = new ArrayList<>();

        for (Class<?> entityClass : classes) {
            sheetCellViews.addAll(ReflectionUtil.getSheetCellViews(entityClass));
        }

        InputStream inputStream = getFileToInputStream(file);

        TemplateExcelCustomParse template = new TemplateExcelCustomParse(inputStream);
        template.setSheetCellViews(sheetCellViews);

        ExcelSheetParser excelParser = buildExcelParse(template);

        SheetData firstSheetData = excelParser.getFirstSheetData();

        return firstSheetData;
    }

    @Override
    public String generateSheetToImage(com.khanbank.cpms.domain.File file, String sheetName, String fromCell,
            String toCell) {

        String inputXlsxFilePath = file.getPath();

        String outputFilePath = FileUtil.changeFileExtension(inputXlsxFilePath, "png");

        try {

            ExcelSheetToImage sheetToImage = new ExcelSheetToImage(pythonDirector);
            sheetToImage.convert(inputXlsxFilePath, sheetName, fromCell, toCell, outputFilePath);
            logger.debug("excel sheet to image {} saving ", outputFilePath);

        } catch (Exception e) {
            logger.error(e.getMessage());
            outputFilePath = null;
        }

        return outputFilePath;
    }

}

package com.khanbank.cpms.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.khanbank.cpms.domain.Facility;
import com.khanbank.cpms.service.dto.FacilityReport;

/**
 * Spring Data repository for the Facility entity.
 */
@Repository
public interface FacilityRepository extends BaseSpecRespository<Facility, Long> {

    Page<Facility> findByBuildingProjectId(Long id, Pageable pageable);

    @Query("SELECT new com.khanbank.cpms.service.dto.FacilityReport(f.type, t.status, SUM(f.area), SUM(f.area * t.pricePerUnit), SUM(s.amount)) "
            + "FROM Facility f " + "INNER JOIN f.trade t " + "LEFT JOIN t.installments s "
            + "GROUP BY f.type, t.status")
    Page<FacilityReport> fetchFacilityDataInnerJoin(Pageable pageable);

}

package com.khanbank.cpms.repository;

import java.time.Instant;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.khanbank.cpms.domain.Compliance;

/**
 * Spring Data repository for the Compliance entity.
 */
@Repository
public interface ComplianceRepository extends JpaRepository<Compliance, Long> {

	Page<Compliance> findByProjectId(Long id, Pageable pageable);

	List<Compliance> findByDueDateBefore(Instant date);

}

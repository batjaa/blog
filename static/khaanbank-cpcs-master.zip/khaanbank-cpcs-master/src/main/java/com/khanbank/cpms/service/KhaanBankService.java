package com.khanbank.cpms.service;

import java.util.List;
import java.util.Optional;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;

import com.khanbank.cpms.service.dto.AppUser;
import com.khanbank.cpms.service.dto.UserDTO;

public interface KhaanBankService {

    String refreshAccessToken(AppUser appUser);

    UsernamePasswordAuthenticationToken authenticationUser(String username, String password);
    
    List<UserDTO> getUsers(String accessToken);
    
    Optional<UserDTO> getUser(String accessToken, String userId);

}

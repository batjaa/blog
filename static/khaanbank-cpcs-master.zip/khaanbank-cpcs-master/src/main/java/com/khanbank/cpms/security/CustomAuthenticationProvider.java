package com.khanbank.cpms.security;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.stereotype.Component;

import com.khanbank.cpms.service.KhaanBankService;

@Component
public class CustomAuthenticationProvider implements AuthenticationProvider {

    private final Logger logger = LoggerFactory.getLogger(CustomAuthenticationProvider.class);

    @Autowired
    private KhaanBankService restService;

    public CustomAuthenticationProvider() {
        super();
    }

    // API
    @Override
    public Authentication authenticate(final Authentication authentication) throws AuthenticationException {
        String username = authentication.getName();
        Object credentials = authentication.getCredentials();

        if (credentials == null || username == null || credentials.toString().isEmpty() || username.isEmpty()) {
            logger.debug(" username and password is null or empty !!!");
            return new UsernamePasswordAuthenticationToken(null, null);
        }

        String password = credentials.toString();

        return restService.authenticationUser(username, password);
    }

    @Override
    public boolean supports(final Class<?> authentication) {
        return authentication.equals(UsernamePasswordAuthenticationToken.class);
    }

}

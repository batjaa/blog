package com.khanbank.cpms.excel.template;

import java.util.ArrayList;
import java.util.List;

public class GroupTemplate extends TemplateField {

	private List<TemplateField> childTemplate;

	public GroupTemplate(TemplateField field) {
		super(field);
		setType(null);
		setValue(null);
		setDisplayName("Цуглуулагч");
		setFieldName(this.getGroupFieldName());
		setGroupFieldName(null);
	}

	public void addGroupTemplate(GroupTemplate groupField) {
		if (childTemplate == null)
			childTemplate = new ArrayList<>();

		childTemplate.add(groupField);
	}

	public void addTemplate(TemplateField docField) {

		if (childTemplate == null)
			childTemplate = new ArrayList<>();

		if (hasDocField(docField))
			return;

		Class<?> contentClass = docField.getContentClass();

		if (docField.hasGroupFieldName() && contentClass.equals(getContentClass()) && docField.isCollection())
			docField.setCollection(false);

		childTemplate.add(docField);
	}

	public void removeTemplate(TemplateField docField) {

		if (childTemplate == null)
			return;

		if (!hasDocField(docField))
			return;

		childTemplate.remove(docField);
	}

	private boolean hasDocField(TemplateField docField) {
		return childTemplate.stream().anyMatch(d -> d.getDisplayName().matches(docField.getDisplayName()) || d.equals(docField));
	}

	public List<TemplateField> getChildTemplate() {
		return childTemplate;
	}

	public void setChildTemplate(List<TemplateField> childDocFields) {
		this.childTemplate = childDocFields;
	}

	public boolean hasFieldNameDocField(String fieldName) {

		if (childTemplate == null)
			return false;

		return childTemplate.stream().anyMatch(f -> f.getFieldName().matches(fieldName));
	}

}

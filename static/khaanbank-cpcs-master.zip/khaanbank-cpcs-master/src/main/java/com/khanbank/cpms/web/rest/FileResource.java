package com.khanbank.cpms.web.rest;

import java.net.URI;
import java.net.URISyntaxException;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.Optional;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.khanbank.cpms.domain.File;
import com.khanbank.cpms.repository.FileRepository;
import com.khanbank.cpms.service.FileService;

import io.github.jhipster.web.util.HeaderUtil;
import io.github.jhipster.web.util.ResponseUtil;

/**
 * REST controller for managing {@link com.khanbank.cpms.domain.File}.
 */
@RestController
@RequestMapping("/api")
public class FileResource {

    private final Logger log = LoggerFactory.getLogger(FileResource.class);

    @Value("${app.upload-director}")
    private String uploadDirector = "";

    private static final String ENTITY_NAME = "file";

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final FileRepository fileRepository;

    @Autowired
    private FileService fileService;

    public FileResource(FileRepository fileRepository) {
        this.fileRepository = fileRepository;
    }

    @GetMapping("/files/{id}/download")
    public ResponseEntity<byte[]> downloadFile(@PathVariable Long id) throws URISyntaxException {

        Optional<File> optFile = fileRepository.findById(id);

        if (optFile.isPresent()) {
            File file = optFile.get();
            String fullPath = file.getPath();

            try {
                java.io.File javaFile = new java.io.File(fullPath);

                // get the mimetype
                String mimeType = URLConnection.guessContentTypeFromName(file.getName());

                if (mimeType == null) {
                    // unknown mimetype so set the mimetype to application/octet-stream
                    mimeType = "application/octet-stream";
                }

                byte[] fileByte = FileCopyUtils.copyToByteArray(javaFile);

                HttpHeaders header = new HttpHeaders();
                header.setContentType(MediaType.parseMediaType(mimeType));
                header.setContentLength(fileByte.length);

                String encodeName = URLEncoder.encode(file.getName(), "UTF-8");

                // attachment; inline;
                String contentDisposition = "inline; filename=" + encodeName;
                header.setContentDisposition(ContentDisposition.parse(contentDisposition));

                return ResponseEntity.ok().headers(header).body(fileByte);

            } catch (Exception e) {
                log.error(e.getMessage());
            }

        }

        return ResponseEntity.badRequest().build();
    }

    /**
     * {@code POST  /files} : Create a new file.
     *
     * @param file
     *            the file to create.
     * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new file, or with status {@code 400 (Bad Request)} if the file has already an ID.
     * @throws URISyntaxException
     *             if the Location URI syntax is incorrect.
     */
    @PostMapping(value = "/files", consumes = "multipart/form-data")
    public ResponseEntity<File> createFile(@Valid @RequestBody MultipartFile file) throws URISyntaxException {
        log.debug("REST request to save File : {}", file);

        java.io.File storedFile = this.fileService.store(file);

        if (storedFile == null) {
            log.error("file хадгалалт амжилтгүй болсон алдаатай file байна.");
            return ResponseEntity.badRequest().build();
        }

        String fileName = file.getOriginalFilename();
        String absolutePath = storedFile.getAbsolutePath();

        File result = new File().name(fileName).path(absolutePath);

        fileRepository.save(result);

        return ResponseEntity
                .created(new URI("/api/files/" + result.getId())).headers(HeaderUtil
                        .createEntityCreationAlert(applicationName, true, ENTITY_NAME, result.getId().toString()))
                .body(result);
    }

    /**
     * {@code GET  /files/:id} : get the "id" file.
     *
     * @param id
     *            the id of the file to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the file, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/files/{id}")
    public ResponseEntity<File> getFile(@PathVariable Long id) {
        log.debug("REST request to get File : {}", id);
        Optional<File> file = fileRepository.findById(id);
        return ResponseUtil.wrapOrNotFound(file);
    }

    /**
     * {@code DELETE  /files/:id} : delete the "id" file.
     *
     * @param id
     *            the id of the file to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/files/{id}")
    public ResponseEntity<Void> deleteFile(@PathVariable Long id) {
        log.debug("REST request to delete File : {}", id);
        fileRepository.deleteById(id);
        return ResponseEntity.noContent()
                .headers(HeaderUtil.createEntityDeletionAlert(applicationName, false, ENTITY_NAME, id.toString()))
                .build();
    }

}

package com.khanbank.cpms.service.dto;

import com.khanbank.cpms.domain.enumeration.FacilityStatus;
import com.khanbank.cpms.domain.enumeration.FacilityType;

public class FacilityReport {

    private FacilityType type;

    private FacilityStatus status;

    private Long area;

    private Long totalPrice;

    private Long installmentAmount;

    public FacilityReport(FacilityType type, FacilityStatus status, Double area, Double totalPrice,
            Double installmentAmount) {
        this.type = type;
        this.status = status;
        this.area = area.longValue();
        this.totalPrice = totalPrice == null ? 0l : totalPrice.longValue();
        this.installmentAmount = installmentAmount == null ? 0l : installmentAmount.longValue();
    }

    public FacilityType getType() {
        return type;
    }

    public void setType(FacilityType type) {
        this.type = type;
    }

    public FacilityStatus getStatus() {
        return status;
    }

    public void setStatus(FacilityStatus status) {
        this.status = status;
    }

    public Long getArea() {
        return area;
    }

    public void setArea(Long area) {
        this.area = area;
    }

    public Long getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(Long totalPrice) {
        this.totalPrice = totalPrice;
    }

    public Long getInstallmentAmount() {
        return installmentAmount;
    }

    public void setInstallmentAmount(Long installmentAmount) {
        this.installmentAmount = installmentAmount;
    }

}

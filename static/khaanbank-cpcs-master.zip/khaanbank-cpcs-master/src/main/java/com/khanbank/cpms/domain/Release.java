package com.khanbank.cpms.domain;

import java.time.Instant;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.khanbank.cpms.domain.enumeration.ReleaseStatus;

/**
 * A Release.
 */
@Entity
@Table(name = "jhi_release")
public class Release extends AbstractAuditingEntity {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "released_date")
    private Instant releasedDate;

    @Column(name = "notes")
    private String notes;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false)
    private ReleaseStatus status;

    @Column(name = "release_number")
    private Long releaseNumber;

    @LastModifiedBy
    @Column(name = "updated_by", nullable = false)
    private String updatedBy;

    @LastModifiedDate
    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;

    @CreatedDate
    @Column(name = "created_at", nullable = false)
    private Instant createdAt;

    @OneToOne(mappedBy = "release")
    @JsonIgnore
    private Facility facility;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Instant getReleasedDate() {
        return releasedDate;
    }

    public Release releasedDate(Instant releasedDate) {
        this.releasedDate = releasedDate;
        return this;
    }

    public void setReleasedDate(Instant releasedDate) {
        this.releasedDate = releasedDate;
    }

    public String getNotes() {
        return notes;
    }

    public Release notes(String notes) {
        this.notes = notes;
        return this;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public ReleaseStatus getStatus() {
        return status;
    }

    public Release status(ReleaseStatus status) {
        this.status = status;
        return this;
    }

    public void setStatus(ReleaseStatus status) {
        this.status = status;
    }

    public Long getReleaseNumber() {
        return releaseNumber;
    }

    public Release releaseNumber(Long releaseNumber) {
        this.releaseNumber = releaseNumber;
        return this;
    }

    public void setReleaseNumber(Long releaseNumber) {
        this.releaseNumber = releaseNumber;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public Release updatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
        return this;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Instant getUpdatedAt() {
        return updatedAt;
    }

    public Release updatedAt(Instant updatedAt) {
        this.updatedAt = updatedAt;
        return this;
    }

    public void setUpdatedAt(Instant updatedAt) {
        this.updatedAt = updatedAt;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public Release createdAt(Instant createdAt) {
        this.createdAt = createdAt;
        return this;
    }

    public void setCreatedAt(Instant createdAt) {
        this.createdAt = createdAt;
    }

    public Facility getFacility() {
        return facility;
    }

    public Release facility(Facility facility) {
        this.facility = facility;
        return this;
    }

    public void setFacility(Facility facility) {
        this.facility = facility;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Release)) {
            return false;
        }
        return id != null && id.equals(((Release) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return "Release{" + "id=" + getId() + ", releasedDate='" + getReleasedDate() + "'" + ", notes='" + getNotes()
                + "'" + ", status='" + getStatus() + "'" + ", releaseNumber=" + getReleaseNumber() + ", updatedBy='"
                + getUpdatedBy() + "'" + ", updatedAt='" + getUpdatedAt() + "'" + ", createdAt='" + getCreatedAt() + "'"
                + "}";
    }
}

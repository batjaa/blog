package com.khanbank.cpms.web.rest;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;
import org.zalando.problem.Status;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.khanbank.cpms.domain.Building;
import com.khanbank.cpms.domain.Company;
import com.khanbank.cpms.domain.Compliance;
import com.khanbank.cpms.domain.EngineerAssessment;
import com.khanbank.cpms.domain.Facility;
import com.khanbank.cpms.domain.File;
import com.khanbank.cpms.domain.Grant;
import com.khanbank.cpms.domain.Project;
import com.khanbank.cpms.domain.ProjectCostEstimate;
import com.khanbank.cpms.domain.ProjectCostEstimateSubmission;
import com.khanbank.cpms.domain.enumeration.ProjectCostEstimateSubmissionStatus;
import com.khanbank.cpms.repository.BuildingRepository;
import com.khanbank.cpms.repository.ComplianceRepository;
import com.khanbank.cpms.repository.EngineerAssessmentRepository;
import com.khanbank.cpms.repository.FacilityRepository;
import com.khanbank.cpms.repository.FileRepository;
import com.khanbank.cpms.repository.GrantRepository;
import com.khanbank.cpms.repository.ProjectCostEstimateRepository;
import com.khanbank.cpms.repository.ProjectCostEstimateSubmissionRepository;
import com.khanbank.cpms.repository.ProjectRepository;
import com.khanbank.cpms.security.AccessExpressions;
import com.khanbank.cpms.service.NotificationService;
import com.khanbank.cpms.service.StorageService;
import com.khanbank.cpms.service.util.HelperUtil;
import com.khanbank.cpms.service.util.JsonUtil;
import com.khanbank.cpms.service.util.ReflectionUtil;
import com.khanbank.cpms.web.rest.errors.BadRequestAlertException;
import com.khanbank.cpms.web.rest.errors.BadRequestException;
import com.khanbank.cpms.web.rest.errors.ErrorResponseCodes;
import com.khanbank.cpms.web.rest.spec.InstantGreaterThanOrEqual;
import com.khanbank.cpms.web.rest.spec.InstantLessThanOrEqual;

import io.github.jhipster.web.util.HeaderUtil;
import io.github.jhipster.web.util.PaginationUtil;
import io.github.jhipster.web.util.ResponseUtil;
import net.kaczmarzyk.spring.data.jpa.domain.Equal;
import net.kaczmarzyk.spring.data.jpa.domain.GreaterThanOrEqual;
import net.kaczmarzyk.spring.data.jpa.domain.LessThanOrEqual;
import net.kaczmarzyk.spring.data.jpa.domain.Like;
import net.kaczmarzyk.spring.data.jpa.web.annotation.Conjunction;
import net.kaczmarzyk.spring.data.jpa.web.annotation.Or;
import net.kaczmarzyk.spring.data.jpa.web.annotation.Spec;

/**
 * REST controller for managing {@link com.khanbank.cpms.domain.Project}.
 */
@RestController
@RequestMapping("/api")
public class ProjectResource {

    private final Logger log = LoggerFactory.getLogger(ProjectResource.class);

    private static final String ENTITY_NAME = "project";
    private static final String PROJECT_FILE_ID = "projectFileId";
    private static final String INITIAL_COST_ESTIMATE_FILE_ID = "initialCostEstimateFileId";
    private static final String GRANT_FILE_IDS = "fileIds";
    private static final String ENGINEERASSESSMENT_FILE_ID = "fileIds";

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final ProjectRepository projectRepo;

    @Autowired
    private EngineerAssessmentRepository engineerAssessmentRepo;

    @Autowired
    private FacilityRepository facilityRepo;

    @Autowired
    private ProjectCostEstimateRepository costEstimateRepo;

    @Autowired
    private GrantRepository grantRepo;

    @Autowired
    private ComplianceRepository complianceRepo;

    @Autowired
    private ProjectCostEstimateSubmissionRepository costEstimateSubmissionRepo;

    @Autowired
    private StorageService storageService;

    @Autowired
    private NotificationService notifyService;

    @Autowired
    private FileRepository fileRepo;

    @Autowired
    private BuildingRepository buildingRepo;

    public ProjectResource(ProjectRepository projectRepository) {
        this.projectRepo = projectRepository;
    }

    @PostMapping("/projects")
    public ResponseEntity<Project> createProject(@Valid @RequestBody ObjectNode content) throws URISyntaxException {
        JsonNode jsProjectFileId = content.get(PROJECT_FILE_ID);

        if (jsProjectFileId == null) {
            throw new BadRequestAlertException(" Facility excel file no found ", ENTITY_NAME, "idexists");
        }

        JsonNode jsIntialCostEstimateFileId = content.get(INITIAL_COST_ESTIMATE_FILE_ID);

        Project project = JsonUtil.parseObjectNodeToObject(content, Project.class, PROJECT_FILE_ID,
                INITIAL_COST_ESTIMATE_FILE_ID);

        log.debug("REST request to save Project : {}", project);

        if (project.getId() != null) {
            throw new BadRequestAlertException("A new project cannot already have an ID", ENTITY_NAME, "idexists");
        }

        long projectFileId = jsProjectFileId.longValue();

        try {
            File projectFile = fileRepo.findById(projectFileId).get();

            Set<Building> buildings = storageService.loadParserSheetDatas(projectFile, Building.class);

            for (Building building : buildings)
                HelperUtil.setCreateMapObjectValues(building, project, false);

            project.setBuildings(buildings);

        } catch (Exception e) {
            log.error(e.getMessage());
            throw new BadRequestAlertException("Facility excel file failing parse", ENTITY_NAME, "idexists");
        }

        ProjectCostEstimate costEstimate = new ProjectCostEstimate();
        costEstimate.setProject(project);
        project.setProjectCostEstimate(costEstimate);

        if (jsIntialCostEstimateFileId != null) {

            long intialCostEstimateFileId = jsIntialCostEstimateFileId.longValue();

            Optional<File> optIntialCostEstimateFile = fileRepo.findById(intialCostEstimateFileId);

            if (optIntialCostEstimateFile.isPresent()) {
                File intialCostEstimateFile = optIntialCostEstimateFile.get();
                ProjectCostEstimateSubmission estimateSubmission = new ProjectCostEstimateSubmission();
                estimateSubmission.setStatus(ProjectCostEstimateSubmissionStatus.SUBMITTED);
                estimateSubmission.setFile(intialCostEstimateFile);
                costEstimate.addProjectCostEstimateSubmissions(estimateSubmission);
            }
        }

        // Сонгсон company д project ийг нэмж өгөх
        Company company = project.getCompany();

        if (company == null) {
            throw new BadRequestAlertException("Company is not selected", ENTITY_NAME, "idexists");
        }

        company.addProjects(project);

        Project result = projectRepo.saveAndFlush(project);

        return ResponseEntity
                .created(new URI("/api/projects/" + result.getId())).headers(HeaderUtil
                        .createEntityCreationAlert(applicationName, true, ENTITY_NAME, result.getId().toString()))
                .body(result);
    }

    /**
     * {@code PUT  /projects} : Updates an existing project.
     *
     * @param project
     *            the project to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated project, or with status {@code 400 (Bad Request)} if the project is not valid, or with status
     *         {@code 500 (Internal Server Error)} if the project couldn't be updated.
     * @throws URISyntaxException
     *             if the Location URI syntax is incorrect.
     */
    @PutMapping("/projects")
    public ResponseEntity<Project> updateProject(@Valid @RequestBody Project project) throws URISyntaxException {
        log.debug("REST request to update Project : {}", project);
        Optional<Project> optOldProject = projectRepo.findById(project.getId());

        boolean updateEntity = HelperUtil.updateObjectRequiredFields(optOldProject, project);

        if (!updateEntity)
            return ResponseEntity.badRequest().build();

        Project result = projectRepo.saveAndFlush(project);
        return ResponseEntity.ok().headers(
                HeaderUtil.createEntityUpdateAlert(applicationName, true, ENTITY_NAME, project.getId().toString()))
                .body(result);
    }

    /**
     * /** {@code GET  /projects} : get all the projects.
     *
     * @param pageable
     *            the pagination information.
     * @param filter
     *            the filter of the request.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of projects in body.
     */
    @GetMapping("/projects")
    public ResponseEntity<List<Project>> getAllProjects(@Conjunction(value = {
            @Or({
                    @Spec(path = "name", params = "query", spec = Equal.class),
                    @Spec(path = "name", params = "query", spec = Like.class)
            })
    }, and = {
            @Spec(path = "dueDate", params = "dueDate[gte]", spec = InstantGreaterThanOrEqual.class),
            @Spec(path = "dueDate", params = "dueDate[lte]", spec = InstantLessThanOrEqual.class),
            @Spec(path = "loanAmount", params = "loanAmount[gte]", spec = GreaterThanOrEqual.class),
            @Spec(path = "loanAmount", params = "loanAmount[lte]", spec = LessThanOrEqual.class),
            @Spec(path = "status", params = "filter[status]", spec = Equal.class),
            @Spec(path = "company.id", params = "filter[company_id]", spec = Equal.class),
    }) Specification<Project> spec, Pageable pageable, UriComponentsBuilder uriBuilder) {

        log.debug("REST request to get a page of Projects");

        Page<Project> page = projectRepo.findAll(spec, pageable);

        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(uriBuilder, page);
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
     * {@code GET  /projects/:id} : get the "id" project.
     *
     * @param id
     *            the id of the project to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the project, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/projects/{id}")
    public ResponseEntity<Project> getProject(@PathVariable Long id) {
        log.debug("REST request to get Project : {}", id);
        Optional<Project> project = projectRepo.findById(id);
        return ResponseUtil.wrapOrNotFound(project);
    }

    /**
     * {@code DELETE  /projects/:id} : delete the "id" project.
     *
     * @param id
     *            the id of the project to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/projects/{id}")
    public ResponseEntity<Void> deleteProject(@PathVariable Long id) {
        log.debug("REST request to delete Project : {}", id);
        projectRepo.deleteById(id);
        return ResponseEntity.noContent()
                .headers(HeaderUtil.createEntityDeletionAlert(applicationName, true, ENTITY_NAME, id.toString()))
                .build();
    }

    @PostMapping("/projects/{id}/compliances")
    @PreAuthorize(AccessExpressions.PROJECT_ACCESS)
    public ResponseEntity<Compliance> createProjectCompliance(@PathVariable Long id,
            @Valid @RequestBody Compliance compliance) throws URISyntaxException {
        log.debug("POST request to project compliance: {}", id);

        Map<String, Object> errorDetails = ReflectionUtil.findInvalidFields(compliance);
        
        if (!errorDetails.isEmpty()) {
            throw new BadRequestException(Status.BAD_GATEWAY, ErrorResponseCodes.REQUIRED_FIELDS_MISSING,
                    "Шаардлагатай талбарууд хоосон байна.", errorDetails);
        }

        Project project = projectRepo.findById(id).get();

        compliance.setProject(project);

        // TODO authorization
        // Admins, CS, CA

        Compliance result = complianceRepo.saveAndFlush(compliance);

        return ResponseEntity.ok().body(result);
    }

    @GetMapping("/projects/{id}/compliances")
    @PreAuthorize(AccessExpressions.PROJECT_ACCESS)
    public ResponseEntity<List<Compliance>> getProjectCompliances(@PathVariable Long id, Pageable pageable,
            UriComponentsBuilder uriBuilder) throws URISyntaxException {
        log.debug("GET request to project compliances: {}", id);

        // TODO authorization
        // Users only with project_view permission can access the endpoint
        // Admins, business owners can see all projects
        // CS can see all project they own and projects that belongs to sub CAs
        // CAs can see all projects they have created and they belong to
        // Engineers can only see projects they belong to
        // Customers can see all projects that belongs to the company

        Page<Compliance> page = complianceRepo.findByProjectId(id, pageable);

        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(uriBuilder, page);

        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    @GetMapping("/projects/{id}/cost-estimate")
    @PreAuthorize(AccessExpressions.PROJECT_ACCESS)
    public ResponseEntity<ProjectCostEstimate> getProjectCostEstimate(@PathVariable Long id) {
        log.debug("REST request to get ProjectCostEstimate : {}", id);
        return ResponseUtil
                .wrapOrNotFound(costEstimateRepo.findByProjectId(id).map(Optional::of).orElse(Optional.empty()));
    }

    @PostMapping("/projects/{id}/cost-estimate-submissions")
    @PreAuthorize(AccessExpressions.PROJECT_ACCESS)
    public ResponseEntity<ProjectCostEstimateSubmission> createSubmitCostSubmission(@PathVariable Long id,
            @Valid @RequestBody ProjectCostEstimateSubmission estimateSubmission) throws URISyntaxException {
        log.debug("POST request for submitting project cost estimate: {}", id);

        Project project = projectRepo.findById(id).get();

        ProjectCostEstimate costEstimate = project.getProjectCostEstimate();

        if (costEstimate == null)
            throw new BadRequestAlertException("Project ийн Сost estimate үүсгэгүй байна", ENTITY_NAME, "idexists");

        // TODO authorization
        // admins, control specialists and customer associates with access to the project

        Page<ProjectCostEstimateSubmission> page = costEstimateSubmissionRepo
                .findByDeletedAtIsNullAndProjectCostEstimateId(costEstimate.getId(), Pageable.unpaged());

        List<ProjectCostEstimateSubmission> submissions = page.getContent();

        if (submissions.stream().anyMatch(s -> s.getStatus().equals(ProjectCostEstimateSubmissionStatus.SUBMITTED)))
            throw new BadRequestException(Status.FORBIDDEN, ErrorResponseCodes.PROJECT_COST_SUBMIT_NOT_ALLOWED,
                    "Өмнөх төсөвт өртөгт хариу өгөх хүртэл өөр төсөвт өртөг илгээх боломжгүй");

        estimateSubmission.setStatus(ProjectCostEstimateSubmissionStatus.SUBMITTED);

        estimateSubmission.setProjectCostEstimate(costEstimate);

        estimateSubmission = costEstimateSubmissionRepo.saveAndFlush(estimateSubmission);

        // Send the direct project owners a notification
        String message = "Шинэ төсөвт өртөгт үүсгэлээ.";
        sendNotification(project, message);

        return ResponseEntity.ok(estimateSubmission);
    }

    @GetMapping("/projects/{id}/cost-estimate-submissions")
    @PreAuthorize(AccessExpressions.PROJECT_ACCESS)
    public ResponseEntity<List<ProjectCostEstimateSubmission>> getProjectCostEstimateSubmissions(@PathVariable Long id,
            Pageable pageable, UriComponentsBuilder uriBuilder) {
        log.debug("REST request to get ProjectCostEstimate-submisions : {}", id);

        Page<ProjectCostEstimateSubmission> page = costEstimateSubmissionRepo
                .findByDeletedAtIsNullAndProjectCostEstimateProjectId(id, pageable);

        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(uriBuilder, page);

        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    @PostMapping("/projects/{id}/grants")
    @PreAuthorize(AccessExpressions.PROJECT_ACCESS)
    public ResponseEntity<Grant> createGrant(@PathVariable Long id, @Valid @RequestBody ObjectNode content) {

        ArrayNode nodeFileIds = (ArrayNode) content.get(GRANT_FILE_IDS);

        Grant grant = JsonUtil.parseObjectNodeToObject(content, Grant.class, GRANT_FILE_IDS);

        if (grant.getId() != null) {
            throw new BadRequestAlertException("A new grant cannot already have an ID", ENTITY_NAME, "idexists");
        }

        Project project = projectRepo.findById(id).get();

        Set<Long> fileIds = HelperUtil.convertListLongValues(nodeFileIds);

        Set<File> files = fileIds.isEmpty() ? new HashSet<>()
                : fileRepo.findAllById(fileIds).stream().collect(Collectors.toSet());

        grant.setFiles(files);
        
        grant.setProject(project);

        Long lastGrant = grantRepo.countByProjectId(project.getId());

        grant.setName("Зээл олголт ".concat(String.valueOf(lastGrant + 1)));

        Grant result = grantRepo.saveAndFlush(grant);
                
        return ResponseEntity.ok().body(result);
    }

    @GetMapping("/projects/{id}/grants")
    @PreAuthorize(AccessExpressions.PROJECT_ACCESS)
    public ResponseEntity<List<Grant>> getGrands(@PathVariable Long id, Pageable pageable,
            UriComponentsBuilder uriBuilder) {
        Page<Grant> page = grantRepo.findByProjectId(id, pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(uriBuilder, page);
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
     * {@code POST  /engineer-assessments} : Create a new engineerAssessment.
     *
     * @param engineerAssessment
     *            the engineerAssessment to create.
     * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new engineerAssessment, or with status {@code 400 (Bad Request)} if the engineerAssessment has already an
     *         ID.
     * @throws URISyntaxException
     *             if the Location URI syntax is incorrect.
     */
    @PostMapping("/projects/{id}/engineer-assessments")
    @PreAuthorize(AccessExpressions.PROJECT_ACCESS)
    public ResponseEntity<EngineerAssessment> createProjectEngineerAssessment(@PathVariable Long id,
            @Valid @RequestBody ObjectNode content) throws URISyntaxException {
        log.debug("REST request to save EngineerAssessment : {}", content);
        ArrayNode nodeFileIds = (ArrayNode) content.get(GRANT_FILE_IDS);

        EngineerAssessment engineerAssessment = JsonUtil.parseObjectNodeToObject(content, EngineerAssessment.class,
                ENGINEERASSESSMENT_FILE_ID);

        if (engineerAssessment.getId() != null) {
            throw new BadRequestAlertException("A new grant cannot already have an ID", ENTITY_NAME, "idexists");
        }

        EngineerAssessment result = engineerAssessment;

        Project project = projectRepo.findById(id).get();

        Set<Long> fileIds = HelperUtil.convertListLongValues(nodeFileIds);

        Set<File> files = fileIds.isEmpty() ? new HashSet<>()
                : fileRepo.findAllById(fileIds).stream().collect(Collectors.toSet());

        engineerAssessment.setFiles(files);

        engineerAssessment.setProject(project);

        engineerAssessmentRepo.saveAndFlush(engineerAssessment);

        return ResponseEntity.ok().body(result);
    }

    @GetMapping("/projects/{id}/engineer-assessments")
    @PreAuthorize(AccessExpressions.PROJECT_ACCESS)
    public ResponseEntity<List<EngineerAssessment>> getEngineerAssessments(@PathVariable Long id, Pageable pageable,
            UriComponentsBuilder uriBuilder) {
        // TODO authorization
        // everyone who has access to project but excluding customers
        Page<EngineerAssessment> page = engineerAssessmentRepo.findByProjectId(id, pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(uriBuilder, page);
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    @GetMapping("/projects/{id}/facilities")
    @PreAuthorize(AccessExpressions.PROJECT_ACCESS)
    public ResponseEntity<List<Facility>> getFacilities(@PathVariable Long id, @Conjunction(value = {
            @Or({
                    @Spec(path = "number", params = "query", spec = Equal.class)
            })
    }, and = {
            @Spec(path = "area", params = "area[gte]", spec = GreaterThanOrEqual.class),
            @Spec(path = "area", params = "area[lte]", spec = LessThanOrEqual.class),
            @Spec(path = "trade.pricePerUnit", params = "pricePerUnit[gte]", spec = GreaterThanOrEqual.class),
            @Spec(path = "trade.pricePerUnit", params = "pricePerUnit[lte]", spec = LessThanOrEqual.class),
            @Spec(path = "building.project.id", pathVars = "id", spec = Equal.class),
            @Spec(path = "type", params = "filter[type]", spec = Equal.class),
            @Spec(path = "building.id", params = "filter[building_id]", spec = Equal.class),
            @Spec(path = "trade.status", params = "filter[status]", spec = Equal.class),
            @Spec(path = "release.status", params = "filter[release_status]", spec = Equal.class),
    })
    
    Specification<Facility> spec, Pageable pageable, UriComponentsBuilder uriBuilder) {
        // TODO authorization
        Page<Facility> page = facilityRepo.findAll(spec, pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(uriBuilder, page);
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    @GetMapping("/projects/{id}/buildings")
    @PreAuthorize(AccessExpressions.PROJECT_ACCESS)
    public ResponseEntity<List<Building>> getBuildings(@PathVariable Long id, Pageable pageable,
            UriComponentsBuilder uriBuilder) {
        Page<Building> page = buildingRepo.findByProjectId(id, pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(uriBuilder, page);
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
     * Project manager users notifications
     * 
     * @param project
     * @param message
     */
    public void sendNotification(Project project, String message) {
        List<String> userIds = new ArrayList<>();
        try {
            userIds = HelperUtil.parseListString(project.getUsers(), ",");
        } catch (Exception e) {
            log.error(e.getMessage());
        }
        // TODO filter userId CS role khaan bank api connected
        notifyService.sendNotification(userIds, message);
    }

}

package com.khanbank.cpms.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.khanbank.cpms.domain.Trade;

/**
 * Spring Data repository for the Trade entity.
 */
@Repository
public interface TradeRepository extends JpaRepository<Trade, Long> {

	Optional<Trade> findByFacilityId(Long id);

}

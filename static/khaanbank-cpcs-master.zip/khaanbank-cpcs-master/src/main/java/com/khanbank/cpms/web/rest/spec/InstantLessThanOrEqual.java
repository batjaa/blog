package com.khanbank.cpms.web.rest.spec;

import java.time.Instant;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Predicate;

import net.kaczmarzyk.spring.data.jpa.domain.ComparableSpecification;
import net.kaczmarzyk.spring.data.jpa.utils.Converter;
import net.kaczmarzyk.spring.data.jpa.utils.QueryContext;

/**
 * <p>
 * Filters with less than or equal where-clause (e.g. {@code where date <= "2019-09-19T15:00:00Z"}).
 * </p>
 * 
 * <p>
 * Support field type: instant.
 * </p>
 * 
 * <p>
 * Field types must be Comparable (e.g, implement the {@code Comparable} interface); this is a JPA constraint.
 * </p>
 * 
 * <p>
 * NOTE: comparisons are dependent on the underlying database.
 * </p>
 * <p>
 * Comparisons of floats and doubles (especially floats) may be incorrect due to precision loss.
 * </p>
 * <p>
 * Comparisons of booleans may be dependent on the underlying database representation.
 * </p>
 * <p>
 * Comparisons of enums will be of their ordinal or string representations, depending on what you specified to JPA, e.g., {@code @Enumerated(EnumType.STRING)}, {@code @Enumerated(EnumType.ORDINAL)} or
 * the default ({@code @Enumerated(EnumType.ORDINAL)})
 * </p>
 * 
 * @author Z.Jakasil
 */
public class InstantLessThanOrEqual extends ComparableSpecification<Instant> implements InstantConverter {

    private static final long serialVersionUID = 1L;

    public InstantLessThanOrEqual(QueryContext queryContext, String path, String[] httpParamValues,
            Converter converter) {
        super(queryContext, path, httpParamValues, converter);
    }

    @Override
    protected <Y extends Comparable<? super Y>> Predicate makePredicate(CriteriaBuilder cb, Expression<? extends Y> x,
            Y y) {

        Y convertY = makePredicatedValueConverter(y);

        return cb.lessThanOrEqualTo(x, convertY);
    }

}

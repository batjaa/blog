package com.khanbank.cpms.service.dto;

import org.springframework.security.core.userdetails.UserDetails;

public interface AppUser extends UserDetails {

    String getAccessToken();

    boolean hasAccessToken();

    void setRefreshAccessToken(String refreshAccessToken);

}

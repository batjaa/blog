package com.khanbank.cpms.web.rest;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.khanbank.cpms.domain.Role;
import com.khanbank.cpms.repository.RoleRepository;
import com.khanbank.cpms.web.rest.errors.BadRequestAlertException;

import io.github.jhipster.web.util.HeaderUtil;
import io.github.jhipster.web.util.PaginationUtil;
import io.github.jhipster.web.util.ResponseUtil;

/**
 * REST controller for managing {@link com.khanbank.cpms.domain.Role}.
 */
@RestController
@RequestMapping("/api")
public class RoleResource {

	private final Logger log = LoggerFactory.getLogger(RoleResource.class);

	private static final String ENTITY_NAME = "role";

	@Value("${jhipster.clientApp.name}")
	private String applicationName;

	private final RoleRepository roleRepository;

	public RoleResource(RoleRepository roleRepository) {
		this.roleRepository = roleRepository;
	}

	/**
	 * {@code POST  /roles} : Create a new role.
	 *
	 * @param role
	 *            the role to create.
	 * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new role, or with status {@code 400 (Bad Request)} if the role has already an ID.
	 * @throws URISyntaxException
	 *             if the Location URI syntax is incorrect.
	 */
	@PostMapping("/roles")
	public ResponseEntity<Role> createRole(@Valid @RequestBody Role role) throws URISyntaxException {
		log.debug("REST request to save Role : {}", role);
		if (role.getId() != null) {
			throw new BadRequestAlertException("A new role cannot already have an ID", ENTITY_NAME, "idexists");
		}
		Role result = roleRepository.save(role);
		return ResponseEntity.created(new URI("/api/roles/" + result.getId())).headers(HeaderUtil.createEntityCreationAlert(applicationName, true, ENTITY_NAME, result.getId().toString()))
				.body(result);
	}

	/**
	 * {@code PUT  /roles} : Updates an existing role.
	 *
	 * @param role
	 *            the role to update.
	 * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated role, or with status {@code 400 (Bad Request)} if the role is not valid, or with status
	 *         {@code 500 (Internal Server Error)} if the role couldn't be updated.
	 * @throws URISyntaxException
	 *             if the Location URI syntax is incorrect.
	 */
	@PutMapping("/roles")
	public ResponseEntity<Role> updateRole(@Valid @RequestBody Role role) throws URISyntaxException {
		log.debug("REST request to update Role : {}", role);
		if (role.getId() == null) {
			throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
		}
		Role result = roleRepository.save(role);
		return ResponseEntity.ok().headers(HeaderUtil.createEntityUpdateAlert(applicationName, true, ENTITY_NAME, role.getId().toString())).body(result);
	}

	/**
	 * {@code GET  /roles} : get all the roles.
	 *
	 * @param pageable
	 *            the pagination information.
	 * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of roles in body.
	 */
	@GetMapping("/roles")
	public ResponseEntity<List<Role>> getAllRoles(Pageable pageable, @RequestParam MultiValueMap<String, String> queryParams, UriComponentsBuilder uriBuilder) {
		log.debug("REST request to get a page of Roles");
		Page<Role> page = roleRepository.findAll(pageable);
		HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(uriBuilder.queryParams(queryParams), page);
		return ResponseEntity.ok().headers(headers).body(page.getContent());
	}

	/**
	 * {@code GET  /roles/:id} : get the "id" role.
	 *
	 * @param id
	 *            the id of the role to retrieve.
	 * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the role, or with status {@code 404 (Not Found)}.
	 */
	@GetMapping("/roles/{id}")
	public ResponseEntity<Role> getRole(@PathVariable Long id) {
		log.debug("REST request to get Role : {}", id);
		Optional<Role> role = roleRepository.findById(id);
		return ResponseUtil.wrapOrNotFound(role);
	}

	/**
	 * {@code DELETE  /roles/:id} : delete the "id" role.
	 *
	 * @param id
	 *            the id of the role to delete.
	 * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
	 */
	@DeleteMapping("/roles/{id}")
	public ResponseEntity<Void> deleteRole(@PathVariable Long id) {
		log.debug("REST request to delete Role : {}", id);
		roleRepository.deleteById(id);
		return ResponseEntity.noContent().headers(HeaderUtil.createEntityDeletionAlert(applicationName, true, ENTITY_NAME, id.toString())).build();
	}
}

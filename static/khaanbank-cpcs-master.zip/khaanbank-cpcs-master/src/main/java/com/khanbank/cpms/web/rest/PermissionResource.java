package com.khanbank.cpms.web.rest;

import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.khanbank.cpms.domain.Permission;
import com.khanbank.cpms.repository.PermissionRepository;
import com.khanbank.cpms.web.rest.errors.BadRequestAlertException;

import io.github.jhipster.web.util.HeaderUtil;
import io.github.jhipster.web.util.PaginationUtil;
import io.github.jhipster.web.util.ResponseUtil;

/**
 * REST controller for managing {@link com.khanbank.cpms.domain.Permission}.
 */
@RestController
@RequestMapping("/api")
public class PermissionResource {

	private final Logger log = LoggerFactory.getLogger(PermissionResource.class);

	private static final String ENTITY_NAME = "permission";

	@Value("${jhipster.clientApp.name}")
	private String applicationName;

	private final PermissionRepository permissionRepository;

	public PermissionResource(PermissionRepository permissionRepository) {
		this.permissionRepository = permissionRepository;
	}

	/**
	 * {@code PUT  /permissions} : Updates an existing permission.
	 *
	 * @param permission
	 *            the permission to update.
	 * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated permission, or with status {@code 400 (Bad Request)} if the permission is not valid, or with status
	 *         {@code 500 (Internal Server Error)} if the permission couldn't be updated.
	 * @throws URISyntaxException
	 *             if the Location URI syntax is incorrect.
	 */
	@PutMapping("/permissions")
	public ResponseEntity<Permission> updatePermission(@Valid @RequestBody Permission permission) throws URISyntaxException {
		log.debug("REST request to update Permission : {}", permission);
		if (permission.getId() == null) {
			throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
		}
		Permission result = permissionRepository.save(permission);
		return ResponseEntity.ok().headers(HeaderUtil.createEntityUpdateAlert(applicationName, true, ENTITY_NAME, permission.getId().toString())).body(result);
	}

	/**
	 * {@code GET  /permissions} : get all the permissions.
	 *
	 * @param pageable
	 *            the pagination information.
	 * @param eagerload
	 *            flag to eager load entities from relationships (This is applicable for many-to-many).
	 * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of permissions in body.
	 */
	@GetMapping("/permissions")
	public ResponseEntity<List<Permission>> getAllPermissions(Pageable pageable, @RequestParam MultiValueMap<String, String> queryParams, UriComponentsBuilder uriBuilder,
			@RequestParam(required = false, defaultValue = "false") boolean eagerload) {
		log.debug("REST request to get a page of Permissions");
		Page<Permission> page;
		if (eagerload) {
			page = permissionRepository.findAllWithEagerRelationships(pageable);
		} else {
			page = permissionRepository.findAll(pageable);
		}
		HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(uriBuilder.queryParams(queryParams), page);
		return ResponseEntity.ok().headers(headers).body(page.getContent());
	}

	/**
	 * {@code GET  /permissions/:id} : get the "id" permission.
	 *
	 * @param id
	 *            the id of the permission to retrieve.
	 * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the permission, or with status {@code 404 (Not Found)}.
	 */
	@GetMapping("/permissions/{id}")
	public ResponseEntity<Permission> getPermission(@PathVariable Long id) {
		log.debug("REST request to get Permission : {}", id);
		Optional<Permission> permission = permissionRepository.findOneWithEagerRelationships(id);
		return ResponseUtil.wrapOrNotFound(permission);
	}
}

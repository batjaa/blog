package com.khanbank.cpms.config;

import org.springframework.boot.orm.jpa.hibernate.SpringPhysicalNamingStrategy;
import org.hibernate.boot.model.naming.Identifier;
import org.hibernate.engine.jdbc.env.spi.JdbcEnvironment;

public class PrefixSpringPhysicalNamingStrategy extends SpringPhysicalNamingStrategy {
    String TABLE_NAME_PREFIX = "cpms_";

    @Override
    public Identifier toPhysicalTableName(Identifier name, JdbcEnvironment jdbcEnvironment) {
        String prefixedName = TABLE_NAME_PREFIX + name.getText();
        Identifier newIdentifier = new Identifier(prefixedName.toUpperCase(), name.isQuoted());
        return super.toPhysicalTableName(newIdentifier, jdbcEnvironment);
    }
}

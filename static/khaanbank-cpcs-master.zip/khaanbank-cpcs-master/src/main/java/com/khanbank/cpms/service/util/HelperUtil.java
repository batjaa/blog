package com.khanbank.cpms.service.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import javax.persistence.Entity;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.node.ArrayNode;

public class HelperUtil {

    private static final Logger logger = LoggerFactory.getLogger(HelperUtil.class);

    private static final String CREATE_AT_FIELD = "createdAt";
    private static final String UPDATE_AT_FIELD = "updatedAt";
    private static final String CREATE_BY_FIELD = "createdBy";
    private static final String UPDATE_BY_FIELD = "updatedBy";

    private static List<String> ignoreRequistFields = Arrays.asList(CREATE_AT_FIELD, UPDATE_AT_FIELD, CREATE_BY_FIELD,
            UPDATE_BY_FIELD);

    public static boolean hasDefualtRequistFields(String field) {
        return ignoreRequistFields.stream().anyMatch(f -> f.matches(field));
    }

    /**
     * Бүх entity байх (Required) талбаруудн утагийн оноож өгөх<br>
     * 
     * Ignore Required Fields : <b>createdAt, createdBy, updatedAt, updatedBy</b>
     * 
     * @param contentObj
     * @param entity
     * @param lockedRefrence
     * @param entityUpdate
     */
    public static void setCreateMapObjectValues(Object contentObj, Object entity, boolean lockedRefrence) {
        Map<String, Object> values = new LinkedHashMap<String, Object>();

        Class<?> entityClass = entity == null ? null : entity.getClass();

        if (entityClass != null && entityClass.isAnnotationPresent(Entity.class)) {
            // Project-ийн нэрийн эхний үсэгийн жижиг болгож field нэр үүсгэж авах утагийн авах
            String entityName = ReflectionUtil.firstChatToLowercase(entityClass.getSimpleName());
            values.put(entityName, entity);
        }

        try {
            ReflectionUtil.setObjectValue(contentObj, values, lockedRefrence);
        } catch (Exception e) {
            logger.error(e.getMessage());
        }

    }

    /**
     * сreateAt, createBy заавал бөглөх талбар null болж орж байгаа түүнийг авдаг болгох<br>
     * old manual field names
     * 
     * @param optOldObject
     * @param updObject
     * @param fieldNames
     */
    public static <T> boolean updateObjectRequiredFields(Optional<T> optOldObject, T updObject, String... fieldNames) {

        if (!optOldObject.isPresent())
            return false;

        Object oldObject = optOldObject.get();

        Set<String> invalidNames = new HashSet<>();

        invalidNames.add(CREATE_AT_FIELD);
        invalidNames.add(CREATE_BY_FIELD);

        invalidNames.addAll(Arrays.asList(fieldNames));

        Map<String, Object> values = ReflectionUtil.getContentValues(oldObject, invalidNames);

        if (values.isEmpty())
            return true;

        try {
            ReflectionUtil.setObjectValue(updObject, values, false);
        } catch (Exception e) {
            logger.error(e.getMessage());
        }

        return true;

    }

    public static Set<Long> convertListLongValues(ArrayNode nodeFileIds) {
        Set<Long> result = new HashSet<>();

        if (nodeFileIds == null)
            return result;

        nodeFileIds.forEach(nfileId -> result.add(nfileId.longValue()));

        return result;
    }

    /**
     * String values delimiter split
     * 
     * @param values
     * @param delimiter
     * @throws Exception 
     */
    public static List<String> parseListString(String values, String delimiter) throws Exception {
        List<String> result = new ArrayList<>();

        if (delimiter == null || delimiter.isEmpty())
            throw new Exception("Delimiter is null or empty !!!");

        if (values == null || values.isEmpty())
            return result;

        String[] datas = values.split(delimiter);

        result.addAll(Arrays.asList(datas));

        return result;
    }
}

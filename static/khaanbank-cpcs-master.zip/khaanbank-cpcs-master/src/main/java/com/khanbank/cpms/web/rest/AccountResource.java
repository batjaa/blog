package com.khanbank.cpms.web.rest;

import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.khanbank.cpms.security.SecurityUtils;
import com.khanbank.cpms.service.KhaanBankService;
import com.khanbank.cpms.service.dto.AppUser;
import com.khanbank.cpms.service.mapper.AccountMapper;

/**
 * REST controller for managing the current user's account.
 */
@RestController
@RequestMapping("/api")
public class AccountResource {

    private final Logger log = LoggerFactory.getLogger(AccountResource.class);

    @Autowired
    private KhaanBankService khaanBankService;

    /**
     * {@code GET  /account} : get the current user.
     *
     * @return the current user.
     * @throws RuntimeException
     *             {@code 500 (Internal Server Error)} if the user couldn't be returned.
     */
    @GetMapping("/account")
    public ResponseEntity<AccountMapper> getAccount() {

        try {
            AppUser appUser = SecurityUtils.getAppUser();

            List<String> authorities = appUser.getAuthorities().stream().map(GrantedAuthority::getAuthority)
                    .collect(Collectors.toList());

            AccountMapper account = new AccountMapper(appUser.getUsername(), authorities);
            account.setLangKey("mn");

            if (!appUser.hasAccessToken())
                khaanBankService.refreshAccessToken(appUser);

            return ResponseEntity.ok().body(account);

        } catch (Exception ex) {
            log.error(ex.getMessage());

        }

        return ResponseEntity.badRequest().build();
    }

}

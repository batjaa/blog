package com.khanbank.cpms.service.dto;

import java.util.Set;
import java.util.stream.Collectors;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.khanbank.cpms.config.Constants;
import com.khanbank.cpms.domain.Authority;
import com.khanbank.cpms.domain.User;

/**
 * A DTO representing a user, with his authorities.
 */
public class UserDTO {

    private String id;

    @JsonAlias("name")
    @NotBlank
    @Pattern(regexp = Constants.LOGIN_REGEX)
    @Size(min = 1, max = 50)
    private String login;

    @JsonIgnore
    private String credentials;

    private UserClaims claims;

    @JsonIgnore
    @Email
    @Size(min = 5, max = 254)
    private String email;

    @JsonAlias("status")
    private boolean activated = false;

    private String type;

    @JsonIgnore
    private Set<String> authorities;

    public UserDTO() {
        // Empty constructor needed for Jackson.
    }

    public UserDTO(User user) {
        this.id = user.getId().toString();
        this.login = user.getLogin();
        this.email = user.getEmail();
        this.activated = user.getActivated();
        this.authorities = user.getAuthorities().stream().map(Authority::getName).collect(Collectors.toSet());
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getCredentials() {
        return credentials;
    }

    public void setCredentials(String credentials) {
        this.credentials = credentials;
    }

    public UserClaims getClaims() {
        return claims;
    }

    public void setClaims(UserClaims claims) {
        this.claims = claims;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public boolean isActivated() {
        return activated;
    }

    public void setActivated(boolean activated) {
        this.activated = activated;
    }

    public Set<String> getAuthorities() {
        return authorities;
    }

    public void setAuthorities(Set<String> authorities) {
        this.authorities = authorities;
    }

    @Override
    public String toString() {
        return "UserDTO{" + "login='" + login + '\'' + "}";
    }
}

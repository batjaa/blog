package com.khanbank.cpms.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import com.khanbank.cpms.domain.Project;

/**
 * Spring Data repository for the Project entity.
 */
@Repository
public interface ProjectRepository extends BaseSpecRespository<Project, Long> {
    Project findByBuildingsFacilitiesId(Long facilityId);

    Page<Project> findByCompanyId(Long id, Pageable pageable);
}

package com.khanbank.cpms.web.rest;

import java.net.URISyntaxException;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.khanbank.cpms.domain.File;
import com.khanbank.cpms.domain.Grant;
import com.khanbank.cpms.repository.FileRepository;
import com.khanbank.cpms.repository.GrantRepository;
import com.khanbank.cpms.service.util.HelperUtil;
import com.khanbank.cpms.service.util.JsonUtil;

import io.github.jhipster.web.util.HeaderUtil;
import io.github.jhipster.web.util.ResponseUtil;

/**
 * REST controller for managing {@link com.khanbank.cpms.domain.Grant}.
 */
@RestController
@RequestMapping("/api")
public class GrantResource {

    private final Logger log = LoggerFactory.getLogger(GrantResource.class);

    private static final String ENTITY_NAME = "grant";

    private static final String GRANT_FILE_IDS = "fileIds";

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final GrantRepository grantRepo;

    @Autowired
    private FileRepository fileRepo;

    public GrantResource(GrantRepository grantRepository) {
        this.grantRepo = grantRepository;
    }

    /**
     * {@code PUT  /grants} : Updates an existing grant.
     *
     * @param grant
     *            the grant to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated grant, or with status {@code 400 (Bad Request)} if the grant is not valid, or with status
     *         {@code 500 (Internal Server Error)} if the grant couldn't be updated.
     * @throws URISyntaxException
     *             if the Location URI syntax is incorrect.
     */
    @PutMapping("/grants")
    public ResponseEntity<Grant> updateGrant(@Valid @RequestBody ObjectNode content) throws URISyntaxException {

        log.debug("REST request to update Grant : {}", content);

        ArrayNode nodeFileIds = (ArrayNode) content.get(GRANT_FILE_IDS);

        Grant grant = JsonUtil.parseObjectNodeToObject(content, Grant.class, GRANT_FILE_IDS);

        Optional<Grant> optOldGrant = grantRepo.findById(grant.getId());

        boolean updateEntity = HelperUtil.updateObjectRequiredFields(optOldGrant, grant, "project");

        if (!updateEntity)
            return ResponseEntity.badRequest().build();

        Set<Long> fileIds = HelperUtil.convertListLongValues(nodeFileIds);

        Set<File> files = fileIds.isEmpty() ? new HashSet<>()
                : fileRepo.findAllById(fileIds).stream().collect(Collectors.toSet());

        grant.setFiles(files);

        Grant result = grantRepo.save(grant);
        return ResponseEntity.ok().headers(
                HeaderUtil.createEntityUpdateAlert(applicationName, true, ENTITY_NAME, grant.getId().toString()))
                .body(result);
    }

    /**
     * {@code GET  /grants/:id} : get the "id" grant.
     *
     * @param id
     *            the id of the grant to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the grant, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/grants/{id}")
    public ResponseEntity<Grant> getGrant(@PathVariable Long id) {
        log.debug("REST request to get Grant : {}", id);
        Optional<Grant> grant = grantRepo.findById(id);
        return ResponseUtil.wrapOrNotFound(grant);
    }

    /**
     * {@code DELETE  /grants/:id} : delete the "id" grant.
     *
     * @param id
     *            the id of the grant to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/grants/{id}")
    public ResponseEntity<Void> deleteGrant(@PathVariable Long id) {
        log.debug("REST request to delete Grant : {}", id);
        grantRepo.deleteById(id);
        return ResponseEntity.noContent()
                .headers(HeaderUtil.createEntityDeletionAlert(applicationName, true, ENTITY_NAME, id.toString()))
                .build();
    }
}

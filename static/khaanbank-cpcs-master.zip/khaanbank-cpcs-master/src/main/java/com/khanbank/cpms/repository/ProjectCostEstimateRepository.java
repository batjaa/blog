package com.khanbank.cpms.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.khanbank.cpms.domain.ProjectCostEstimate;

/**
 * Spring Data repository for the ProjectCostEstimate entity.
 */
@Repository
public interface ProjectCostEstimateRepository extends JpaRepository<ProjectCostEstimate, Long> {

	Optional<ProjectCostEstimate> findByProjectId(Long projectId);

}

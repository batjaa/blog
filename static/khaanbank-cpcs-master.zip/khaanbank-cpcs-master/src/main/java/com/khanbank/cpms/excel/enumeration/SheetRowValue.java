package com.khanbank.cpms.excel.enumeration;

public enum SheetRowValue {
    CURRENT, SUM, LAST_VALUE, LAST_DATE
}

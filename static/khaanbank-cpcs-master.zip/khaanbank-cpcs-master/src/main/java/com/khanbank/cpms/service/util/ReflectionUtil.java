package com.khanbank.cpms.service.util;

import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotNull;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.khanbank.cpms.excel.SheetAbstractCellView;
import com.khanbank.cpms.excel.SheetCellView;
import com.khanbank.cpms.excel.SheetColumnView;
import com.khanbank.cpms.excel.SheetRowView;
import com.khanbank.cpms.excel.anno.SheetCell;
import com.khanbank.cpms.excel.anno.SheetRow;
import com.khanbank.cpms.excel.template.TemplateField;

public class ReflectionUtil {
    private static Logger logger = LoggerFactory.getLogger(ReflectionUtil.class);

    // Class-н төрлийг шалгана.
    public static boolean isWrapperClass(Class<?> clazz) {
        if (isDate(clazz))
            return true;
        if (isNumber(clazz))
            return true;
        if (isText(clazz))
            return true;

        return false;
    }

    public static boolean isDate(Class<?> clazz) {
        if (clazz.equals(Date.class))
            return true;

        if (clazz.equals(Instant.class))
            return true;

        return false;
    }

    public static boolean isNumber(Class<?> clazz) {
        if (clazz.equals(Integer.class))
            return true;
        if (clazz.equals(Long.class))
            return true;
        if (clazz.equals(Double.class))
            return true;
        if (clazz.equals(Short.class))
            return true;
        if (clazz.equals(Byte.class))
            return true;
        if (clazz.equals(Float.class))
            return true;

        return false;
    }

    public static boolean isText(Class<?> clazz) {
        if (clazz.equals(String.class))
            return true;

        return false;
    }

    /***/
    public static List<SheetCellView> getSheetCellViews(Class<?> clazz) {
        return getSheetCellViews(clazz, null, false, null);
    }

    private static List<SheetCellView> getSheetCellViews(Class<?> clazz, Class<?> parentClass, boolean isCollection,
            String groupFieldName) {

        List<SheetCellView> fields = new ArrayList<>();

        for (Field field : clazz.getDeclaredFields()) {
            String fieldName = field.getName();
            try {
                Class<?> type = field.getType();

                if (field.isAnnotationPresent(JsonIgnoreProperties.class)
                        || field.isAnnotationPresent(JsonIgnore.class))
                    continue;

                boolean hasOneToMany = field.isAnnotationPresent(OneToMany.class);

                if (hasOneToMany) {
                    ParameterizedType pt = (ParameterizedType) field.getGenericType();
                    for (Type t : pt.getActualTypeArguments()) {
                        type = Class.forName(t.getTypeName());
                    }
                }

                if (type.isAnnotationPresent(Entity.class)) {
                    groupFieldName = hasOneToMany ? fieldName : isCollection ? groupFieldName : null;
                    List<SheetCellView> documentFields = getSheetCellViews(type, clazz, hasOneToMany, groupFieldName);
                    fields.addAll(documentFields);
                    continue;
                }

                SheetCell sheetCellAnno = field.getDeclaredAnnotation(SheetCell.class);
                boolean required = field.getDeclaredAnnotation(NotNull.class) != null;

                SheetAbstractCellView sheetView = null;

                if (sheetCellAnno != null) {
                    SheetColumnView sheetColumn = new SheetColumnView(sheetCellAnno);
                    sheetColumn.setRequired(required);
                    sheetView = sheetColumn;
                }

                SheetRow sheetRowAnno = field.getDeclaredAnnotation(SheetRow.class);

                if (sheetRowAnno != null) {
                    SheetRowView sheetRow = new SheetRowView(sheetRowAnno);
                    sheetView = sheetRow;
                }

                if (sheetView == null)
                    continue;

                String displayName = sheetView.getKey();
                TemplateField template = new TemplateField(displayName, fieldName, type, clazz, parentClass);
                template.setCollection(isCollection);
                template.setRequired(required);
                template.setGroupFieldName(groupFieldName);
                sheetView.setTemplate(template);
                fields.add(sheetView);
            } catch (Exception ex) {
                logger.error("field name : {}\n {}", fieldName, ex.getMessage());
                continue;
            }
        }

        return fields;
    }

    public static void setObjectValue(Object contentObj, Map<String, Object> values, boolean lockedRefrence)
            throws Exception {
        if (contentObj == null)
            return;

        setObjectValue(contentObj, contentObj.getClass(), values, lockedRefrence);
    }

    @SuppressWarnings({
            "unchecked"
    })
    private static void setObjectValue(Object contentObj, Class<?> entityClass, Map<String, Object> values,
            boolean lockedRefrence) throws Exception {

        if (!entityClass.isAnnotationPresent(Entity.class))
            return;

        if (!lockedRefrence) {
            String parentName = firstChatToLowercase(entityClass.getSimpleName());
            values.put(parentName, contentObj);
        }

        for (Field field : entityClass.getDeclaredFields()) {

            field.setAccessible(true);

            Class<?> type = field.getType();
            Object fieldValue = field.get(contentObj);

            boolean hasFieldValue = fieldValue != null;

            if (!lockedRefrence && hasFieldValue && type.isAnnotationPresent(Entity.class)) {
                setObjectValue(fieldValue, type, values, lockedRefrence);
                continue;
            }

            if (!lockedRefrence && hasFieldValue && field.isAnnotationPresent(OneToMany.class)) {
                Class<?> actualType = getActualType((ParameterizedType) field.getGenericType());

                for (Object val : (Collection<Object>) fieldValue)
                    setObjectValue(val, actualType, values, lockedRefrence);

                continue;
            }

            if (hasFieldValue)
                continue;

            String name = field.getName();
            Object value = values.get(name);

            if (value == null)
                continue;

            field.set(contentObj, value);
        }

    }

    public static Map<String, Object> getContentValues(Object contentObj, Set<String> fieldNames) {
        Map<String, Object> result = new LinkedHashMap<>();
        Class<?> clazz = contentObj.getClass();

        for (String fieldName : fieldNames) {
            try {
                Field field = clazz.getDeclaredField(fieldName);
                field.setAccessible(true);

                Object value = field.get(contentObj);

                if (value != null) {
                    logger.debug("GET old value: {}", value);
                    result.put(fieldName, value);
                }
            } catch (Exception e) {
                logger.error(e.getMessage());
            }
        }

        return result;
    }

    private static Class<?> getActualType(ParameterizedType pt) throws ClassNotFoundException {
        Class<?> result = null;
        for (Type t : pt.getActualTypeArguments()) {
            result = Class.forName(t.getTypeName());
        }

        return result;
    }

    /** Орж ирсэн Үгийн Эхний үгийг Жижиг болгож өгнө */
    public static String firstChatToLowercase(String fieldName) {
        if (fieldName == null || fieldName.isEmpty())
            return fieldName;
        Character firstLower = fieldName.charAt(0);
        String rest = fieldName.substring(1);
        String result = firstLower.toString().toLowerCase() + rest;
        return result;
    }

    public static Map<String, Object> findInvalidFields(Object object) {

        Class<? extends Object> entityClass = object.getClass();

        if (!entityClass.isAnnotationPresent(Entity.class))
            return new HashMap<>();

        Map<String, Object> errorDetails = new HashMap<>();

        List<Field> invalidFields = Arrays.asList(entityClass.getDeclaredFields()).stream()
                .filter(field -> field.isAnnotationPresent(NotNull.class)
                        && !HelperUtil.hasDefualtRequistFields(field.getName()))
                .collect(Collectors.toList());

        for (Field field : invalidFields) {

            try {
                field.setAccessible(true);
                Object notNullObject = field.get(object);
                if (notNullObject == null)
                    errorDetails.put(field.getName(), "Утга агуулах ёстой.");
            } catch (Exception e) {

            }

        }
        return errorDetails;
    }

}

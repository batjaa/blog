package com.khanbank.cpms.service.util;

import java.io.File;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.RandomStringUtils;

public class FileUtil {

    public static String createTempFilename(String originalName) {
        String extension = FilenameUtils.getExtension(originalName);
        String randomFileName = RandomStringUtils.randomAlphabetic(16);
        return randomFileName + "." + extension;
    }

    public static String changeFileExtension(String originalName, String extension) {
        String fileName = FilenameUtils.removeExtension(originalName);

        return fileName + "." + extension;
    }

    public static String getFilePath(File newFile) {
        return newFile.getAbsolutePath().replace(System.getProperty("user.dir"), "");
    }

    public static boolean existsFile(String absolutePath) {
        return absolutePath == null ? false : new File(absolutePath).exists();
    }

}
